//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// skiplist.cpp
//
// Identification: src/primer/skiplist.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
// 跳表
// 需要优化：删除之后最高高度需要更新（拿一个桶来记录每个高度的节点数）===----------------------------------------------------------------------===//

#include "primer/skiplist.h"
#include <cassert>
#include <cstddef>
#include <functional>
#include <memory>
#include <string>
#include <vector>
#include "common/macros.h"
#include "fmt/core.h"

namespace bustub {

/** @brief Checks whether the container is empty.检查表是否为空 */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::Empty() -> bool {
  auto readLock = Read();
  if(!Size())return true;
  return false;
  // UNIMPLEMENTED("TODO(P0): Add implementation.");
}

/** @brief Returns the number of elements in the skip list. */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::Size() -> size_t {
  auto readLock = Read();
  return size_;
  // UNIMPLEMENTED("TODO(P0): Add implementation.");
}

/**
 * @brief Iteratively deallocate all the nodes.迭代地释放所有节点
 *
 * We do this to avoid stack overflow when the skip list is large.
 *
 * If we let the compiler handle the deallocation, it will recursively call the destructor of each node,
 * which could block up the the stack.
 */
SKIPLIST_TEMPLATE_ARGUMENTS void SkipList<K, Compare, MaxHeight, Seed>::Drop() {
  for (size_t i = 0; i < MaxHeight; i++) {
    auto curr = std::move(header_->links_[i]);
    while (curr != nullptr) {
      // std::move sets `curr` to the old value of `curr->links_[i]`,
      // and then resets `curr->links_[i]` to `nullptr`.
      curr = std::move(curr->links_[i]);
    }
  }
}

/**
 * @brief Removes all elements from the skip list.
 *
 * Note: You might want to use the provided `Drop` helper function.
 */
SKIPLIST_TEMPLATE_ARGUMENTS void SkipList<K, Compare, MaxHeight, Seed>::Clear() {
  auto writeLock = Write();
  Drop();
  height_ = 1;
  size_ = 0;
  // UNIMPLEMENTED("TODO(P0): Add implementation.");
}

/**
 * @brief Inserts a key into the skip list.
 *
 * Note: `Insert` will not insert the key if it already exists in the skip list.
 *
 * @param key key to insert.
 * @return true if the insertion is successful, false if the key already exists.
 */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::Insert(const K &key) -> bool {
  auto writeLock = Write();
  // 预先设置高度，用来后面记录要修改指针的节点
  size_t nodeHeight = RandomHeight();
  // 保存要修改的节点
  std::shared_ptr<SkipNode> update[MaxHeight];
  //初始化update数组
  for (size_t i = 0; i < MaxHeight; i++) update[i] = Header();

  auto curr = Header();
  for (size_t i = MaxHeight - 1; i >= 0 && i !=SIZE_MAX; i--) {
    while (curr->Next(i) != nullptr && compare_(curr->Next(i)->Key(), key)) {
      curr = curr->Next(i);
    }  // 直到这一层没有元素或者找到一个比key大的元素，就停止，往下一层走
    if (curr->Next(i) != nullptr && !compare_(curr->Next(i)->Key(), key) && !compare_(key, curr->Next(i)->Key())) {
      return false;
    }  // 如果下一个就等于key，返回false
    update[i]=curr;
  }
  // 当找不到key时，插入节点。此时的curr指向前一个节点
  auto node = std::shared_ptr<SkipNode>(new SkipNode(nodeHeight, key));
  for (size_t i = nodeHeight - 1; i >= 0 && i != SIZE_MAX; i--) {
    node->SetNext(i,update[i]->Next(i));
    update[i]->SetNext(i,node);
  }
  size_++;
  if(node->Height() > height_)height_ = node->Height();
  return true;
  // UNIMPLEMENTED("TODO(P0): Add implementation.");
}

/**
 * @brief Erases the key from the skip list.
 *
 * @param key key to erase.
 * @return bool true if the element got erased, false otherwise.
 */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::Erase(const K &key) -> bool {
  auto writeLock = Write();
  // 保存要修改的节点
  std::shared_ptr<SkipNode> update[MaxHeight];
  std::shared_ptr<SkipNode> target = nullptr;
  // 初始化update数组
  for (size_t i = 0; i < MaxHeight; i++) update[i] = Header();

  auto curr = Header();
  for (size_t i = height_ - 1; i >= 0 && i != SIZE_MAX; i--) {
    while (curr->Next(i) != nullptr && compare_(curr->Next(i)->Key(), key)){
      curr = curr->Next(i);  
    }
    if (curr->Next(i) != nullptr && !compare_(curr->Next(i)->Key(), key) && !compare_(key, curr->Next(i)->Key())) {
      if (target == nullptr) target = curr->Next(i);
      update[i] = curr;
    }
  }
  if(target == nullptr)return false;
  for (size_t i = target->Height() - 1; i >= 0 && i != SIZE_MAX; i--) {
    update[i]->SetNext(i,target->Next(i));
  }
  size_--;
  // 释放target节点
  target.reset();
  return true;
  //UNIMPLEMENTED("TODO(P0): Add implementation.");
}

/**
 * @brief Checks whether a key exists in the skip list.
 *
 * @param key key to look up.
 * @return bool true if the element exists, false otherwise.
 */
// 查找元素key
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::Contains(const K &key) -> bool {
  auto readLock = Read();
  // Following the standard library: Key `a` and `b` are considered equivalent if neither compares less
  // than the other: `!compare_(a, b) && !compare_(b, a)`.
  // 这里的compare_（a,b）是默认a小于b的时候返回true
  auto curr = Header();
  for (size_t i = height_ - 1; i >= 0 && i != SIZE_MAX; i--) {
    while (curr->Next(i) != nullptr && compare_(curr->Next(i)->Key(), key)) {
        curr = curr->Next(i);
    }//直到这一层没有元素或者找到一个比key大的元素，就停止，往下一层走
    if(curr->Next(i) != nullptr &&
     !compare_(curr->Next(i)->Key(), key)&&
     !compare_(key, curr->Next(i)->Key())){
      return true;
    }//如果下一个就等于key，返回true
  }
  return false;
  //UNIMPLEMENTED("TODO(P0): Add implementation.");
}

/**
 * @brief Prints the skip list for debugging purposes.
 *
 * Note: You may modify the functions in any way and the output is not tested.
 */
SKIPLIST_TEMPLATE_ARGUMENTS void SkipList<K, Compare, MaxHeight, Seed>::Print() {
  auto readLock = Read();
  auto node = header_->Next(LOWEST_LEVEL);
  while (node != nullptr) {
    fmt::println("Node {{ key: {}, height: {} }}", node->Key(), node->Height());
    node = node->Next(LOWEST_LEVEL);
  }
}

/**
 * @brief Generate a random height. The height should be cappped at `MaxHeight`.
 * Note: we implement/simulate the geometric process to ensure platform independence.
 * 生成结点的随机高度，高度上限为`MaxHeight`
 */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::RandomHeight() -> size_t {
  // Branching factor (1 in 4 chance), see Pugh's paper.
  static constexpr unsigned int branching_factor = 4;
  // Start with the minimum height
  size_t height = 1;
  while (height < MaxHeight && (rng_() % branching_factor == 0)) {
    height++;
  }
  return height;
}

/**
 * @brief Gets the current node height.返回节点的高度
 */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::SkipNode::Height() const -> size_t {
  // UNIMPLEMENTED("TODO(P0): Add implementation.");
  return links_.size();
}

/**
 * @brief Gets the next node by following the link at `level`.
 *
 * @param level index to the link.
 * @return std::shared_ptr<SkipNode> the next node, or `nullptr` if such node does not exist.
 */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::SkipNode::Next(size_t level) const
    -> std::shared_ptr<SkipNode> {
  // UNIMPLEMENTED("TODO(P0): Add implementation.");
  return links_[level];
}

/**
 * @brief Set the `node` to be linked at `level`.
 *
 * @param level index to the link.
 * 设置level层的下一个节点为node
 */
SKIPLIST_TEMPLATE_ARGUMENTS void SkipList<K, Compare, MaxHeight, Seed>::SkipNode::SetNext(
    size_t level, const std::shared_ptr<SkipNode> &node) {
  //UNIMPLEMENTED("TODO(P0): Add implementation.");
  links_[level]=node;
}

/** @brief Returns a reference to the key stored in the node. */
SKIPLIST_TEMPLATE_ARGUMENTS auto SkipList<K, Compare, MaxHeight, Seed>::SkipNode::Key() const -> const K & {
  return key_;
//   UNIMPLEMENTED("TODO(P0): Add implementation.");
}

// Below are explicit instantiation of template classes.
// 下面是模板类的显式实例化。
template class SkipList<int>;
template class SkipList<std::string>;
template class SkipList<int, std::greater<>>;
template class SkipList<int, std::less<>, 8>;

}  // namespace bustub
