//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_k_replacer.h
//
// Identification: src/include/buffer/lru_k_replacer.h
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#pragma once

#include <limits>
#include <list>
#include <mutex>  // NOLINT
#include <optional>
#include <unordered_map>
#include <set>

#include "common/config.h"
#include "common/macros.h"

namespace bustub {

enum class AccessType { Unknown = 0, Lookup, Scan, Index };

class LRUKNode {
  public:
  //这里为什么不要求写构造函数？
  explicit LRUKNode(frame_id_t frame_id, size_t k) : k_(k), fid_(frame_id) {
  }
  //析构函数
  ~LRUKNode() = default;
  // 返回可驱逐状态
  bool get_is_evictable() const 
  { return is_evictable_; }
  //设定状态
  void set_is_evictable(bool is_evictable) {
    is_evictable_ = is_evictable;
  }
  //获取历史访问次数
  size_t get_history_size() { return history_size_ ;}
  //获取id
  frame_id_t get_fid(){return fid_;}
  //获取设定的k_
  size_t get_k(){return k_;}
  //获取历史队列
  std::list<size_t>* get_history() { return &history_; }
  //更新历史队列
  size_t update_history(size_t timestamp) {//增加新的
    if(history_size_ < k_){
      history_.push_front(timestamp);
      history_size_++;
    }
    else{
      history_.pop_back();
      history_.push_front(timestamp);
    }
    
    if(history_size_ == k_){
      //更新k距离
      k_distance_ = history_.back();
    }
    else{
      k_distance_ = history_.front();
    }
    return k_distance_;
  }
  //获取k距离 
  auto get_k_distance() -> size_t { return k_distance_; }
  //设置下表
  // void set_order_in_list(size_t order){ order_in_list = order; }
  
  //获取in_k_list
  bool get_in_k_list(){ return in_k_list_; }
  
  void set_in_k_list(bool in_k_list){ in_k_list_ =in_k_list; }

 private:
  /** History of last seen K timestamps of this page. Least recent timestamp stored in front. */
  // Remove maybe_unused if you start using them. Feel free to change the member variables as you want.

  std::list<size_t>history_;  // 过去k次访问时间
  size_t k_;// k值
  frame_id_t fid_;// frame id
  bool is_evictable_{false};// 是否可以被驱逐,这里为什么默认不可驱逐？？？？

  size_t history_size_{0};  // 访问次数
  size_t k_distance_{SIZE_T_MAX};//k距离
  
  //size_t order_in_list{SIZE_T_MAX};//记录在队伍中的名次，越小越容易被驱逐
  bool in_k_list_{false};
};

/*
 * LRUKReplacer implements the LRU-k replacement policy.
 *
 * The LRU-k algorithm evicts a frame whose backward k-distance is maximum
 * of all frames. Backward k-distance is computed as the difference in time between
 * current timestamp and the timestamp of kth previous access.
 *
 * A frame with less than k historical references is given
 * +inf as its backward k-distance. When multiple frames have +inf backward k-distance,
 * classical LRU algorithm is used to choose victim.
 */
class LRUKReplacer {
 public:
  explicit LRUKReplacer(size_t num_frames, size_t k);

  DISALLOW_COPY_AND_MOVE(LRUKReplacer);

  /**
   * TODO(P1): Add implementation
   *
   * @brief Destroys the LRUReplacer.实现析构函数
   */
  ~LRUKReplacer() = default;

  //删除一个frame
  auto Evict() -> std::optional<frame_id_t>;

  //增加一个访问
  void RecordAccess(frame_id_t frame_id, AccessType access_type = AccessType::Unknown);

  //设置某个frame是否可以被驱逐
  void SetEvictable(frame_id_t frame_id, bool set_evictable);

  //删除某个frame
  void Remove(frame_id_t frame_id);

  //返回可驱逐的frame数量 
  auto Size() -> size_t;
  
  //维护那两个list
  void update_list(frame_id_t frame_id, bool is_new, size_t old_time = 0);

 private:
  // TODO(student): implement me! You can replace these member variables as you like.
  // Remove maybe_unused if you start using them.
  std::unordered_map<frame_id_t, LRUKNode> node_store_;  // 存储每个frameid的历史访问记录节点
  size_t current_timestamp_{0};         // 当前时间戳，每访问一条就增加1
  size_t curr_size_{0};                 // 当前可驱逐缓存个数
  size_t replacer_size_{0};             // 缓存的总大小
  size_t k_{0};                         // K值
  std::mutex latch_{};//互斥锁
  
  //添加成员变量
  size_t node_store_size_{0};        //mp的大小
  std::set<size_t> unk_list_;           // 记录未到k次的页面的k距离排序，这里是生序
  std::set<size_t> k_list_;             // 记录未到k次的页面的k距离排序，这里是生序
  std::unordered_map<size_t,frame_id_t> timestamp_store_;  // 从k_dis找到frame_id
};

}  // namespace bustub
