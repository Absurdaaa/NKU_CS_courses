//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_k_replacer.cpp
//
// Identification: src/buffer/lru_k_replacer.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/lru_k_replacer.h"
#include "common/exception.h"

namespace bustub {

/**
 *
 * TODO(P1): Add implementation
 *
 * @brief a new LRUKReplacer.
 * @param num_frames the maximum number of frames the LRUReplacer will be required to store
 */

LRUKReplacer::LRUKReplacer(size_t num_frames, size_t k) : replacer_size_(num_frames), k_(k) {
  node_store_.reserve(num_frames);
  timestamp_store_.reserve(num_frames);
  // unk_list_.clear();
  // k_list_.clear();
  return;  // 疑问，这里不是不需要实现吗？
}

/**
 * TODO(P1): Add implementation
 *
 * @brief Find the frame with largest backward k-distance and evict that frame. Only frames
 * that are marked as 'evictable' are candidates for eviction.
 *
 * A frame with less than k historical references is given +inf as its backward k-distance.
 * If multiple frames have inf backward k-distance, then evict frame whose oldest timestamp如果多个可驱逐，则找最老的
 * is furthest in the past.
 *
 * Successful eviction of a frame should decrement the size of replacer and remove the frame's
 * access history.
 *
 * @return true if a frame is evicted successfully, false if no frames can be evicted.
 */
// auto LRUKReplacer::Evict() -> std::optional<frame_id_t> {
//   // 上锁
//   auto latch = std::unique_lock<std::mutex>(latch_);
//   //遍历寻找最远的可驱逐的frame
//   [[maybe_unused]] size_t oldest_timestamp = std::numeric_limits<size_t>::max();
//   bool is_k = true;//用来判定现在的fid是不是满k的
//   [[maybe_unused]] std::optional<frame_id_t> frame_id = std::nullopt;
  
//   if(this->Size() == 0){
//     return frame_id;
//   }

//   for (auto &[key, value] : node_store_) {//迭代遍历
//     if(value.get_is_evictable()){ //如果这个帧可驱逐
//       if(!is_k && value.get_history_size()<value.get_k()){ //第二次之后找到一个没满k的fid
//         if (value.get_history()->front() < oldest_timestamp) {
//           frame_id = key;
//           oldest_timestamp = value.get_history()->front();
//         }
//       }
//       else if (is_k) {
//         if (value.get_history_size() == value.get_k()){
//           if (value.get_history()->front() < oldest_timestamp) {
//             frame_id = key;
//             oldest_timestamp = value.get_history()->front();
//           }
//         }
//         else{  // 第一次找到一个没满k的帧
//           frame_id = key;
//           oldest_timestamp = value.get_history()->front();
//           is_k = false;
//         }
//       } 
//     }
//   }
//   // 下面驱逐frameid
//   // 如果有找到id，就驱逐，不然就返回这个空
//   if(frame_id.has_value()){
//     Remove(frame_id.value());
//   }
  
//   return frame_id;
// }
auto LRUKReplacer::Evict() -> std::optional<frame_id_t> {
  latch_.lock();

  std::optional<frame_id_t> frame_id = std::nullopt;
  //寻找最远的可驱逐的frame,先从unk_list找：
  if(!unk_list_.empty()){
    for (size_t timestamp : unk_list_) 
      {
        auto it_frame = timestamp_store_.find(timestamp);
        if (it_frame == timestamp_store_.end()) continue;

        auto it_Node = node_store_.find(it_frame->second);
        if (it_Node == node_store_.end()) continue;

        if (it_Node->second.get_is_evictable()) {
          frame_id = it_frame->second;
          unk_list_.erase(timestamp);  // ✔️ OK：你后续不再访问 `it`，立即 break
          //timestamp_store_.erase(it_frame);
          break;
        }
      }
  }
  else if(!k_list_.empty()){//再从k_list找
    for (size_t timestamp : k_list_) {
      auto it_frame = timestamp_store_.find(timestamp);
      if (it_frame == timestamp_store_.end()) continue;
      auto it_Node = node_store_.find(it_frame->second);
      if (it_Node == node_store_.end()) continue;
      if (it_Node->second.get_is_evictable()) {
        frame_id = it_frame->second;
        // auto it_list = std::lower_bound(k_list_.begin(), k_list_.end(), timestamp);
        k_list_.erase(timestamp);
        //timestamp_store_.erase(it_frame);
        break;
      }
    }
  }
  // else{//都为空，报错
  //  //BUSTUB_ASSERT(false, "Cannot find frame in replacer");
  //  return
  // }
  
  if (frame_id.has_value()) {
    Remove(frame_id.value());
  }
  latch_.unlock();
  return frame_id;
}



/**
 * TODO(P1): Add implementation
 *
 * @brief Record the event that the given frame id is accessed at current timestamp.
 * Create a new entry for access history if frame id has not been seen before.
 *
 * If frame id is invalid (ie. larger than replacer_size_), throw an exception. You can
 * also use BUSTUB_ASSERT to abort the process if frame id is invalid.
 *
 * @param frame_id id of frame that received a new access.
 * @param access_type type of access that was received. This parameter is only needed for
 * leaderboard tests.
 * 增加访问记录
 */
void LRUKReplacer::RecordAccess(frame_id_t frame_id, [[maybe_unused]] AccessType access_type){
  // 上锁
  // auto latch = std::unique_lock<std::mutex>(latch_);
  latch_.lock();
  
  current_timestamp_++;//增加时间戳
  auto it = node_store_.find(frame_id);
  if(it == node_store_.end()) {
    if (node_store_size_ == replacer_size_) {
      latch_.unlock();//Evict里面又上了一次互斥锁
      Evict();
      latch_.lock();
    }
    //创建新的node放进去
    LRUKNode new_node(frame_id, k_);
    timestamp_store_.insert({new_node.update_history(current_timestamp_),frame_id});
    
    node_store_.insert({frame_id, std::move(new_node)});
    node_store_size_++;
    update_list(frame_id ,1,SIZE_T_MAX);
    // curr_size_++;
  }
  else{//找到这个id了
    size_t old_time = node_store_.find(frame_id)->second.get_k_distance();
    timestamp_store_.erase(timestamp_store_.find(old_time));
    timestamp_store_.insert({(it->second).update_history(current_timestamp_), frame_id});
    update_list(frame_id, 0, old_time);
  }
  latch_.unlock();
}

/**
 * TODO(P1): Add implementation
 *
 * @brief Toggle whether a frame is evictable or non-evictable. This function also
 * controls replacer's size. Note that size is equal to number of evictable entries.控制curr-size
 *
 * If a frame was previously evictable and is to be set to non-evictable, then size should
 * decrement. If a frame was previously non-evictable and is to be set to evictable,
 * then size should increment.
 *
 * If frame id is invalid, throw an exception or abort the process.
 *
 * For other scenarios, this function should terminate without modifying anything.
 *
 * @param frame_id id of frame whose 'evictable' status will be modified
 * @param set_evictable whether the given frame is evictable or not
 */
void LRUKReplacer::SetEvictable(frame_id_t frame_id, bool set_evictable) {
    //上锁
    auto latch = std::unique_lock<std::mutex>(latch_);
    //如果找不到这个id，终止还是报错？
    auto it = node_store_.find(frame_id);
    if (it == node_store_.end()) {
      return;
      //BUSTUB_ASSERT(false, "Cannot find thisframe id");
    }
    //如果之前是可驱逐的，现在要设置为不可驱逐，就减少size
    if ((it->second).get_is_evictable() && !set_evictable) {
      (it->second).set_is_evictable(set_evictable);
      curr_size_--;
    }
    //如果之前是不可驱逐的，现在要设置为可驱逐，就增加size
    if (!(it->second).get_is_evictable() && set_evictable) {
      (it->second).set_is_evictable(set_evictable);
      curr_size_++;
    }
    return;
}

/**
 * TODO(P1): Add implementation
 *
 * @brief Remove an evictable frame from replacer, along with its access history.
 * This function should also decrement replacer's size if removal is successful.
 *
 * Note that this is different from evicting a frame, which always remove the frame
 * with largest backward k-distance. This function removes specified frame id,
 * no matter what its backward k-distance is.
 *
 * If Remove is called on a non-evictable frame, throw an exception or abort the
 * process.
 *
 * If specified frame is not found, directly return from this function.
 *
 * @param frame_id id of frame to be removed
 */
void LRUKReplacer::Remove(frame_id_t frame_id) {
  // 上锁,锁了一次还需要锁吗
  // auto latch = std::unique_lock<std::mutex>(latch_);
  timestamp_store_.erase(
    timestamp_store_.find(
      node_store_.find(frame_id)->second.get_k_distance()
      )
    );
  node_store_.erase(node_store_.find(frame_id));
  
  node_store_size_--;
  curr_size_--;
}

/**
 * TODO(P1): Add implementation
 *
 * @brief Return replacer's size, which tracks the number of evictable frames.
 *
 * @return size_t
 * 应该是获取当前可驱逐的frame数量
 */
auto LRUKReplacer::Size() -> size_t {
  return curr_size_;
    }

void LRUKReplacer::update_list(frame_id_t frame_id, bool is_new,size_t old_time){
  auto it = node_store_.find(frame_id);
  if(it == node_store_.end()){return;}
  
  if(it->second.get_history_size() < k_){//如果小于k_
    if(is_new){//如果新放进去的
      unk_list_.insert(it->second.get_k_distance());
    }else{//如果原本就在里面
    //删掉之前记录
    // auto it_list = std::lower_bound(unk_list_.begin(), unk_list_.end(), old_time);
    unk_list_.erase(old_time);

    unk_list_.insert(it->second.get_k_distance());
    }
  }
  else{ //如果等于k_
    if (!it->second.get_in_k_list()){//原本不在k里面
      // 删掉之前记录
      // auto it_list = std::lower_bound(unk_list_.begin(), unk_list_.end(), old_time);
      unk_list_.erase(old_time);

      k_list_.insert(it->second.get_k_distance());
      it->second.set_in_k_list(1);
    }
    else{
      // auto it_list = std::lower_bound(k_list_.begin(), k_list_.end(), old_time);
      k_list_.erase(old_time);

      k_list_.insert(it->second.get_k_distance());
    }
  }
  return;
}
}  // namespace bustub
