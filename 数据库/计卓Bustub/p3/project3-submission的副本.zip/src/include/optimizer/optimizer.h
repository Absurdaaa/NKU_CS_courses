//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// optimizer.h
//
// Identification: src/include/optimizer/optimizer.h
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#pragma once

#include <memory>
#include <string>
#include <tuple>
#include <unordered_map>
#include <utility>
#include <vector>

#include "catalog/catalog.h"
#include "concurrency/transaction.h"
#include "execution/expressions/abstract_expression.h"
#include "execution/expressions/logic_expression.h"
#include "execution/plans/abstract_plan.h"

namespace bustub {

/**
 * The optimizer takes an `AbstractPlanNode` and outputs an optimized `AbstractPlanNode`.
 */
class Optimizer {
 public:
  explicit Optimizer(const Catalog &catalog, bool force_starter_rule)
      : catalog_(catalog), force_starter_rule_(force_starter_rule) {}

  auto Optimize(const AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef;

  auto OptimizeCustom(const AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef;

 private:
  auto OptimizeMergeProjection(const AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef;

  auto OptimizeMergeFilterNLJ(const AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef;

  auto OptimizeNLJAsHashJoin(const AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef;

  auto OptimizeNLJAsIndexJoin(const AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef;

  auto OptimizeEliminateTrueFilter(const AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef;

  auto OptimizeMergeFilterScan(const AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef;

  auto RewriteExpressionForJoin(const AbstractExpressionRef &expr, size_t left_column_cnt, size_t right_column_cnt)
      -> AbstractExpressionRef;

  auto IsPredicateTrue(const AbstractExpressionRef &expr) -> bool;

  auto OptimizeOrderByAsIndexScan(const AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef;

  auto OptimizeSeqScanAsIndexScan(const AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef;

  auto MatchIndex(const std::string &table_name, uint32_t index_key_idx)
      -> std::optional<std::tuple<index_oid_t, std::string>>;

  auto OptimizeColumnPruning(const AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef;

  auto OptimizeSortLimitAsTopN(const AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef;

  auto EstimatedCardinality(const std::string &table_name) -> std::optional<size_t>;
  
  //输入一个等式表达式，我们用来检查等式里面的列是否为索引，然后给indexscan提供值
  // auto CheckCompexpr(const AbstractExpressionRef &comp_expr,std::string table_name, index_oid_t index_oid,
  //                    std::vector<AbstractExpressionRef> &pred_keys)
  //     -> std::optional<index_oid_t>;
      
  //DFS对logic谓词
  // auto DFSLogicExpr(const AbstractExpressionRef &expr, std::vector<AbstractExpressionRef> &pred_keys)
  //     -> std::optional<index_oid_t>;

  //递归从logic里面提取出等式
  auto CollectEqualityConditions(const LogicExpression *expr,
                                  std::unordered_map<uint32_t, std::vector<Value>> &column_values,
                                  const std::string &table_name) -> void;

  auto ExtractEquiJoinKeys(const AbstractExpressionRef &expr, const Schema &left_schema,
                                      const Schema &right_schema, std::vector<AbstractExpressionRef> *left_keys,
                                      std::vector<AbstractExpressionRef> *right_keys) -> bool;

  /** Catalog will be used during the planning process. USERS SHOULD ENSURE IT OUTLIVES
   * OPTIMIZER, otherwise it's a dangling reference.
   */
  const Catalog &catalog_;

  const bool force_starter_rule_;
};

}  // namespace bustub
