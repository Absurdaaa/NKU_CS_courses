//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// external_merge_sort_executor.h
//
// Identification: src/include/execution/executors/external_merge_sort_executor.h
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

/**
 * 外部归并排序
 * 我们分批读取数据到页面里面，然后归并排序
 */
#pragma once

#include <cstddef>
#include <memory>
#include <utility>
#include <vector>
#include "common/config.h"
#include "common/macros.h"
#include "execution/execution_common.h"
#include "execution/executors/abstract_executor.h"
#include "execution/plans/sort_plan.h"
#include "storage/table/tuple.h"

namespace bustub {
#define SORT_PAGE_HEADER_SIZE 8
// #define SORT_PAGE_SLOT_CNT ((BUSTUB_PAGE_SIZE - LEAF_PAGE_HEADER_SIZE) / (sizeof(KeyType) + sizeof(RID)))

/**
 * Page to hold the intermediate data for external merge sort.
 *
 * Only fixed-length data will be supported in Fall 2024.
 * 应该先全部读取到page中，此时再每个页面都各自排序后再进行归并
 * 
 */
class SortPage {
 public:
  auto Insert(SortKey sort_key, Tuple tuple) -> bool;
  auto Insert(SortEntry sortentry) -> bool;
  //满了或者没有需要放入了之后，先进行内部排序
  void Sort(TupleComparator cmp);
  
  bool IsFull(int SORT_PAGE_SLOT_CNT){return int(tuple_count_) == SORT_PAGE_SLOT_CNT;}
  
  SortEntry GetEntry(size_t index) const {
    if (index >= tuple_count_) {
      throw Exception("Index out of range");
    }
    return array_[index];
  }
  
  size_t GetTupleCount() const { return tuple_count_; }
  /**
   * TODO: Define and implement the methods for reading data from and writing data to the sort
   * page. Feel free to add other helper methods.
   */
 private:
  /**
   * TODO: Define the private members. You may want to have some necessary metadata 元数据 for
   * the sort page before the start of the actual data.
   */
  
  // page_id_t page_id_;
  
  // 元组计数元数据（存储在页面开头）
  size_t tuple_count_;
  
  // 用来存储参与排序的属性
  std::vector<SortEntry> array_;
  
};

/**
 * A data structure that holds the sorted tuples as a run during external merge sort.
 * Tuples might be stored in multiple pages, and tuples are ordered both within one page
 * and across pages.
 * 用来存一组已经排好序的sortpage
 */
class MergeSortRun {
 public:
  MergeSortRun() = default;
  MergeSortRun(std::vector<page_id_t> pages, BufferPoolManager *bpm) : pages_(std::move(pages)), bpm_(bpm) {}
  
  ~MergeSortRun() {
    Drop();
  }
  
  void Drop() {
    if (bpm_ == nullptr) {
      return;  // 已经被释放过
    }
    //释放所有存有序页面的内存
    for (auto page_id : pages_) {
      bpm_->DeletePage(page_id);
    }
    bpm_ = nullptr;
    pages_.clear();
  }

  auto GetPageCount() const -> size_t { return pages_.size(); }

  bool Insert(SortEntry sortentry, int SORT_PAGE_SLOT_CNT);

  /** Iterator for iterating on the sorted tuples in one run. */
  class Iterator {
    friend class MergeSortRun;

   public:
    Iterator() = default;

    /**
     * Advance the iterator to the next tuple. If the current sort page is exhausted, move to the
     * next sort page.
     *
     * TODO: Implement this method.
     */
    auto operator++() -> Iterator & {
      if (current_page_id_ == INVALID_PAGE_ID || current_page_index_ >= run_->GetPageCount()) {
        throw Exception("Invalid page id");
      }

      auto read_guard = run_->bpm_->ReadPage(current_page_id_);
      auto sortpage = read_guard.As<SortPage>();

      if (current_tuple_index_ + 1 < sortpage->GetTupleCount()) {
        current_tuple_index_++;
        return *this;
      } else {
        current_page_index_++;
        if(current_page_index_ < run_->GetPageCount()) {
          current_page_id_ = run_->pages_[current_page_index_];
          current_tuple_index_ = 0;
        } else {
          current_page_id_ = INVALID_PAGE_ID;
          current_tuple_index_ = 0;
        }
      }

      return *this; 
    }

    /**
     * Dereference the iterator to get the current tuple in the sorted run that the iterator is
     * pointing to.
     * 这里原本返回tuple
     *这里改成了返回SortEntry
     * TODO: Implement this method.
     */
    auto operator*() -> SortEntry {
      if(current_page_id_ == INVALID_PAGE_ID || current_page_index_ >= run_->GetPageCount()) {
        throw Exception("Invalid page id");
      }
      // 获取页面并添加错误检查
      auto read_guard = run_->bpm_->ReadPage(current_page_id_);
      if (read_guard.GetData() == nullptr) {
        throw Exception("Failed to read page");
      }
      // auto read_guard = run_->bpm_->ReadPage(current_page_id_);
      auto sortpage = read_guard.As<SortPage>();
      return sortpage->GetEntry(current_tuple_index_);
    }

    /**
     * Checks whether two iterators are pointing to the same tuple in the same sorted run.
     *
     * TODO: Implement this method.
     */
    auto operator==(const Iterator &other) const -> bool {
      if (current_page_id_ == other.current_page_id_ && 
          current_tuple_index_ == other.current_tuple_index_ &&
          current_page_index_ == other.current_page_index_ &&
          run_ == other.run_) {
        return true;
      }
      return false;
    }

    /**
     * Checks whether two iterators are pointing to different tuples in a sorted run or iterating
     * on different sorted runs.
     *
     * TODO: Implement this method.
     */
    auto operator!=(const Iterator &other) const -> bool {
      return !(*this == other);
    }

    

   private:
    explicit Iterator(const MergeSortRun *run) : run_(run) {}

    /** The sorted run that the iterator is iterating on. */
    const MergeSortRun *run_;

    /**
     * TODO: Add your own private members here. You may want something to record your current
     * position in the sorted run. Also feel free to add additional constructors to initialize
     * your private members.
     */
    //当前遍历到的sortpage
    page_id_t current_page_id_;
    //当前遍历到的tuple
    size_t current_tuple_index_;
    //当前遍历到的sortpage的index
    size_t current_page_index_;
    
    
  };

  /**
   * Get an iterator pointing to the beginning of the sorted run, i.e. the first tuple.
   *
   * TODO: Implement this method.
   */
  auto Begin() -> Iterator {
    auto it = Iterator(this);
    it.current_page_index_ = 0;
    it.current_tuple_index_ = 0;
    if(pages_.size() > 0)
      it.current_page_id_ = pages_[0];
    else
      it.current_page_id_ = INVALID_PAGE_ID;
    return it;
  }

  /**
   * Get an iterator pointing to the end of the sorted run, i.e. the position after the last tuple.
   *
   * TODO: Implement this method.
   */
  auto End() -> Iterator {
    auto it = Iterator(this);
    it.current_page_index_ = pages_.size();
    // auto read_guard = bpm_->ReadPage(pages_[it.current_page_index_]);
    // auto sortpage = read_guard.As<SortPage>();
    // it.current_tuple_index_ = sortpage->GetTupleCount();
    it.current_tuple_index_ = 0;
    it.current_page_id_ = INVALID_PAGE_ID;
    return it;
  }
  
  size_t GetTupleCount() const { return tuple_count_; }

  Iterator current_iter_;

 private:
  /** The page IDs of the sort pages that store the sorted tuples. */
  std::vector<page_id_t> pages_;
  /**
   * The buffer pool manager used to read sort pages. The buffer pool manager is responsible for
   * deleting the sort pages when they are no longer needed.
   */
  BufferPoolManager *bpm_;
  
  size_t tuple_count_ = 0;
};

/**
 * ExternalMergeSortExecutor executes an external merge sort.
 *
 * In Fall 2024, only 2-way external merge sort is required.
 */
template <size_t K>
class ExternalMergeSortExecutor : public AbstractExecutor {
 public:
  ExternalMergeSortExecutor(ExecutorContext *exec_ctx, const SortPlanNode *plan,
                            std::unique_ptr<AbstractExecutor> &&child_executor);

  void Init() override;

  auto Next(Tuple *tuple, RID *rid) -> bool override;

  /** @return The output schema for the external merge sort */
  auto GetOutputSchema() const -> const Schema & override { return plan_->OutputSchema(); }
  
  //计算keysize
  auto CulKeysize()->uint8_t;

  //归并两个块
  auto Merge(MergeSortRun *run1,MergeSortRun*run2) -> MergeSortRun *;

private:
 /** The sort plan node to be executed */
 const SortPlanNode *plan_;

 /** Compares tuples based on the order-bys */
 TupleComparator cmp_;

 /** TODO: You will want to add your own private members here. */
 std::unique_ptr<AbstractExecutor> child_executor_;

 std::vector<OrderBy> order_bys_;

 BufferPoolManager *bpm_;

 std::vector<MergeSortRun *> runs_;
 std::vector<page_id_t> sort_page_ids_;

 int SORT_PAGE_SLOT_CNT;
 int TUPLE_SIZE;

};

}  // namespace bustub
