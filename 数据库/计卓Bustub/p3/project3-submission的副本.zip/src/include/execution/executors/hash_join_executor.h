//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// hash_join_executor.h
//
// Identification: src/include/execution/executors/hash_join_executor.h
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#pragma once

#include <memory>
#include <utility>



#include "execution/executor_context.h"
#include "execution/executors/abstract_executor.h"
#include "execution/plans/hash_join_plan.h"
#include "storage/table/tuple.h"

namespace bustub {



// // 添加这个哈希函数类
// struct HashJoinKeyHasher {
//   auto operator()(const HashJoinKey &key) const -> std::size_t {
//     std::size_t hash = 0;
//     for (const auto &value : key.join_ons_) {
//       hash = hash * 31 + Hash;
//     }
//     return hash;
//   }
// };

class HashJoinTable{
  public:
   HashJoinTable(const HashJoinTable &) = default;
   HashJoinTable(const std::vector<AbstractExpressionRef> &left_key_exprs,
                 const std::vector<AbstractExpressionRef> &right_key_exprs, const Schema left_schema,
                 const Schema right_schema)
       : left_key_exprs_(left_key_exprs),
         right_key_exprs_(right_key_exprs),
         left_schema_(left_schema),
         right_schema_(right_schema) {};
   /**
    * 根据右边的schema生成初始值
    */
   auto GenerateInitialJoinValue() -> Tuple;

   auto MakeLeftHashJoinKey(const Tuple &tuple) -> HashJoinKey;

   auto MakeRightHashJoinKey(const Tuple &tuple) -> HashJoinKey;

  void Insert(const HashJoinKey &key, const Tuple &value) {
     hash_table_[key].push_back(value);
   }

   auto Find(const HashJoinKey &key) -> HashJoinVal {
     if (hash_table_.find(key) != hash_table_.end()) {
       return hash_table_[key];
     }
     // 找不到返回空
     return {};
    }

  private:
    const std::vector<AbstractExpressionRef> left_key_exprs_;
    const std::vector<AbstractExpressionRef> right_key_exprs_;
    const Schema left_schema_;
    const Schema right_schema_;
    std::unordered_map<HashJoinKey, HashJoinVal> hash_table_{};
};

/**
 * HashJoinExecutor executes a nested-loop JOIN on two tables.
 */
class HashJoinExecutor : public AbstractExecutor {
  
 public:
  HashJoinExecutor(ExecutorContext *exec_ctx, const HashJoinPlanNode *plan,
                   std::unique_ptr<AbstractExecutor> &&left_child, std::unique_ptr<AbstractExecutor> &&right_child);

  void Init() override;

  auto Next(Tuple *tuple, RID *rid) -> bool override;

  /** @return The output schema for the join */
  auto GetOutputSchema() const -> const Schema & override { return plan_->OutputSchema(); };

  void BuildHashTable();
  //把两个可以连接的元组连接起来
  auto MakeJoinTuple(const Tuple &left_tuple, const Tuple &right_tuple) -> Tuple;

 private:
  /** The HashJoin plan node to be executed. */
  const HashJoinPlanNode *plan_;
  std::unique_ptr<AbstractExecutor> left_child_;
  std::unique_ptr<AbstractExecutor> right_child_;

  HashJoinTable hht_;

  // 当前正在处理的左表元组
  Tuple left_tuple_;
  RID left_rid_;
  HashJoinVal matched_left_tuples_{};
  size_t matched_idx_{0};
  //目前手上的左元组是否未被处理过
  bool has_left_tuple_{false};
  
  //左表遍历完没
  bool is_end_{false};
};

}  // namespace bustub


