//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// nested_index_join_executor.h
//
// Identification: src/include/execution/executors/nested_index_join_executor.h
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#pragma once

#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "execution/executor_context.h"
#include "execution/executors/abstract_executor.h"
#include "execution/expressions/abstract_expression.h"
#include "execution/plans/nested_index_join_plan.h"
#include "storage/table/tmp_tuple.h"
#include "storage/table/tuple.h"

namespace bustub {

/**
 * IndexJoinExecutor executes index join operations.
 */
class NestIndexJoinExecutor : public AbstractExecutor {
 public:
  NestIndexJoinExecutor(ExecutorContext *exec_ctx, const NestedIndexJoinPlanNode *plan,
                        std::unique_ptr<AbstractExecutor> &&child_executor);

  auto GetOutputSchema() const -> const Schema & override { return plan_->OutputSchema(); }

  void Init() override;

  auto Next(Tuple *tuple, RID *rid) -> bool override;

 private:
  /** The nested index join plan node. */
  const NestedIndexJoinPlanNode *plan_;

  std::unique_ptr<AbstractExecutor> child_executor_;
  
  //当前扫描匹配的元组
  Tuple left_tuple_;
  RID left_rid_;
  //表示左表的元组是否已经结束
  bool is_end_{false};
  JoinType join_type_;
  // bool need_right_match_{false};
  // bool has_right_match_{false};
  
  //关于索引的信息
  table_oid_t table_oid_;
  TableHeap *table_heap_;
  const TableInfo *table_info_;
  
  
  index_oid_t index_oid_;
  std::shared_ptr<IndexInfo> index_info_;
  BPlusTreeIndexForTwoIntegerColumn *b_tree_index;
};
}  // namespace bustub
