//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// b_plus_tree_internal_page.h
//
// Identification: src/include/storage/page/b_plus_tree_internal_page.h
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#pragma once

#include <queue>
#include <string>

#include "storage/page/b_plus_tree_page.h"

namespace bustub {

#define B_PLUS_TREE_INTERNAL_PAGE_TYPE BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>
//header的大小
#define INTERNAL_PAGE_HEADER_SIZE 12
// INTERNAL_PAGE_SLOT_CNT：定义了内部页可以存储的键值槽的数量。这个数量的计算方式是：从页面的总大小（BUSTUB_PAGE_SIZE）中减去头部大小（INTERNAL_PAGE_HEADER_SIZE），然后除以每个键值对（KeyType 和 ValueType）所占用的大小
#define INTERNAL_PAGE_SLOT_CNT \
  ((BUSTUB_PAGE_SIZE - INTERNAL_PAGE_HEADER_SIZE) / ((int)(sizeof(KeyType) + sizeof(ValueType))))  // NOLINT

/**
 * Store `n` indexed keys and `n + 1` child pointers (page_id) within internal page.
 * Pointer PAGE_ID(i) points to a subtree in which all keys K satisfy:
 * K(i) <= K < K(i+1).
 * 这个节点的值是子节点的最小值
 * 
 * NOTE: Since the number of keys does not equal to number of child pointers,
 * the first key in key_array_ always remains invalid. That is to say, any search / lookup
 * should ignore the first key.
 * key_array_里面的第一个位置是空的，不存储任何数据，进行查找的时候需要忽略第一个位置
 *
 * Internal page format (keys are stored in increasing order):
 *  ---------
 * | HEADER |
 *  ---------
 *  ------------------------------------------
 * | KEY(1)(INVALID) | KEY(2) | ... | KEY(n) |
 *  ------------------------------------------
 *  ---------------------------------------------
 * | PAGE_ID(1) | PAGE_ID(2) | ... | PAGE_ID(n) |
 *  ---------------------------------------------
 */
INDEX_TEMPLATE_ARGUMENTS
class BPlusTreeInternalPage : public BPlusTreePage {
 public:
  // Delete all constructor / destructor to ensure memory safety
  BPlusTreeInternalPage() = delete;
  BPlusTreeInternalPage(const BPlusTreeInternalPage &other) = delete;

  void Init(int max_size = INTERNAL_PAGE_SLOT_CNT);

  auto KeyAt(int index) const -> KeyType;

  void SetKeyAt(int index, const KeyType &key);

  /**
   * @param value The value to search for
   * @return The index that corresponds to the specified value
   * 这里的ValueType是page_id，这里要求根据pageid来查找对应下标
   * 我们应该遍历所有的pageid，找到对应的id，然后返回对应的下标
   */
  auto ValueIndex(const ValueType &page_id) const -> int;
  
  
  //输入key关键字，给出对应字节点的下标
  auto Lookup(const KeyType &key, const KeyComparator &comparator) const -> int;

  auto ValueAt(int index) const -> ValueType;

  //当新建一个内部节点的时候，插入两个值的时候初始化
  void InternalInit(
    const KeyType &key, 
    const ValueType left_pageid,
    const ValueType right_pageid);
  
  void InsertValue(const KeyType &key, ValueType page_id, int index);
  
  //插入操作
  bool Insert(const KeyType &key, ValueType page_id, const KeyComparator &comparator);

  //分裂操作并插入
  KeyType Split(KeyType &key, ValueType page_id, B_PLUS_TREE_INTERNAL_PAGE_TYPE *new_page,const KeyComparator &comparator_);

  //删除掉下标为index的元素
  void Remove(int index);


  /**
   * @brief For test only, return a string representing all keys in
   * this internal page, formatted as "(key1,key2,key3,...)"
   *
   * @return The string representation of all keys in the current internal page
   * 用来打印、、所有key
   */
  auto ToString() const -> std::string {
    std::string kstr = "(";
    bool first = true;

    // First key of internal page is always invalid
    for (int i = 1; i < GetSize(); i++) {
      KeyType key = KeyAt(i);
      if (first) {
        first = false;
      } else {
        kstr.append(",");
      }

      kstr.append(std::to_string(key.ToString()));
    }
    kstr.append(")");

    return kstr;
  }

 private:
  // Array members for page data.
  // 存的是建置
  KeyType key_array_[INTERNAL_PAGE_SLOT_CNT];
  //存的是字节点的pageid
  ValueType page_id_array_[INTERNAL_PAGE_SLOT_CNT];
  // (Spring 2025) Feel free to add more fields and helper functions below if needed
};

}  // namespace bustub
