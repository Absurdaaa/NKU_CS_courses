//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// b_plus_tree_leaf_page.h
//
// Identification: src/include/storage/page/b_plus_tree_leaf_page.h
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#pragma once

#include <string>
#include <utility>
#include <vector>

#include "storage/page/b_plus_tree_page.h"

namespace bustub {

#define B_PLUS_TREE_LEAF_PAGE_TYPE BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>
#define LEAF_PAGE_HEADER_SIZE 16
#define LEAF_PAGE_SLOT_CNT ((BUSTUB_PAGE_SIZE - LEAF_PAGE_HEADER_SIZE) / (sizeof(KeyType) + sizeof(ValueType)))

/**
 * Store indexed key and record id (record id = page id combined with slot id,
 * see `include/common/rid.h` for detailed implementation) together within leaf
 * page. Only support unique key.
 *
 * Leaf page format (keys are stored in order):
 *  ---------
 * | HEADER |
 *  ---------
 *  ---------------------------------
 * | KEY(1) | KEY(2) | ... | KEY(n) |
 *  ---------------------------------
 *  ---------------------------------
 * | RID(1) | RID(2) | ... | RID(n) |
 *  ---------------------------------
 *
 *  Header format (size in byte, 16 bytes in total):
 *  -----------------------------------------------
 * | PageType (4) | CurrentSize (4) | MaxSize (4) |
 *  -----------------------------------------------
 *  -----------------
 * | NextPageId (4) |
 *  -----------------
 */
INDEX_TEMPLATE_ARGUMENTS
class BPlusTreeLeafPage : public BPlusTreePage {
 public:
  // Delete all constructor / destructor to ensure memory safety
  BPlusTreeLeafPage() = delete;
  BPlusTreeLeafPage(const BPlusTreeLeafPage &other) = delete;

  void Init(int max_size = LEAF_PAGE_SLOT_CNT);

  // Helper methods
  auto GetNextPageId() const -> page_id_t;
  void SetNextPageId(page_id_t next_page_id);
  auto KeyAt(int index) const -> KeyType;
  auto ValueAt(int index) const -> ValueType;
  
  //输入key关键字，给出对应值
  auto Lookup(const KeyType &key, std::vector<ValueType> *result, const KeyComparator &comparator) const -> bool;
  
  //更精确的二分查找实现
  auto checkKey(const KeyType &key, const KeyComparator &comparator) const -> int {
    int left = 0;
    int right = GetSize() - 1;
    int insert_pos = GetSize(); // 默认在末尾插入
    
    while (left <= right) {
      int mid = left + (right - left) / 2;
      int cmp = comparator(key, KeyAt(mid));
      
      if (cmp == 0) {
        // 找到完全相同的键
        return mid;
      } else if (cmp < 0) {
        // 当前键比目标键大，向左查找
        insert_pos = mid;
        right = mid - 1;
      } else {
        // 当前键比目标键小，向右查找
        left = mid + 1;
      }
    }
    
    return insert_pos;
  }

  //插入值
  auto InsertValue(const KeyType &key, const ValueType &value, int index) -> bool;
  
  //分裂并同时插入新键值对
  void SplitAndInsert(
    const KeyType &key, const ValueType &value, B_PLUS_TREE_LEAF_PAGE_TYPE *new_leaf,
    page_id_t new_page_id, const KeyComparator &comparator);

  // //分裂,这里offset取决于插入的位置在左边还是右边，我们希望保证分裂并插入之后两边都是等于minsize
  // //offest=1时就是左边放min-1个，右边放min个
  // //offest=0时就是左边放min个，右边放min-1个
  // void Split(B_PLUS_TREE_LEAF_PAGE_TYPE *new_leaf,page_id_t new_page_id ,int offest) {
  //   //分裂，新的放在右边
  //   int mid = GetMinSize(); //mid表示左边有几个节点
  //   mid -=offest;
  //   //设定节点块指向
  //   new_leaf->SetNextPageId(GetNextPageId());
  //   SetNextPageId(new_page_id);
  //   //设置大小
  //   new_leaf->SetSize(GetSize() - mid);
  //   SetSize(mid);
  //   for (int i = 0; i < new_leaf->GetSize(); i++) {
  //     new_leaf->key_array_[i] = key_array_[mid + i];
  //     new_leaf->rid_array_[i] = rid_array_[mid + i];
  //   }
  //   return;
  // }


  
  //删除掉下标为index的元素
  void Remove(int index);

  /**
   * @brief For test only return a string representing all keys in
   * this leaf page formatted as "(key1,key2,key3,...)"
   *
   * @return The string representation of all keys in the current internal page
   */
  auto ToString() const -> std::string {
    std::string kstr = "(";
    bool first = true;

    for (int i = 0; i < GetSize(); i++) {
      KeyType key = KeyAt(i);
      if (first) {
        first = false;
      } else {
        kstr.append(",");
      }

      kstr.append(std::to_string(key.ToString()));
    }
    kstr.append(")");

    return kstr;
  }

 private:
  page_id_t next_page_id_;
  // Array members for page data.
  KeyType key_array_[LEAF_PAGE_SLOT_CNT];
  ValueType rid_array_[LEAF_PAGE_SLOT_CNT];
  // (Spring 2025) Feel free to add more fields and helper functions below if needed
};

}  // namespace bustub
