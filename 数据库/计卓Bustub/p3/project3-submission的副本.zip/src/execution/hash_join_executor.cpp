//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// hash_join_executor.cpp
//
// Identification: src/execution/hash_join_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/hash_join_executor.h"
#include "type/value_factory.h"

namespace bustub {

/**
 * Construct a new HashJoinExecutor instance.
 * @param exec_ctx The executor context
 * @param plan The HashJoin join plan to be executed
 * @param left_child The child executor that produces tuples for the left side of join
 * @param right_child The child executor that produces tuples for the right side of join
 */
HashJoinExecutor::HashJoinExecutor(ExecutorContext *exec_ctx, const HashJoinPlanNode *plan,
                                   std::unique_ptr<AbstractExecutor> &&left_child,
                                   std::unique_ptr<AbstractExecutor> &&right_child)
    : AbstractExecutor(exec_ctx),
      plan_(plan),
      left_child_(std::move(left_child)),
      right_child_(std::move(right_child)),
      hht_ (plan->LeftJoinKeyExpressions(), plan->RightJoinKeyExpressions(), plan->GetLeftPlan()->OutputSchema(), plan->GetRightPlan()->OutputSchema()){
  if (!(plan->GetJoinType() == JoinType::LEFT || plan->GetJoinType() == JoinType::INNER)) { 
    // Note for Fall 2024: You ONLY need to implement left join and inner join.
    throw bustub::NotImplementedException(fmt::format("join type {} not supported", plan->GetJoinType()));
  }
}

/** Initialize the join */
void HashJoinExecutor::Init() { 
  //throw NotImplementedException("HashJoinExecutor is not implemented"); 
  // 初始化左右子执行器
  left_child_->Init();
  right_child_->Init();
  // 构建哈希表
  BuildHashTable();
  
  //获取第一个左表元组，以及一些匹配变量和状态
  is_end_ = !left_child_->Next(&left_tuple_, &left_rid_);
  if(!is_end_){
    has_left_tuple_ = true;//说明目前手上的元组还没被处理
    matched_idx_ = 0;
  }
    
}


/**
 * Yield the next tuple from the join.
 * @param[out] tuple The next tuple produced by the join.
 * @param[out] rid The next tuple RID, not used by hash join.
 * @return `true` if a tuple was produced, `false` if there are no more tuples.
 * 要注意的是，当某个右表的元组能匹配上多个左表的元组，我们要记录右表遍历输出的信息，否则少输出项
 * 记得要检查连接条件？但是没有支持evalutejoin
 */
auto HashJoinExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  while(true){
    // 如果已经结束，直接返回false
    if (is_end_) {
      return false;
    }
    
    if (has_left_tuple_) {//如果没有被处理过，这个分支就是来先获取对应的右表元组集合，如果没有，看情况返回元组，同时循环下一个元组
      
      // 先获取左表的哈希键
      HashJoinKey left_key = hht_.MakeLeftHashJoinKey(left_tuple_);
      // 获取右表对应元组
      matched_left_tuples_ = hht_.Find(left_key);
      
      if (matched_left_tuples_.empty()) {  // 如果没有匹配的右表元组，说明左表元组没有匹配的，直接返回
      
        if (plan_->GetJoinType() == JoinType::LEFT) {
          // 如果是左连接，返回左表元组和空的右表元组
          Tuple right_tuple = hht_.GenerateInitialJoinValue();
          *tuple = MakeJoinTuple(left_tuple_, right_tuple);
          *rid = {INVALID_PAGE_ID, 0};
          
          //同时更新下一个左表元组，方便下一次迭代
          is_end_ = !left_child_->Next(&left_tuple_, &left_rid_);
          matched_idx_ = 0;
          has_left_tuple_ = true;
          
          return true;
        } 
        else {
          // 如果是内连接，继续获取下一个左表元组，然后继续循环
          is_end_ = !left_child_->Next(&left_tuple_, &left_rid_);
          matched_idx_ = 0;
          has_left_tuple_ = true;
          continue;
        }
      }
      else{ //如果不是空的，直接进入下一个循环
        has_left_tuple_ = false;
        continue;
      }
    } else {  // 说明上一个的元组还没遍历完对应的右表元组

      if (matched_idx_ < matched_left_tuples_.size()) {
        // 取出当前匹配的右表元组
        Tuple right_tuple = matched_left_tuples_[matched_idx_];
        matched_idx_++;
        // 连接左表和右表元组
        *tuple = MakeJoinTuple(left_tuple_, right_tuple);
        *rid = {INVALID_PAGE_ID, 0};
        return true;
      }

      // 如果已经遍历完所有匹配的右表元组，获取下一个左表元组
      is_end_ = !left_child_->Next(&left_tuple_, &left_rid_);
      matched_idx_ = 0;
      has_left_tuple_ = true;
      continue;   //继续循环查找下一个左表元组
    }
  }
  
  return false;
}

/**
 * 构建哈希表
 * 把左表的所有元组哈希之后放到哈希表中
 * 这里会冲突，所以hash表的第二项是一个vector，存放所有冲突的元组
 * 这里改成了初始化右表，因为这样我们需要遍历每个左表元组，能避免漏掉某些元组没有匹配的情况
 */
void HashJoinExecutor::BuildHashTable() {
  Tuple right_tuple;
  RID right_rid;
  // 先遍历右表
  while (right_child_->Next(&right_tuple, &right_rid)) {
    // 计算哈希键
    HashJoinKey key = hht_.MakeRightHashJoinKey(right_tuple);
    // 插入哈希表
    hht_.Insert(key, right_tuple);
  }
}

/**
 * 初始化默认值也是出事化为右表的格式（不过这里没区别
 */
auto HashJoinTable::GenerateInitialJoinValue() -> Tuple {
  std::vector<Value> values;
  // 构建连接结果
  values.reserve(right_schema_.GetColumnCount());
  for (uint32_t i = 0; i < right_schema_.GetColumnCount(); ++i) {
    values.push_back(ValueFactory::GetNullValueByType(right_schema_.GetColumn(i).GetType()));
  }
  return Tuple(values, &right_schema_);
}

auto HashJoinTable::MakeLeftHashJoinKey(const Tuple &tuple) -> HashJoinKey {
  HashJoinKey key;
  for (const auto &expr : left_key_exprs_) {
    key.join_ons_.push_back(expr->Evaluate(&tuple, left_schema_));
  }
  return key;
}

auto HashJoinTable::MakeRightHashJoinKey(const Tuple &tuple) -> HashJoinKey {
  HashJoinKey key;
  for (const auto &expr : right_key_exprs_) {
    key.join_ons_.push_back(expr->Evaluate(&tuple, right_schema_));
  }
  return key;
}

auto HashJoinExecutor::MakeJoinTuple(const Tuple &left_tuple, const Tuple &right_tuple) -> Tuple {
  std::vector<Value> values;
  // 构建连接结果
  values.reserve(plan_->OutputSchema().GetColumnCount());
  size_t left_len = plan_->GetLeftPlan()->OutputSchema().GetColumnCount();
  size_t right_len = plan_->GetRightPlan()->OutputSchema().GetColumnCount();
  for (uint32_t i = 0; i < left_len; ++i) {
    values.push_back(left_tuple.GetValue(&plan_->GetLeftPlan()->OutputSchema(), i));
  }
  for (uint32_t i = 0; i < right_len; ++i) {
    values.push_back(right_tuple.GetValue(&plan_->GetRightPlan()->OutputSchema(), i));
  }
  return Tuple(values, &plan_->OutputSchema());
}
}  // namespace bustub
