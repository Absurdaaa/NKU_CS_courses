//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// nested_index_join_executor.cpp
//
// Identification: src/execution/nested_index_join_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/nested_index_join_executor.h"
#include "type/value_factory.h"
namespace bustub {

/**
 * Creates a new nested index join executor.
 * @param exec_ctx the context that the nested index join should be performed in
 * @param plan the nested index join plan to be executed
 * @param child_executor the outer table
 */
NestIndexJoinExecutor::NestIndexJoinExecutor(ExecutorContext *exec_ctx, const NestedIndexJoinPlanNode *plan,
                                             std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx),plan_(plan), child_executor_(std::move(child_executor)) {
  //如果不是左连接或者内连接，报错
  if (!(plan->GetJoinType() == JoinType::LEFT || plan->GetJoinType() == JoinType::INNER)) {
    // Note for 2023 Spring: You ONLY need to implement left join and inner join.
    throw bustub::NotImplementedException(fmt::format("join type {} not supported", plan->GetJoinType()));
  }

  join_type_ = plan->GetJoinType();
  // if (join_type_ == JoinType::LEFT) {
  //   need_right_match_ = true;
  // } else if (join_type_ == JoinType::INNER) {
  //   need_right_match_ = false;
  // }

  
  table_oid_ = plan->GetInnerTableOid();
  table_info_ = exec_ctx_->GetCatalog()->GetTable(table_oid_).get();
  if (table_info_ == nullptr) {  // 找不到这个表，但是在进入前应该会检查
    throw ExecutionException("Table not found");
  }
  table_heap_ = table_info_->table_.get();
  
  // 获取计划中指定的索引
  index_oid_ = plan->GetIndexOid();
  index_info_ = exec_ctx_->GetCatalog()->GetIndex(index_oid_);
  b_tree_index = dynamic_cast<BPlusTreeIndexForTwoIntegerColumn *>(index_info_->index_.get());
}

void NestIndexJoinExecutor::Init() { 
  //throw NotImplementedException("NestIndexJoinExecutor is not implemented"); 
  // 初始化子执行器
  child_executor_->Init();
}

/**
 * 从plan里面获取右表的索引树，然后通过索引树查找相关的元组
 * 如果找不到，说明真的没有，如果找到了，那么大概率只有一个，因为是索引
 * 所以不需要找完了还继续遍历
 * 这里也没有右执行器初始化
 */
auto NestIndexJoinExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  Tuple right_tuple;
  RID right_rid;

  // 如果已经结束，直接返回false
  is_end_ = !child_executor_->Next(&left_tuple_, &left_rid_);
  if (is_end_)return false;
  

  while (true) {
    // 尝试在右表中找匹配项
    // 1. 根据坐标的元组构建索引查询键， 里似乎只考虑一列的索引
    std::vector<Value> key_values;
    key_values.push_back(plan_->key_predicate_->Evaluate(&left_tuple_, child_executor_->GetOutputSchema()));
    Tuple key_tuple(key_values, &index_info_->key_schema_);
    
    //2 根据键值查找
    std::vector<RID> right_rids;
    b_tree_index->ScanKey(key_tuple, &right_rids, exec_ctx_->GetTransaction());
    
    //3.如果找到了,先检查是否被删除
    if(right_rids.size()==1){
      right_rid = right_rids[0];
      // 检查是否杯删除
      TupleMeta curr_meta = table_heap_->GetTupleMeta(right_rid);
      
      // 如过已经被删除了，因为索引没有重复的，所以直接匹配下一个左边元组
      // 如果没被删除
      if (!curr_meta.is_deleted_) {
        //获取完元组之后，break，推出循环并且获取下一个左边元组
        // 如果存在且没有被删除，就获取元组
        right_tuple = table_heap_->GetTuple(right_rid).second;
        
        uint32_t left_len = child_executor_->GetOutputSchema().GetColumnCount();
        uint32_t right_len = table_info_->schema_.GetColumnCount();
        
        std::vector<Value> values;
        // 构建连接结果...从左右表提取值
        values.reserve(plan_->OutputSchema().GetColumnCount());
        for (uint32_t i = 0; i < left_len; ++i) {
          values.push_back(left_tuple_.GetValue(&child_executor_->GetOutputSchema(), i));
        }
        for (uint32_t i = 0; i < right_len; ++i) {
          values.push_back(right_tuple.GetValue(&table_info_->schema_, i));
        }
        // 创建连接元组
        *tuple = Tuple(values, &plan_->OutputSchema());
        *rid = {INVALID_PAGE_ID, 0};  // 或生成新RID
        // has_right_match_ = true;
        return true;
      }
    } 
    
    // 如果没有找到匹配项，检查是否是左连接
    if (join_type_ == JoinType::LEFT) {
      uint32_t left_len = child_executor_->GetOutputSchema().GetColumnCount();
      uint32_t right_len = table_info_->schema_.GetColumnCount();
      // 构建左表+NULL值的连接结果
      std::vector<Value> values;
      // ... 填充左表值和右表NULL值
      values.reserve(left_len + right_len);
      for (uint32_t i = 0; i < left_len; ++i) {
        values.push_back(left_tuple_.GetValue(&child_executor_->GetOutputSchema(), i));
      }
      for (uint32_t i = 0; i < right_len; ++i) {
        values.push_back(ValueFactory::GetNullValueByType(table_info_->schema_.GetColumn(i).GetType()));
      }
      // 创建连接元组
      *tuple = Tuple(values, &plan_->OutputSchema());
      *rid = {INVALID_PAGE_ID, 0};  // 或生成新RID
      return true;
    }
  
    // 又没找到匹配项，又是内连接，直接获取左表下一行，没结束继续循环
    is_end_ = !child_executor_->Next(&left_tuple_, &left_rid_);
    if (!is_end_) {
      continue;
    }
    //左表没下一行了
    return false;
  }
}

}  // namespace bustub
