//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// external_merge_sort_executor.cpp
//
// Identification: src/execution/external_merge_sort_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/external_merge_sort_executor.h"
#include <iostream>
#include <optional>
#include <vector>
#include "common/config.h"
#include "execution/plans/sort_plan.h"

namespace bustub {

template <size_t K>
ExternalMergeSortExecutor<K>::ExternalMergeSortExecutor(ExecutorContext *exec_ctx, const SortPlanNode *plan,
                                                        std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), cmp_(plan->GetOrderBy()), child_executor_(std::move(child_executor)) {
  order_bys_ = plan->GetOrderBy();
  bpm_ = exec_ctx->GetBufferPoolManager();
  
  if(!runs_.empty()){
    for(auto run : runs_){
      run->Drop();
    }
    runs_.clear();
  }

  // 计算每个sortpage能存的元组数
  int TUPLE_SIZE = plan->OutputSchema().GetInlinedStorageSize();
  int KEY_SIZE = CulKeysize();
  SORT_PAGE_SLOT_CNT = (BUSTUB_PAGE_SIZE - SORT_PAGE_HEADER_SIZE) / (KEY_SIZE + TUPLE_SIZE);

  // auto child_ctx_ = child_executor_->GetExecutorContext();
  // child_ctx_->GetNLJCheckExecutorSet
  // auto table_oid = plan->GetChildPlan()->OutputSchema().GetTableOid();
  // table_info_ = child_ctx_->GetCatalog()->GetTable(table_oid);
  // if (table_info_ == nullptr) {  // 找不到这个表，但是在进入前应该会检查
  //   throw ExecutionException("Table not found");
  // }
  // table_heap_ = table_info_->table_.get();
  sort_page_ids_.clear();
}

/** Initialize the external merge sort */
template <size_t K>
void ExternalMergeSortExecutor<K>::Init() {
  //初始化子执行器
  child_executor_->Init();

  if (!runs_.empty()) {
    for (auto run : runs_) {
      run->Drop();
    }
    runs_.clear();
  }

  //用sortpage存放子执行器的所有元组
  page_id_t current_page_id = bpm_->NewPage();
  if(current_page_id == INVALID_PAGE_ID) {
    throw Exception("No more pages");
  }
  auto writeguard = bpm_->WritePage(current_page_id);
  auto sortpage = writeguard.AsMut<SortPage>();
  
  
  
  Tuple tuple;
  RID rid;
  bool has_next = 0;
  
  while(child_executor_->Next(&tuple, &rid)){
    has_next = 1;
    if(sortpage->IsFull(SORT_PAGE_SLOT_CNT)){
      // 把当前的sortpage放入sortpage_ids中
      sort_page_ids_.push_back(current_page_id);
      //如果满了，就先进行排序
      sortpage->Sort(cmp_);

      writeguard.Flush();
      writeguard.Drop();

      // if (current_page_id == 173) {
      //   auto read_guard1 = bpm_->ReadPage(173);
      //   auto sortpage1 = read_guard1.As<SortPage>();
      //   std::cout << "111Page id: " << current_page_id << std::endl;
      //   std::cout << "--" << sortpage1->GetTupleCount() << "----------------------" << std::endl;
      // }
      
      //再分配一个新的sortpage
      current_page_id = bpm_->NewPage();
      if(current_page_id == INVALID_PAGE_ID) {
        throw Exception("No more pages");
      }
      
      
      writeguard = bpm_->WritePage(current_page_id);
      sortpage = writeguard.AsMut<SortPage>();

      
    }
    
    //把当前的tuple放入sortpage中
    auto sortkey = GenerateSortKey(tuple, order_bys_, child_executor_->GetOutputSchema());
    sortpage->Insert(sortkey, tuple);
  }
  
  
  
  if(has_next == 0){
    //如果没有元组，就直接返回
    return;
  }
  
  //把最后一个没满的sortpage也进行排序
  sort_page_ids_.push_back(current_page_id);
  sortpage->Sort(cmp_);
  //释放写锁
  sortpage = nullptr;
  writeguard.Drop();
  
  //将所有sortpage放入runs中
  for(auto page_id : sort_page_ids_){
    // if(page_id == 173) {
    //   std::cout << "Page id: " << page_id << std::endl;
    // }
    MergeSortRun *run = new MergeSortRun({page_id}, bpm_);
    runs_.push_back(run);
  }
  std::vector<MergeSortRun *> new_runs;
  //下面进行归并排序,记得不断释放指针
  while(runs_.size() > 1){
    
    for(size_t i = 0; i < runs_.size(); i+=2){
      if(i+1 < runs_.size()){
        //两个归并
        MergeSortRun *run1 = runs_[i];
        MergeSortRun *run2 = runs_[i+1];
        //进行归并
        auto merged_run = Merge(run1, run2);


        new_runs.push_back(merged_run);
      }else{
        //单个归并
        new_runs.push_back(runs_[i]);
      }
    }
    // 释放旧的runs
    runs_.clear();
    runs_.resize(0);

    runs_ = std::move(new_runs);
    
    new_runs.clear();
    new_runs.resize(0);
  }
    
  
  runs_[0]->current_iter_ = runs_[0]->Begin();

  sort_page_ids_.clear();
}


/**
 * Yield the next tuple from the external merge sort.
 * @param[out] tuple The next tuple produced by the external merge sort.
 * @param[out] rid The next tuple RID produced by the external merge sort.
 * @return `true` if a tuple was produced, `false` if there are no more tuples
 */
template <size_t K>
auto ExternalMergeSortExecutor<K>::Next(Tuple *tuple, RID *rid) -> bool {
  if (runs_.empty()) {
    return false;
  }
  else if(runs_.size()>1){
    throw ExecutionException("error");
  }
  //获取当前的run
  MergeSortRun *current_run = runs_.back();
  
  //如果当前的迭代器已经到达末尾，就返回false
  if ((current_run->current_iter_) == current_run->End()) {
    return false;
  }
  //获取当前的sortentry
  SortEntry sortentry = *(current_run->current_iter_);
  *tuple = (sortentry.second);
  //获取对应的rid
  *rid = tuple->GetRid();
  
  ++(current_run->current_iter_);
  return true;
  // return false;
}

/**
 * Calculate the key size based on the order by expressions.
 * @return The key size
 */
template <size_t K>
auto ExternalMergeSortExecutor<K>::CulKeysize() -> uint8_t {
  uint8_t key_size = 0;
  for (const auto &order_by : order_bys_) {
    TypeId type = order_by.second->GetReturnType().GetType();
    uint8_t typesize = 0;
    switch (type) {
      case TypeId::BOOLEAN:
      case TypeId::TINYINT:
        typesize = 1;
        break;
      case TypeId::SMALLINT:
        typesize = 2;
        break;
      case TypeId::INTEGER:
        typesize = 4;
        break;
      case TypeId::BIGINT:
      case TypeId::DECIMAL:
      case TypeId::TIMESTAMP:
        typesize = 8;
        break;
      default: {
        UNREACHABLE("Cannot get size of invalid type");
      }
    }
    key_size += typesize;
  }
  return key_size;
}

/**
 * Merge two sorted runs into a new sorted run.
 * @param run1 The first sorted run
 * @param run2 The second sorted run
 * @return A new sorted run that contains the merged tuples from run1 and run2
 */
template <size_t K>
auto ExternalMergeSortExecutor<K>::Merge(MergeSortRun *run1, MergeSortRun *run2) -> MergeSortRun *{
  MergeSortRun *merged_run = new MergeSortRun({},bpm_);
  
  auto it1 = run1->Begin();
  auto it2 = run2->Begin();
  auto end1 = run1->End();
  auto end2 = run2->End();
  while (it1 != end1 && it2 != end2) {
    if (cmp_(*it1, *it2)) {
      merged_run->Insert(*it1, SORT_PAGE_SLOT_CNT);
      ++it1;
    } else {
      merged_run->Insert(*it2, SORT_PAGE_SLOT_CNT);
      ++it2;
    }
  }
  if(it1 != end1) {
    //释放掉run2
    run2->Drop();
    while(it1 != end1){
      merged_run->Insert(*it1, SORT_PAGE_SLOT_CNT);
      ++it1;
    }
    run1->Drop();
  }
  else{
    //释放掉run1
    run1->Drop();
    while(it2 != end2){
      merged_run->Insert(*it2, SORT_PAGE_SLOT_CNT);
      ++it2;
    }
    run2->Drop();
  }
  //确定释放两个run
  return merged_run;
}

void SortPage::Sort(TupleComparator cmp){
  //这里用快速排序
  std::sort(array_.begin(), array_.end(), cmp);
}

auto SortPage::Insert(SortKey sort_key,Tuple tuple) -> bool{
  array_.push_back(std::make_pair(sort_key, tuple));
  tuple_count_++;
  return true;
}

auto SortPage::Insert(SortEntry sortentry) -> bool {
  array_.push_back(sortentry);
  tuple_count_++;
  return true;
}

bool MergeSortRun::Insert(SortEntry sortentry, int SORT_PAGE_SLOT_CNT) {
  if(pages_.empty()){//如果一开始什么页面都没有
    auto page_id = bpm_->NewPage();
    if (page_id == INVALID_PAGE_ID) {
      return false;
    }
    // if (page_id == 173) {
    //   std::cout << "New page id: " << page_id << std::endl;
    // }
    pages_.push_back(page_id);
  }
  
  auto page_id = pages_.back();
  auto write_guard = bpm_->WritePage(page_id);
  auto sortpage = write_guard.AsMut<SortPage>();
  if (sortpage->IsFull(SORT_PAGE_SLOT_CNT)) {//如果已经满了，就加叶
    write_guard.Flush();
    write_guard.Drop();

    auto new_page_id = bpm_->NewPage();
    if (new_page_id == INVALID_PAGE_ID) {
      return false;
    }
    pages_.push_back(new_page_id);
    
    write_guard = bpm_->WritePage(new_page_id);
    sortpage = write_guard.AsMut<SortPage>();
    sortpage->Insert(sortentry);
    write_guard.Drop();
  }
  else{//如如果美满，就直接插入最后的page中
    sortpage->Insert(sortentry);
    write_guard.Drop();
  }
  tuple_count_++;
  return true;
}

template class ExternalMergeSortExecutor<2>;

}  // namespace bustub
