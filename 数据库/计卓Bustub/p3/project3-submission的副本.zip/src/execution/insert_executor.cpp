//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// insert_executor.cpp
//
// Identification: src/execution/insert_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <memory>

#include "execution/executors/insert_executor.h"

namespace bustub {

/**
 * Construct a new InsertExecutor instance.
 * @param exec_ctx The executor context
 * @param plan The insert plan to be executed
 * @param child_executor The child executor from which inserted tuples are pulled
 */
InsertExecutor::InsertExecutor(ExecutorContext *exec_ctx, const InsertPlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan), child_executor_(std::move(child_executor)) {
  table_info_ = exec_ctx_->GetCatalog()->GetTable(plan_->GetTableOid());
  if (table_info_ == nullptr) {  // 找不到这个表，但是在进入前应该会检查
    throw ExecutionException("Table not found");
  }

  // 如果没有索引就是空
  index_info_ = exec_ctx_->GetCatalog()->GetTableIndexes(table_info_->name_);
    }

/** Initialize the insert */
void InsertExecutor::Init() {
  // throw NotImplementedException("InsertExecutor is not implemented");
  //这里init到底要干什么？？？
  }

/**
 * Yield the number of rows inserted into the table.
 * @param[out] tuple The integer tuple indicating the number of rows inserted into the table
 * @param[out] rid The next tuple RID produced by the insert (ignore, not used)
 * @return `true` if a tuple was produced, `false` if there are no more tuples
 *
 * NOTE: InsertExecutor::Next() does not use the `rid` out-parameter.
 * NOTE: InsertExecutor::Next() returns true with number of inserted rows produced only once.
 */
//[[maybe_unused]] Tuple *tuple
auto InsertExecutor::Next(Tuple *tuple, RID *rid) -> bool { 
  TableHeap *table_heap = table_info_->table_.get();
  if (has_produced_output_) {
    return false;
  }
  Tuple inserted_tuple;
  RID inserted_rid;
  //插入，直到没有元组为止
  while (child_executor_->Next(&inserted_tuple, &inserted_rid)) {

    // meta构造里面说，ts在project3的时候设置为0
    auto rid = table_heap->InsertTuple({0, false}, 
                                        inserted_tuple, exec_ctx_->GetLockManager(), exec_ctx_->GetTransaction(),
                                        plan_->GetTableOid());
    if (!rid.has_value()|| rid.value().GetPageId()== INVALID_PAGE_ID) {//插入失败了
      continue;
    }

    // 获取插入的RID
    RID rid_v = rid.value();

    // 更新索引（如果有）
    for (auto &index : index_info_) {
      // 构建索引键
      std::vector<Value> key_values;
      const auto &key_attrs = index->index_->GetKeyAttrs();

      for (const auto col_idx : key_attrs) {
        key_values.push_back(inserted_tuple.GetValue(&table_info_->schema_, col_idx));
      }

      // 创建索引键元组
      Tuple key_tuple = inserted_tuple.KeyFromTuple(table_info_->schema_, index->key_schema_, key_attrs);

      // 插入索引
      index->index_->InsertEntry(key_tuple, rid_v, exec_ctx_->GetTransaction());
    }

    rows_inserted_num++;  // 增加计数
  }

  if(has_produced_output_) {
    return false;
  }
  // ===== 创建结果元组 =====
  // 1. 创建包含行数的 Value 对象
  std::vector<Value> values;
  values.emplace_back(Value(INTEGER, rows_inserted_num));
  // 2. 使用 Value 和输出模式创建 Tuple
  *tuple = Tuple(values, &plan_->OutputSchema());

  has_produced_output_ = true;  // 标记为已产生输出
  return true;
   }

}  // namespace bustub
