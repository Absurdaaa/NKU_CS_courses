//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// delete_executor.cpp
//
// Identification: src/execution/delete_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <memory>

#include "execution/executors/delete_executor.h"

namespace bustub {

/**
 * Construct a new DeleteExecutor instance.
 * @param exec_ctx The executor context
 * @param plan The delete plan to be executed
 * @param child_executor The child executor that feeds the delete
 */
DeleteExecutor::DeleteExecutor(ExecutorContext *exec_ctx, const DeletePlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx), plan_(plan),child_executor_(std::move(child_executor)) {}

/** Initialize the delete */
void DeleteExecutor::Init() {
  // throw NotImplementedException("DeleteExecutor is not implemented");
  table_info_ = exec_ctx_->GetCatalog()->GetTable(plan_->GetTableOid());
  if (table_info_ == nullptr) {  // 找不到这个表，但是在进入前应该会检查
    throw ExecutionException("Table not found");
  }
  // 如果没有索引就是空
  index_info_ = exec_ctx_->GetCatalog()->GetTableIndexes(table_info_->name_);
  table_heap_ = table_info_->table_.get();
  }

/**
 * Yield the number of rows deleted from the table.
 * @param[out] tuple The integer tuple indicating the number of rows deleted from the table存被删除的行数
 * @param[out] rid The next tuple RID produced by the delete (ignore, not used)
 * @return `true` if a tuple was produced, `false` if there are no more tuples
 *
 * NOTE: DeleteExecutor::Next() does not use the `rid` out-parameter.
 * NOTE: DeleteExecutor::Next() returns true with the number of deleted rows produced only once.
 */
auto DeleteExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  if (has_produced_output_) {//如果已经输出过了，就不需要再输出了
    return false;
  }
  Tuple deleted_tuple;
  RID deleted_rid;
  //知道没有元组可以删除为止
  while (child_executor_->Next(&deleted_tuple, &deleted_rid)) {
    TupleMeta deleted_meta = table_heap_->GetTupleMeta(deleted_rid);
    if(deleted_meta.is_deleted_) { // 如果已经删除了，就不需要再删除了
      continue;
    }
    // 删除元组,更新表里面的meta信息
    deleted_meta.is_deleted_ = true;
    table_heap_->UpdateTupleMeta(deleted_meta, deleted_rid);
    // 更新索引表
    for (auto &index_info : index_info_) {
      auto index = index_info->index_.get();
      auto table_schema = table_info_->schema_;
      auto key_schema = index_info->key_schema_;
      auto key = deleted_tuple.KeyFromTuple(table_schema,key_schema, index->GetKeyAttrs());
      index->DeleteEntry(key, deleted_rid, exec_ctx_->GetTransaction());
    }
    rows_deleted_num++;
  }
  if(has_produced_output_) {
    return false;
  }
  if(rows_deleted_num >= 0) {
    // 构造输出的元组
    std::vector<Value> values;
    values.emplace_back(Value(INTEGER, rows_deleted_num));
    *tuple = Tuple(values, &plan_->OutputSchema());
    has_produced_output_ = true;
    return true;
  }
  return false; 
}

}  // namespace bustub
