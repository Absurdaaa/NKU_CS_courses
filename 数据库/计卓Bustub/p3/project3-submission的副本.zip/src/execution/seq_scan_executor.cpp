//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// seq_scan_executor.cpp
//
// Identification: src/execution/seq_scan_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/seq_scan_executor.h"

namespace bustub {

/**
 * Construct a new SeqScanExecutor instance.
 * @param exec_ctx The executor context
 * @param plan The sequential scan plan to be executed
 */
SeqScanExecutor::SeqScanExecutor(ExecutorContext *exec_ctx, const SeqScanPlanNode *plan) : AbstractExecutor(exec_ctx),plan_(plan) {
  TableHeap *table_heap = exec_ctx_->GetCatalog()->GetTable(plan_->GetTableOid())->table_.get();
  //这里重复构造了临时的table_iter_，导致计算变多
  table_iter_ = new TableIterator(table_heap, table_heap->MakeIterator().GetRID(), table_heap->MakeIterator().GetStop_at_rid_());
}

/** Initialize the sequential scan */
void SeqScanExecutor::Init() {
  TableHeap *table_heap = exec_ctx_->GetCatalog()->GetTable(plan_->GetTableOid())->table_.get();
  // 这里重复构造了临时的table_iter_，导致计算变多
  //  throw NotImplementedException("SeqScanExecutor is not implemented");
  table_iter_ = new TableIterator(table_heap, table_heap->MakeIterator().GetRID(), table_heap->MakeIterator().GetStop_at_rid_());
  }

/**
 * Yield the next tuple from the sequential scan.
 * @param[out] tuple The next tuple produced by the scan
 * @param[out] rid The next tuple RID produced by the scan
 * @return `true` if a tuple was produced, `false` if there are no more tuples没有更多的时候返回错误
 */
//这里好像没有考虑到filter_predicate_的情况
auto SeqScanExecutor::Next(Tuple *tuple, RID *rid) -> bool { 
  
  if(!table_iter_->IsEnd()) {
    //如果这个被删除了，就下一个
    bool is_delete = table_iter_->GetTuple().first.is_deleted_;
    if(is_delete) {
      ++(*table_iter_);
      return Next(tuple, rid);
    }
    
    *tuple = (table_iter_->GetTuple().second);
    *rid = table_iter_->GetRID();
    ++(*table_iter_);
    
    if (plan_->filter_predicate_ != nullptr) {
      auto predicate = plan_->filter_predicate_;
      auto value = predicate->Evaluate(tuple, plan_->OutputSchema());
      if (!value.IsNull() && value.GetAs<bool>()) {
        return true;
      } else {
        return Next(tuple, rid);
      }
    }
    return true;
  }
  return false;
  }

}  // namespace bustub
