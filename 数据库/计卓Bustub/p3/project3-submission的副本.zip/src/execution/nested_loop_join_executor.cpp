//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// nested_loop_join_executor.cpp
//
// Identification: src/execution/nested_loop_join_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/nested_loop_join_executor.h"
#include "binder/table_ref/bound_join_ref.h"
#include "common/exception.h"
#include "type/value_factory.h"

namespace bustub {

/**
 * Construct a new NestedLoopJoinExecutor instance.
 * @param exec_ctx The executor context
 * @param plan The nested loop join plan to be executed
 * @param left_executor The child executor that produces tuple for the left side of join
 * @param right_executor The child executor that produces tuple for the right side of join
 */
NestedLoopJoinExecutor::NestedLoopJoinExecutor(ExecutorContext *exec_ctx, const NestedLoopJoinPlanNode *plan,
                                               std::unique_ptr<AbstractExecutor> &&left_executor,
                                               std::unique_ptr<AbstractExecutor> &&right_executor)
    : AbstractExecutor(exec_ctx),plan_(plan), left_executor_(std::move(left_executor)), right_executor_(std::move(right_executor)) {
  if ((plan->GetJoinType() == JoinType::LEFT || plan->GetJoinType() == JoinType::INNER)) {
    // Note for 2023 Fall: You ONLY need to implement left join and inner join.
    //只需要实现左连接和内连接
    // throw bustub::NotImplementedException(fmt::format("join type {} not supported", plan->GetJoinType()));
    join_type_ = plan->GetJoinType();
    if (join_type_ == JoinType::LEFT) {
      need_right_match_ = true;
    } else if (join_type_ == JoinType::INNER) {
      need_right_match_ = false;
    }
    // 这里的逻辑是，如果是左连接，就需要右边的匹配；如果是内连接，就不需要右边的匹配
    return;
  }
  throw bustub::NotImplementedException(fmt::format("join type {} not supported", plan->GetJoinType()));
}

/** Initialize the join */
void NestedLoopJoinExecutor::Init() {
  // throw NotImplementedException("NestedLoopJoinExecutor is not implemented");
  // 初始化左右子执行器
  left_executor_->Init();
  right_executor_->Init();

  // 获取第一个左表元组
  is_end_ = !left_executor_->Next(&left_tuple_, &left_rid_);

  // 如果有左表元组，设置状态为需要找右表匹配
  if (!is_end_) {
    need_right_match_ = true;
    has_right_match_ = false;
  }
}

/**
 * Yield the next tuple from the join.
 * @param[out] tuple The next tuple produced by the join
 * @param[out] rid The next tuple RID produced, not used by nested loop join.
 * @return `true` if a tuple was produced, `false` if there are no more tuples.
 */
auto NestedLoopJoinExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  // 如果已经结束，直接返回false
  if (is_end_) {
    return false;
  }

  while (true) {
    // 尝试在右表中找匹配项
    if (need_right_match_) {
      Tuple right_tuple;
      RID right_rid;
      
      //排行榜p2:如果右表是死条件

      // 尝试获取右表下一行
      if (right_executor_->Next(&right_tuple, &right_rid)) {
        // 检查连接条件
        Value join_condition = plan_->Predicate()->EvaluateJoin(&left_tuple_, left_executor_->GetOutputSchema(),
                                                                &right_tuple, right_executor_->GetOutputSchema());
        // 条件满足，创建连接元组
        if (!join_condition.IsNull() && join_condition.GetAs<bool>()) {
          uint32_t left_len = left_executor_->GetOutputSchema().GetColumnCount();
          uint32_t right_len = right_executor_->GetOutputSchema().GetColumnCount();
          has_right_match_ = true;
          std::vector<Value> values;
          // 构建连接结果...从左右表提取值
          values.reserve(plan_->OutputSchema().GetColumnCount());

          for (uint32_t i = 0; i < left_len; ++i) {
            values.push_back(left_tuple_.GetValue(&left_executor_->GetOutputSchema(), i));
          }
          for (uint32_t i = 0; i < right_len; ++i) {
            values.push_back(right_tuple.GetValue(&right_executor_->GetOutputSchema(), i));
          }
          // 创建连接元组
          *tuple = Tuple(values, &plan_->OutputSchema());
          *rid = {INVALID_PAGE_ID,0};  // 或生成新RID
          return true;
        }
        // 不匹配，继续尝试右表下一行
        continue;
      }

      // 右表已经遍历完
      need_right_match_ = false;

      // LEFT JOIN 且右表无匹配项，生成带NULL的结果
      if (join_type_ == JoinType::LEFT && !has_right_match_) {
        uint32_t left_len = left_executor_->GetOutputSchema().GetColumnCount();
        uint32_t right_len = right_executor_->GetOutputSchema().GetColumnCount();

        // 构建左表+NULL值的连接结果
        std::vector<Value> values;
        // ... 填充左表值和右表NULL值
        values.reserve(left_len + right_len);
        for (uint32_t i = 0; i < left_len; ++i) {
          values.push_back(left_tuple_.GetValue(&left_executor_->GetOutputSchema(), i));
        }
        for (uint32_t i = 0; i < right_len; ++i) {
          values.push_back(ValueFactory::GetNullValueByType(right_executor_->GetOutputSchema().GetColumn(i).GetType()));
        }
        // 创建连接元组
        *tuple = Tuple(values, &plan_->OutputSchema());
        *rid = {INVALID_PAGE_ID, 0};  // 或生成新RID
        return true;
      }
    }

    // 获取左表下一行
    if (left_executor_->Next(&left_tuple_, &left_rid_)) {
      // 重置右表执行器,准备新的内循环
      right_executor_->Init();
      need_right_match_ = true;
      has_right_match_ = false;
      continue;
    }

    // 左表也遍历完了，连接结束
    is_end_ = true;
    return false;
  }
}

}  // namespace bustub
