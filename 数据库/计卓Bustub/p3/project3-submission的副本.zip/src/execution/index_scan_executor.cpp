//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// index_scan_executor.cpp
//
// Identification: src/execution/index_scan_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/index_scan_executor.h"

namespace bustub {

/**
 * Creates a new index scan executor.
 * @param exec_ctx the executor context
 * @param plan the index scan plan to be executed
 */
IndexScanExecutor::IndexScanExecutor(ExecutorContext *exec_ctx, const IndexScanPlanNode *plan)
    : AbstractExecutor(exec_ctx), plan_(plan) {
      table_info_ = exec_ctx_->GetCatalog()->GetTable(plan_->GetTableOid()).get();
      
      if (table_info_ == nullptr) {  // 找不到这个表，但是在进入前应该会检查
        throw ExecutionException("Table not found");
      }
      
      table_heap_ = table_info_->table_.get();

      // 获取计划中指定的索引
      auto index_oid = plan_->GetIndexOid();
      index_info_ = exec_ctx_->GetCatalog()->GetIndex(index_oid);

      if (index_info_ == nullptr) {
        throw ExecutionException("Index not found");
      }
      
      
    }

void IndexScanExecutor::Init() {
  result_rids_.clear();
  current_rid_idx_ = 0;

  // 如果有谓词键值，执行点查询
  //TODO: 现在这里需要构建要查询的key
  if (!plan_->pred_keys_.empty()) {
    auto *b_tree_index = dynamic_cast<BPlusTreeIndexForTwoIntegerColumn *>(index_info_->index_.get());
    
    if (b_tree_index == nullptr) {
      throw ExecutionException("Index type is not BPlusTreeIndex");
    }
    
    // 如果有谓词键值，执行点查询
    //后面我们假设的是这里索引只能有一个，所以这里pred_keys_是指 v1=1 or v1=4 的情况
    for (const auto &key : plan_->pred_keys_) {
      std::vector<Value> key_values;
      key_values.push_back(key->Evaluate(nullptr, plan_->OutputSchema()));
    
    //创建键元组
    Tuple key_tuple(key_values, &index_info_->key_schema_);
    //在缩阴术里面查找
    std::vector<RID> result_rids_new;
    b_tree_index->ScanKey(key_tuple, &result_rids_new, exec_ctx_->GetTransaction());
    result_rids_.insert(result_rids_.end(), result_rids_new.begin(), result_rids_new.end());
    }

  } else{
    auto *b_tree_index = dynamic_cast<BPlusTreeIndexForTwoIntegerColumn *>(index_info_->index_.get());
    
    if (b_tree_index == nullptr) {
      throw ExecutionException("Index type is not BPlusTreeIndex");
    }
    
    // 如果没有谓词键值但需要全索引扫描，获取索引迭代器

    for (auto iter = b_tree_index->GetBeginIterator(); !iter.IsEnd(); ++iter) {
      RID tmp = (*iter).second;
      result_rids_.push_back(tmp);
    }
  }

  return;}

auto IndexScanExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  // 处理所有匹配的RID
  while (current_rid_idx_ < result_rids_.size()) {
    // 获取当前RID
    RID curr_rid = result_rids_[current_rid_idx_++];
    
    //检查是否杯删除
    TupleMeta curr_meta = table_heap_->GetTupleMeta(curr_rid);
    if (curr_meta.is_deleted_) {
      continue;
    }

    *tuple = table_heap_->GetTuple(curr_rid).second;
    *rid = curr_rid;

    //如果有微词判断
    if (plan_->filter_predicate_ != nullptr) {
      auto predicate = plan_->filter_predicate_;
      auto value = predicate->Evaluate(tuple, plan_->OutputSchema());
      if (!value.IsNull() && value.GetAs<bool>()) {
        return true;
      } else {
        return Next(tuple, rid);
      }
    }
    return true;
  }

  // 没有更多结果
  return false;
  }

}  // namespace bustub
