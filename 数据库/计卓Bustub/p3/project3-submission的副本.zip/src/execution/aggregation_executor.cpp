//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// aggregation_executor.cpp
//
// Identification: src/execution/aggregation_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <memory>
#include <vector>

#include "execution/executors/aggregation_executor.h"

namespace bustub {

/**
 * Construct a new AggregationExecutor instance.
 * @param exec_ctx The executor context
 * @param plan The insert plan to be executed
 * @param child_executor The child executor from which inserted tuples are pulled (may be `nullptr`)
 */
AggregationExecutor::AggregationExecutor(ExecutorContext *exec_ctx, const AggregationPlanNode *plan,
                                         std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx),
      plan_(plan),
      child_executor_(std::move(child_executor)),
      aht_(plan->GetAggregates(), plan->GetAggregateTypes()),
      aht_iterator_(aht_.Begin()) {}

/** Initialize the aggregation */
void AggregationExecutor::Init() {
  // 初始化子执行器
  child_executor_->Init();

  // 构建聚合哈希表（注意：聚合是管道阻断器，所以在Init阶段就构建好哈希表）
  aht_.Clear();  // 清空哈希表

  Tuple tuple;
  RID rid;
  bool has_tuple=0;
  // Initialize the aggregation hash table
  while (child_executor_->Next(&tuple, &rid)) {
    has_tuple = 1;
        //遍历要查询的表
        //查询表中每个元组的值都提取出来
    AggregateKey aggrkey = MakeAggregateKey(&tuple);
    AggregateValue aggrvalue = MakeAggregateValue(&tuple);
    //然后把每个元组的值都放到hash表中
    aht_.InsertCombine(aggrkey, aggrvalue);
  }
  if (!has_tuple && plan_->GetGroupBys().empty()) {
    // 创建空的聚合键（没有分组条件时）
    AggregateKey empty_key({});
    // 创建初始聚合值
    AggregateValue initial_agg_val = aht_.GenerateInitialAggregateValue();
    // 直接插入初始值，不要合并，避免COUNT(*)值被误加1
    aht_.InsertDirect(empty_key, initial_agg_val);
  }

  aht_iterator_ = aht_.Begin();
  
}

/**
 * Yield the next tuple from the insert.
 * @param[out] tuple The next tuple produced by the aggregation
 * @param[out] rid The next tuple RID produced by the aggregation
 * @return `true` if a tuple was produced, `false` if there are no more tuples
 */
auto AggregationExecutor::Next(Tuple *tuple, RID *rid) -> bool {
  if (aht_iterator_ == aht_.End()) {
      return false;
    }
  std::vector<Value> values;
  values.reserve(aht_iterator_.Val().aggregates_.size()+aht_iterator_.Key().group_bys_.size());
  for (const auto &group_by : aht_iterator_.Key().group_bys_) {
    values.emplace_back(group_by);
  }
  for (const auto &agg : aht_iterator_.Val().aggregates_) {
    values.emplace_back(agg);
  }
  *tuple = Tuple(values, &plan_->OutputSchema());
  *rid = RID(INVALID_PAGE_ID, 0);
  ++aht_iterator_;
  has_produced_output_ = true;
  return true;
  }

/** Do not use or remove this function, otherwise you will get zero points. */
auto AggregationExecutor::GetChildExecutor() const -> const AbstractExecutor * { return child_executor_.get(); }

}  // namespace bustub
