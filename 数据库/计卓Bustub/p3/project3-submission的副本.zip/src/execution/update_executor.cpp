//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// update_executor.cpp
//
// Identification: src/execution/update_executor.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <memory>

#include "execution/executors/update_executor.h"

namespace bustub {

/**
 * Construct a new UpdateExecutor instance.
 * @param exec_ctx The executor context
 * @param plan The update plan to be executed
 * @param child_executor The child executor that feeds the update
 */
UpdateExecutor::UpdateExecutor(ExecutorContext *exec_ctx, const UpdatePlanNode *plan,
                               std::unique_ptr<AbstractExecutor> &&child_executor)
    : AbstractExecutor(exec_ctx),plan_(plan), child_executor_(std::move(child_executor)) {
  // As of Fall 2022, you DON'T need to implement update executor to have perfect score in project 3 / project 4.
  table_info_ = exec_ctx_->GetCatalog()->GetTable(plan_->GetTableOid()).get();
  if (table_info_ == nullptr) {  // 找不到这个表，但是在进入前应该会检查
    throw ExecutionException("Table not found");
  }
  // 如果没有索引就是空
  index_info_ = exec_ctx_->GetCatalog()->GetTableIndexes(table_info_->name_);
  table_heap_ = table_info_->table_.get();
}

/** Initialize the update */
void UpdateExecutor::Init() { 
  // throw NotImplementedException("UpdateExecutor is not implemented"); 
  child_executor_->Init();
  }

/**
 * Yield the next tuple from the update.
 * @param[out] tuple The next tuple produced by the update
 * @param[out] rid The next tuple RID produced by the update (ignore this)
 * @return `true` if a tuple was produced, `false` if there are no more tuples
 *
 * NOTE: UpdateExecutor::Next() does not use the `rid` out-parameter.
 */
auto UpdateExecutor::Next(Tuple *tuple, RID *rid) -> bool { 
  if(has_produced_output_) {
    return false;
  }
  std::vector<AbstractExpressionRef>  AERs = plan_->target_expressions_;
  Tuple updated_tuple;  // 是用这个装更新后的值吗？
  RID updated_rid;
  //知道没有元组可以更新为止
  while (child_executor_->Next(&updated_tuple, &updated_rid)) {
    TupleMeta updated_meta = table_heap_->GetTupleMeta(updated_rid);
    if(updated_meta.is_deleted_) { // 如果已经删除了，就无法更新了
      continue;
    }
    //先删除
    updated_meta.is_deleted_ = true;
    table_heap_->UpdateTupleMeta(updated_meta, updated_rid);
    //然后再插入新的元祖
    std::vector<Value> values;
    auto schema = table_info_->schema_;
    // int column_num = schema.GetColumnCount();
    // for (int i = 0; i < column_num; i++) {
    //   auto column = schema.GetColumn(i);
    //   auto column_name = column.GetName();
    //   auto value = updated_tuple.GetValue(&schema,i);
    //   values.push_back(value);
    // }

    for(auto AER : AERs) {
      //返回一个Column对象，里面包含了更新列的名字以及类型
      //如果是set的值，会直接返回值，如果是非set的值，会返回updatetuple里面对应位置的值（也就是不修改的值
      auto value = AER->Evaluate(&updated_tuple, schema);
      //塞入更新的值，但是更新的值在什么地方？
      values.push_back(value);
    }

    Tuple new_tuple(values, &schema);
    auto rid_op = table_heap_->InsertTuple({0, false}, new_tuple, exec_ctx_->GetLockManager(), exec_ctx_->GetTransaction(),
                                       plan_->GetTableOid());
    if (!rid_op.has_value() || rid_op.value().GetPageId() == INVALID_PAGE_ID) {  // 插入失败了
      continue;
    }
    auto new_rid = rid_op.value();

    //更新索引
    auto table_schema = table_info_->schema_;
    for (const auto &index_info : index_info_) {
      auto index = index_info->index_.get();
      auto key_schema = index_info->key_schema_;
      //先删除旧索引
      auto old_key = updated_tuple.KeyFromTuple(table_schema, key_schema, index->GetKeyAttrs());
      index_info->index_->DeleteEntry(old_key, updated_rid, exec_ctx_->GetTransaction());
      //然后插入新的索引
      auto new_key = new_tuple.KeyFromTuple(table_schema, key_schema, index->GetKeyAttrs());
      index_info->index_->InsertEntry(new_key, new_rid, exec_ctx_->GetTransaction());
    }
    rows_updated_num++;
  }

  if (has_produced_output_) {
    return false;
  }

  std::vector<Value> values;
  values.emplace_back(Value(INTEGER, rows_updated_num));
  // 2. 使用 Value 和输出模式创建 Tuple
  *tuple = Tuple(values, &plan_->OutputSchema());

  has_produced_output_ = true;  // 标记为已产生输出
  return true;
}

}  // namespace bustub
