//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// column_pruning.cpp
//
// Identification: src/optimizer/column_pruning.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/plans/projection_plan.h"
#include "optimizer/optimizer.h"
namespace bustub {

/**
 * @brief column pruning for child plan following a projection plan
 * @param plan the plan to optimize
 * @return the new plan with column pruning
 * @note You may use this function to implement column pruning optimization.
 */
auto Optimizer::OptimizeColumnPruning(const bustub::AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef {
  // // 如果计划是投影计划
  // if (plan->GetType() == PlanType::Projection) {
  //   auto projection_plan = dynamic_cast<const ProjectionPlanNode *>(plan.get());
  //   //需要获取的列数
  //   auto required_columns = 0;

  //   // 获取子计划
  //   auto child_plan = projection_plan->GetChildPlan();

  //   // 递归优化子计划
  //   auto optimized_child_plan = OptimizeColumnPruning(child_plan);

  //   // 修改子计划的输出列，仅保留需要的列
  //   // auto pruned_child_plan = PruneColumns(optimized_child_plan, required_columns);

  //   // 返回新的投影计划
  //   return std::make_shared<ProjectionPlanNode>(projection_plan->output_schema_, pruned_child_plan,
  //                                               required_columns);
  // }
  return plan;
}

// auto Optimizer::PruneColumns();

}  // namespace bustub
