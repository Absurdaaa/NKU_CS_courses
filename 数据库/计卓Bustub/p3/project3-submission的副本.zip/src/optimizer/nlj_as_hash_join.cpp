//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// nlj_as_hash_join.cpp
//
// Identification: src/optimizer/nlj_as_hash_join.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <algorithm>
#include <memory>
#include "catalog/column.h"
#include "catalog/schema.h"
#include "common/exception.h"
#include "common/macros.h"
#include "execution/expressions/column_value_expression.h"
#include "execution/expressions/comparison_expression.h"
#include "execution/expressions/constant_value_expression.h"
#include "execution/expressions/logic_expression.h"
#include "execution/plans/abstract_plan.h"
#include "execution/plans/filter_plan.h"
#include "execution/plans/hash_join_plan.h"
#include "execution/plans/nested_loop_join_plan.h"
#include "execution/plans/projection_plan.h"
#include "optimizer/optimizer.h"
#include "type/type_id.h"

namespace bustub {

/**
 * @brief optimize nested loop join into hash join.
 * In the starter code, we will check NLJs with exactly one equal condition. You can further support optimizing joins
 * with multiple eq conditions.
 */
auto Optimizer::OptimizeNLJAsHashJoin(const AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef {
  // TODO(student): implement NestedLoopJoin -> HashJoin optimizer rule
  // Note for 2023 Fall: You should support join keys of any number of conjunction of equi-conditions:
  // E.g. <column expr> = <column expr> AND <column expr> = <column expr> AND ...
  if (plan == nullptr) return nullptr;
  
  // if (plan->GetType() != PlanType::NestedLoopJoin) return plan;

  // 递归优化子计划节点
  std::vector<AbstractPlanNodeRef> optimized_children;
  for (const auto &child : plan->GetChildren()) {
    optimized_children.push_back(OptimizeNLJAsHashJoin(child));
  }

  // 创建带有优化子节点的新计划
  auto optimized_plan = plan->CloneWithChildren(std::move(optimized_children));
  
  if(optimized_plan->GetType() != PlanType::NestedLoopJoin) return optimized_plan;

  const auto &nlj_plan = dynamic_cast<const NestedLoopJoinPlanNode &>(*optimized_plan);

  // 只处理内连接和左连接
  if (nlj_plan.GetJoinType() != JoinType::INNER && nlj_plan.GetJoinType() != JoinType::LEFT) {
    return optimized_plan;
  }
  
  JoinType join_type = nlj_plan.GetJoinType();
  // 获取join的等值条件
  AbstractExpressionRef predicate = nlj_plan.Predicate();
  // 提取连接键
  std::vector<AbstractExpressionRef> left_keys_exprs;
  std::vector<AbstractExpressionRef> right_keys_exprs;

  bool JoinCondition = ExtractEquiJoinKeys(predicate, nlj_plan.GetLeftPlan()->OutputSchema(), 
                      nlj_plan.GetRightPlan()->OutputSchema(),
                      &left_keys_exprs, &right_keys_exprs);
                      
  if(JoinCondition){//如果提取成功
    // 这里我们假设连接键的数量是相同的
    if (left_keys_exprs.size() != right_keys_exprs.size()) {
      return optimized_plan;
    }
    // HashJoinPlanNode
    return std::make_shared<HashJoinPlanNode>(nlj_plan.output_schema_, nlj_plan.GetLeftPlan(),
                                                            nlj_plan.GetRightPlan(), left_keys_exprs, right_keys_exprs,
                                                            join_type);
    
    
  }

  return optimized_plan;
}

// 从连接谓词中提取等值连接键
auto Optimizer::ExtractEquiJoinKeys(const AbstractExpressionRef &expr, const Schema &left_schema,
                                    const Schema &right_schema, std::vector<AbstractExpressionRef> *left_keys,
                                    std::vector<AbstractExpressionRef> *right_keys) -> bool {
                                      
  const auto *logic_expr = dynamic_cast<const LogicExpression *>(expr.get());
  // 如果是or连接的逻辑表达式，直接返回false
  if(logic_expr != nullptr && logic_expr->logic_type_ == LogicType::Or){
    return false;
  }
  //如果是and连接的逻辑表达式
  if(logic_expr != nullptr && logic_expr->logic_type_ == LogicType::And) {
    // 递归处理AND的左右子表达式
    bool left_success =
        ExtractEquiJoinKeys(logic_expr->children_[0], left_schema, right_schema, left_keys, right_keys);
    bool right_success =
        ExtractEquiJoinKeys(logic_expr->children_[1], left_schema, right_schema, left_keys, right_keys);
    return left_success && right_success;
  }
  // 如果是等值，直接处理
  const auto *comp_expr = dynamic_cast<const ComparisonExpression *>(expr.get());
  if (comp_expr!=nullptr && comp_expr->comp_type_ == ComparisonType::Equal) {
    // 提取两边列值
    const auto *left_col_expr = dynamic_cast<const ColumnValueExpression *>(comp_expr->children_[0].get());
    const auto *right_col_expr = dynamic_cast<const ColumnValueExpression *>(comp_expr->children_[1].get());
    if(left_col_expr == nullptr || right_col_expr == nullptr) {
      return false;
    }
    //判断哪个列属于哪个表
    left_col_expr->GetTupleIdx() == 0 ? left_keys->push_back(comp_expr->children_[0]) : right_keys->push_back(comp_expr->children_[0]);
    right_col_expr->GetTupleIdx() == 0 ? left_keys->push_back(comp_expr->children_[1]) : right_keys->push_back(comp_expr->children_[1]);
    return true;
  }

  return false;
}

}  // namespace bustub
