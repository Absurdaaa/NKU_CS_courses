//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// seqscan_as_indexscan.cpp
//
// Identification: src/optimizer/seqscan_as_indexscan.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/expressions/column_value_expression.h"
#include "execution/expressions/comparison_expression.h"
#include "execution/expressions/constant_value_expression.h"
#include "execution/expressions/logic_expression.h"
#include "execution/plans/index_scan_plan.h"
#include "execution/plans/seq_scan_plan.h"
#include "optimizer/optimizer.h"

namespace bustub {

/**
 * @brief optimize seq scan as index scan if there's an index on a table
 * @note Fall 2023 only: using hash index and only support point lookup
 * 只支持点查询，就是目前只支持对一个属性作为索引的查询，但是要注意v1=1 or v1=4的情况，以及1 =v1的情况
 * groupby的时候这里假设只有一个谓词
 */
auto Optimizer::OptimizeSeqScanAsIndexScan(const bustub::AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef {
  // 递归处理所有子节点
  std::vector<AbstractPlanNodeRef> children;
  for (const auto &child : plan->GetChildren()) {
    children.emplace_back(OptimizeSeqScanAsIndexScan(child));
  }
  auto optimized_plan = plan->CloneWithChildren(std::move(children));

// 检查是否是SeqScan节点且有过滤条件
  if (optimized_plan->GetType() == PlanType::SeqScan) {
    //转换类型为scan
    const auto &seq_scan_plan = dynamic_cast<const SeqScanPlanNode &>(*optimized_plan);
    // 如果存在过率条件
    if (seq_scan_plan.filter_predicate_ != nullptr) {
      // 先检查是不是groupby的查找，这里假设只有一个谓词
      const auto *column_expr = dynamic_cast<const ColumnValueExpression *>(seq_scan_plan.filter_predicate_.get());
      if (column_expr != nullptr) {
        // 获取表的oid
        auto table_oid = seq_scan_plan.GetTableOid();
        // 获取表的schema
        auto schema = seq_scan_plan.OutputSchema();
        // 获取表的列数
        auto col_count = schema.GetColumnCount();
        // 获取列的索引
        auto col_idx = column_expr->GetColIdx();
        // 如果列的索引大于等于表的列数，说明是groupby的查找？？？
        if (col_idx >= col_count) {
          return optimized_plan;
        }
        // 获取索引的oid和名称
        auto index_pair = MatchIndex(seq_scan_plan.table_name_, col_idx);
        // 不是索引，返回原来递归后的seq scan
        if (!index_pair.has_value()) {
          return optimized_plan;
        }
        auto [index_oid, index_name] = *index_pair;
        // 创建索引扫描节点
        return std::make_shared<IndexScanPlanNode>(seq_scan_plan.output_schema_, table_oid, index_oid,
                                                   seq_scan_plan.filter_predicate_, std::vector<AbstractExpressionRef>{});
      }
      //然后我们在检查是不是where点查找==
      
      //这里先要检查是不是or连接或者and连接   v1=1 or v1=4
      //这里不知道怎么拆分谓词，所以碰到and我们就直接返回原plan
      const auto *logic_expr = dynamic_cast<const LogicExpression *>(seq_scan_plan.filter_predicate_.get());
      if (logic_expr != nullptr) {
        // 根据逻辑类型处理
        if (logic_expr->logic_type_ == LogicType::Or) {
          // 用于存储与特定列相关的等值条件
          std::unordered_map<uint32_t, std::vector<Value>> column_values;

          // 递归处理OR表达式，收集所有可能的索引条件
          CollectEqualityConditions(logic_expr, column_values, seq_scan_plan.table_name_);

          // 找出最佳索引列（出现次数最多的有索引列）
          uint32_t best_col_idx = 0;
          size_t max_conditions = 0;
          std::optional<std::pair<index_oid_t, std::string>> best_index;

          for (const auto &[col_idx, values] : column_values) {
            auto index_info = MatchIndex(seq_scan_plan.table_name_, col_idx);
            if (index_info.has_value() && values.size() > max_conditions) {
              best_col_idx = col_idx;
              max_conditions = values.size();
              best_index = index_info;
            }
          }

          // 如果找到可用索引，创建索引扫描节点
          if (best_index.has_value() && max_conditions > 0) {
            auto [index_oid, index_name] = *best_index;

            // 创建谓词键
            std::vector<AbstractExpressionRef> pred_keys;
            for (const auto &val : column_values[best_col_idx]) {
              pred_keys.push_back(std::make_shared<ConstantValueExpression>(val));
            }

            return std::make_shared<IndexScanPlanNode>(seq_scan_plan.output_schema_, seq_scan_plan.GetTableOid(),
                                                       index_oid,
                                                       seq_scan_plan.filter_predicate_,  // 保留完整谓词
                                                       pred_keys);
          }
        }
      }

      //然后在检查没有逻辑词连接的 点查找  v1=1
      const auto *comp_expr = dynamic_cast<const ComparisonExpression *>(seq_scan_plan.filter_predicate_.get());
      if (comp_expr != nullptr && comp_expr->comp_type_ == ComparisonType::Equal) {
        //提取两边的常量和列值
        const auto *col_expr = dynamic_cast<const ColumnValueExpression *>(comp_expr->children_[0].get());
        const auto *const_expr = dynamic_cast<const ConstantValueExpression *>(comp_expr->children_[1].get());
        if(col_expr == nullptr || const_expr == nullptr) {
          col_expr = dynamic_cast<const ColumnValueExpression *>(comp_expr->children_[1].get());
          const_expr = dynamic_cast<const ConstantValueExpression *>(comp_expr->children_[0].get());
        }

        // 我们先获取表中的所有索引
        auto index_infos = catalog_.GetTableIndexes(seq_scan_plan.table_name_);
        // 遍历所有索引
        for (auto index_info : index_infos) {
          // 获取索引的key
          auto key_attrs = index_info->index_->GetKeyAttrs();
          // 这里我们只支持一个key
          if (key_attrs.size() == 1) {
            auto index_key_idx = key_attrs[0];//这个是这个索引在表中在第几行
            if(col_expr->GetColIdx() == index_key_idx) {
              // 获取索引的oid和名称
              auto [index_oid, index_name] = *MatchIndex(seq_scan_plan.table_name_, index_key_idx);
              // 创建索引扫描节点
              std::vector<AbstractExpressionRef> pred_keys;
              pred_keys.push_back(std::make_shared<ConstantValueExpression>(const_expr->val_));
              return std::make_shared<IndexScanPlanNode>(seq_scan_plan.output_schema_, seq_scan_plan.GetTableOid(),
                                                         index_oid, seq_scan_plan.filter_predicate_, pred_keys);
            }
          }
        }
      }
    }
  }
  return optimized_plan;

}

/**
 * @brief check if the expression is a comparison expression,然后提取索引并遍历表得到索引的oid和名称
 * @param expr comp or logic？
 * @param index_oid the index oid
 * @param pred_keys the predicate keys
 * @return the index oid and name
 */
// auto Optimizer::CheckCompexpr(const AbstractExpressionRef &expr, std::string table_name, index_oid_t index_oid,
//                               std::vector<AbstractExpressionRef> &pred_keys) -> std::optional<index_oid_t> {
//   AbstractExpressionRef expr_copy;
//   *expr_copy = *expr;
//   // 1. 先检查是不是comp
//   const auto comp_expr = dynamic_cast<const ComparisonExpression *>(expr_copy.get());
//   if (comp_expr != nullptr && comp_expr->comp_type_ == ComparisonType::Equal) {
//     // 提取两边的常量和列值
//     const auto *col_expr = dynamic_cast<const ColumnValueExpression *>(comp_expr->children_[0].get());
//     const auto *const_expr = dynamic_cast<const ConstantValueExpression *>(comp_expr->children_[1].get());
//     if (col_expr == nullptr) {
//       col_expr = dynamic_cast<const ColumnValueExpression *>(comp_expr->children_[1].get());
//       const_expr = dynamic_cast<const ConstantValueExpression *>(comp_expr->children_[0].get());
//     }

//     // 我们先获取表中的所有索引
//     auto index_infos = catalog_.GetTableIndexes(table_name);
//     // 遍历所有索引
//     for (auto index_info : index_infos) {
//       // 获取索引的key
//       auto key_attrs = index_info->index_->GetKeyAttrs();
//       // 这里我们只支持一个key
//       if (key_attrs.size() == 1) {
//         auto index_key_idx = key_attrs[0];  // 这个是这个索引在表中在第几行
//         if (col_expr->GetColIdx() == index_key_idx) {
//           // 获取索引的oid和名称
//           auto [index_oid, index_name] = *MatchIndex(table_name, index_key_idx);
//           // 创建索引扫描节点
//           pred_keys.push_back(std::make_shared<ConstantValueExpression>(const_expr->val_));
//           return std::make_optional(index_oid);
//         }
//       }
//     }
//   }
//   return std::nullopt;
// }

// void Optimizer::DFSLogicExpr(const AbstractExpressionRef &expr, std::vector<AbstractExpressionRef> &pred_keys,index_oid_t index_oid) {
//     AbstractExpressionRef expr_copy;
//     *expr_copy = *expr;
//     const auto login_expr = dynamic_cast<const LogicExpression *>(expr_copy.get());
//     if (login_expr!=nullptr){
//       //如何是and连接，直接回家
//       if (login_expr->logic_type_ == LogicType::And) {
//         return std::nullopt;
//       }
//       //如果是or连接，递归遍历
//       for (auto child : login_expr->children_) {
//         auto index_oid = DFSLogicExpr(child, pred_keys, index_oid);

//       }
//     }
//     return std::nullopt;
//     }

// 递归收集OR表达式中的所有等值条件
auto Optimizer::CollectEqualityConditions(const LogicExpression *expr, 
                              std::unordered_map<uint32_t, std::vector<Value>> &column_values,
                              const std::string &table_name)->void {
  // 如果是OR表达式，递归处理两个子节点
  if (expr->logic_type_ == LogicType::Or) {
    for (const auto &child : expr->children_) {
      // 子节点可能是另一个逻辑表达式
      if (const auto *child_logic = dynamic_cast<const LogicExpression *>(child.get())) {
        CollectEqualityConditions(child_logic, column_values, table_name);
      } 
      
      // 或者是比较表达式
      else if (const auto *comp = dynamic_cast<const ComparisonExpression *>(child.get())) {
        if (comp->comp_type_ == ComparisonType::Equal) {
          // 提取列和常量
          const auto *col_expr = dynamic_cast<const ColumnValueExpression *>(comp->children_[0].get());
          const auto *const_expr = dynamic_cast<const ConstantValueExpression *>(comp->children_[1].get());
          
          // 尝试反向形式
          if (col_expr == nullptr || const_expr == nullptr) {
            col_expr = dynamic_cast<const ColumnValueExpression *>(comp->children_[1].get());
            const_expr = dynamic_cast<const ConstantValueExpression *>(comp->children_[0].get());
          }
          
          // 如果找到列=常量形式
          if (col_expr != nullptr && const_expr != nullptr) {
            column_values[col_expr->GetColIdx()].push_back(const_expr->val_);
          }
        }
      }
    }
  }
  else if(expr->logic_type_ == LogicType::And) {
    // 如果是AND表达式，递归处理两个子节点
    for (const auto &child : expr->children_) {
      // 子节点可能是另一个逻辑表达式
      if (const auto *child_logic = dynamic_cast<const LogicExpression *>(child.get())) {
        CollectEqualityConditions(child_logic, column_values, table_name);
      } 
      
      // 或者是比较表达式
      else if (const auto *comp = dynamic_cast<const ComparisonExpression *>(child.get())) {
        if (comp->comp_type_ == ComparisonType::Equal) {
          // 提取列和常量
          const auto *col_expr = dynamic_cast<const ColumnValueExpression *>(comp->children_[0].get());
          const auto *const_expr = dynamic_cast<const ConstantValueExpression *>(comp->children_[1].get());
          
          // 尝试反向形式
          if (col_expr == nullptr || const_expr == nullptr) {
            col_expr = dynamic_cast<const ColumnValueExpression *>(comp->children_[1].get());
            const_expr = dynamic_cast<const ConstantValueExpression *>(comp->children_[0].get());
          }
          
          // 如果找到列=常量形式
          if (col_expr != nullptr && const_expr != nullptr) {
            column_values[col_expr->GetColIdx()].push_back(const_expr->val_);
          }
        }
      }
    }
  }
}

}  // namespace bustub
