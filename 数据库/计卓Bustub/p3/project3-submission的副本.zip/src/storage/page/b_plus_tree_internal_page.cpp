//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// b_plus_tree_internal_page.cpp
//
// Identification: src/storage/page/b_plus_tree_internal_page.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <iostream>
#include <sstream>

#include "common/exception.h"
#include "storage/page/b_plus_tree_internal_page.h"

namespace bustub {
/*****************************************************************************
 * HELPER METHODS AND UTILITIES
 *****************************************************************************/

/**
 * @brief Init method after creating a new internal page.
 *
 * Writes the necessary header information to a newly created page,
 * including set page type, set current size, set page id, set parent id and set max page size,
 * must be called after the creation of a new page to make a valid BPlusTreeInternalPage.
 *
 * @param max_size Maximal size of the page
 */
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::Init(int max_size) {
  //基础设置
  SetPageType(IndexPageType::INTERNAL_PAGE);
  SetSize(0);
  SetMaxSize(max_size);
  for(int i = 0; i < max_size; i++) {
    page_id_array_[i] = INVALID_PAGE_ID;
  }
  for (int i = 0; i < max_size; i++) {
    key_array_[i] = KeyType();  // 初始化键数组
  }
}

/**
 * @brief Helper method to get/set the key associated with input "index"(a.k.a
 * array offset).
 *
 * @param index The index of the key to get. Index must be non-zero.下标非零
 * @return Key at index
 */
INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_INTERNAL_PAGE_TYPE::KeyAt(int index) const -> KeyType {
  if(index<=0||index>=GetSize()){
    BUSTUB_ASSERT(false, "Index out of range");
  }
  //key是从1开始记录的
  return key_array_[index];
}

/**
 * @brief Set key at the specified index.
 *
 * @param index The index of the key to set. Index must be non-zero.
 * @param key The new value for key
 */
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::SetKeyAt(int index, const KeyType &key) {
  if(index<=0||index>=GetSize()){
    BUSTUB_ASSERT(false, "Index out of range");
  }
  key_array_[index] = key;
}

INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_INTERNAL_PAGE_TYPE::ValueIndex(const ValueType &page_id) const -> int {
  for (int i = 0; i < GetSize(); i++) {
    if (page_id_array_[i] == page_id) {
      return i;
    }
  }
  return -1;
}

INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_INTERNAL_PAGE_TYPE::Lookup(const KeyType &key, const KeyComparator &comparator) const -> int {
  // // 改为二分查找，提高查找准确性
  if (GetSize() == 1) {
    //叶节点不可能只有有一个儿子
    abort();
    return 0;  // 只有一个子节点时直接返回
  }
  
  // // 从索引1开始，因为第一个键是无效的
  // int left = 1;
  // int right = GetSize() - 1;
  
  // // 如果小于第一个有效键，返回第一个子节点
  // if (comparator(key, KeyAt(1)) < 0) {
  //   return 0;
  // }
  
  // // 如果大于等于最后一个键，返回最后一个子节点
  // if (comparator(key, KeyAt(right)) >= 0) {
  //   return right;
  // }
  
  // // 二分查找第一个大于key的键的位置
  // while (left < right) {
  //   int mid = left + (right - left) / 2;
  //   if (comparator(key, KeyAt(mid)) < 0) {
  //     right = mid;
  //   } else {
  //     left = mid + 1;
  //   }
  // }
  // // 返回前一个子节点
  // return left - 1;
  
  for(int i = 1; i < GetSize(); i++) {
    if (comparator(key, KeyAt(i)) < 0) {
      return i - 1;
    }
  }
  return GetSize() - 1;  // 如果key大于所有键，返回最后一个子节点
}

/**
 * @brief Helper method to get the value associated with input "index"(a.k.a array
 * offset)
 *
 * @param index The index of the value to get.
 * @return Value at index
 */
INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_INTERNAL_PAGE_TYPE::ValueAt(int index) const -> ValueType {
  if(index>=GetSize()||index>=GetMaxSize()||index<0){
    BUSTUB_ASSERT(false, "Index out of range");
  }
  return page_id_array_[index];
}



// 当新建一个内部节点的时候，插入两个值的时候初始化
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::InternalInit(
  const KeyType &key,
  const ValueType left_pageid,
  const ValueType right_pageid)
{
  SetSize(2);
  SetKeyAt(1, key);
  page_id_array_[0] = left_pageid;
  page_id_array_[1] = right_pageid;
  
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::InsertValue(const KeyType &key, ValueType page_id, int index){
  if(index >= GetMaxSize()){
    abort();
  }
  for (int i = GetSize(); i >index; i--) {
    key_array_[i] = key_array_[i-1];
    page_id_array_[i] = page_id_array_[i-1];
  }
  key_array_[index] = key;
  page_id_array_[index] = page_id;
  ChangeSizeBy(1);
  if(GetSize() > GetMaxSize() || GetSize() < GetMinSize()){
    abort();
  }
  return;
}

/**
 * @brief 插入操作
 *
 * @param key 新分裂的右边节点的第一个key
 * @param page_id 新分裂的右边节点的pageid
 * @return Value at index
 */
INDEX_TEMPLATE_ARGUMENTS bool B_PLUS_TREE_INTERNAL_PAGE_TYPE::Insert(const KeyType &key, ValueType page_id,const KeyComparator &comparator_) {
  if(GetSize() >= GetMaxSize()) {//满了
    abort();
    return false;
  }
  int index = 1;
  for(index = 1; index < GetSize(); index++) {
    if(comparator_(key, KeyAt(index)) == -1) {//key比At小
      break;
    }
  }
  ChangeSizeBy(1);
  for(int i = GetSize()-1; i > index; i--) {
    SetKeyAt(i, KeyAt(i - 1));
    page_id_array_[i] = page_id_array_[i - 1];
  }
  SetKeyAt(index, key);
  page_id_array_[index] = page_id;
  
  if (GetSize() > GetMaxSize()) {
    BUSTUB_ASSERT(false, "节点比最小值小");
  }
  
  // //根内部节点不需要保证大于等于于min
  // if (GetSize() > GetMaxSize() || GetSize() < GetMinSize()) {
  //   abort();
  // }
  return true;
}

/**
 * @brief 分裂操作,并操作，返回右边节点最左的key（这里应该是要最底下的key）
 *
 * @param 
 */
INDEX_TEMPLATE_ARGUMENTS
KeyType B_PLUS_TREE_INTERNAL_PAGE_TYPE::Split(KeyType &key, ValueType page_id, B_PLUS_TREE_INTERNAL_PAGE_TYPE *new_page, const KeyComparator &comparator_) {
  // 临时数组来辅助分裂，确保正确处理所有情况
  KeyType temp_keys[GetMaxSize() + 1];
  ValueType temp_values[GetMaxSize() + 1];
  if(GetSize() != GetMaxSize()) {
    BUSTUB_ASSERT(false, "???");
  }

  // 查找新键应该插入的位置
  int index = 1;
  for(; index < GetSize(); index++) {
    if(comparator_(key, KeyAt(index)) == -1) break;
  }

  // 先复制所有现有键值到临时数组
  temp_values[0] = page_id_array_[0];
  for (int i = 1; i < GetSize(); i++) {
    temp_keys[i] = KeyAt(i);
    temp_values[i] = page_id_array_[i];
  }

  // 将新的键值对插入到临时数组的正确位置
  for (int i = GetSize(); i > index; i--) {
    temp_keys[i] = temp_keys[i-1];
    temp_values[i] = temp_values[i-1];
  }
  temp_keys[index] = key;
  temp_values[index] = page_id;

  // 计算数组中的总元素数
  int total_entries = GetSize() + 1;

  // 计算分割点
  int split = GetMinSize();

  // 上移的键是分割点的键
  KeyType ret_key = temp_keys[split];

  // 重新调整原节点，保留左半部分
  SetSize(split);
  for (int i = 0; i < split; i++) {
    if (i == 0) {
      page_id_array_[i] = temp_values[i];
    } else {
      SetKeyAt(i, temp_keys[i]);
      page_id_array_[i] = temp_values[i];
    }
  }

  // 关键修复: 正确设置新节点的第一个子指针
  // 这个指针应该指向中间键的右子树，即 temp_values[split]
  new_page->page_id_array_[0] = temp_values[split];
  
  // 复制其余的键和值到新节点，从split+1开始
  int new_size = total_entries - split - 1;
  new_page->SetSize(new_size + 1);  // +1因为有额外的指针
  
  // 修复: 使用正确的循环边界和索引计算
  for (int i = 0; i < new_size; i++) {
    // 注意: 键从split+1开始，对应新节点的索引从1开始
    new_page->SetKeyAt(i+1, temp_keys[split+1+i]);
    // 指针也相应地从split+1开始
    new_page->page_id_array_[i+1] = temp_values[split+1+i];
  }

  // 安全检查
  BUSTUB_ASSERT(GetSize() >= GetMinSize(), "Left node size too small after split");
  BUSTUB_ASSERT(new_page->GetSize() >= new_page->GetMinSize(), "Right node size too small after split");

  return ret_key;
}

/**
 * @brief 删除操作
 *
 * @param index
 */
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_INTERNAL_PAGE_TYPE::Remove(int index) {
  if(index == 0){
    page_id_array_[0] = page_id_array_[1];
    for(int i=1;i<GetSize()-1;i++){
      SetKeyAt(i,KeyAt(i+1));
      page_id_array_[i] = page_id_array_[i + 1];
    }
  }
  //删除index位置的key
  else{
    for (int i = index; i < GetSize()-1; i++) {
      SetKeyAt(i, KeyAt(i + 1));
      page_id_array_[i] = page_id_array_[i + 1];
    }
  }
  ChangeSizeBy(-1);
  return;
}


// valuetype for internalNode should be page id_t
template class BPlusTreeInternalPage<GenericKey<4>, page_id_t, GenericComparator<4>>;
template class BPlusTreeInternalPage<GenericKey<8>, page_id_t, GenericComparator<8>>;
template class BPlusTreeInternalPage<GenericKey<16>, page_id_t, GenericComparator<16>>;
template class BPlusTreeInternalPage<GenericKey<32>, page_id_t, GenericComparator<32>>;
template class BPlusTreeInternalPage<GenericKey<64>, page_id_t, GenericComparator<64>>;
}  // namespace bustub
