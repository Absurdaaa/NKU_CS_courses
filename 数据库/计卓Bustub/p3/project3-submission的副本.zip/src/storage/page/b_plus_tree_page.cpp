//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// b_plus_tree_page.cpp
//
// Identification: src/storage/page/b_plus_tree_page.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "storage/page/b_plus_tree_page.h"

namespace bustub {

/*
 * Helper methods to get/set page type
 * Page type enum class is defined in b_plus_tree_page.h
 */
//判断是否是叶子页  
auto BPlusTreePage::IsLeafPage() const -> bool {
  if(page_type_ == IndexPageType::LEAF_PAGE)
    return true;
  return false;
}
//设置页类型
void BPlusTreePage::SetPageType(IndexPageType page_type) {
  page_type_  = page_type;
  }

/*
 * Helper methods to get/set size (number of key/value pairs stored in that
 * page)
 */
auto BPlusTreePage::GetSize() const -> int {

  return size_;
}
void BPlusTreePage::SetSize(int size) { size_ = size; }
void BPlusTreePage::ChangeSizeBy(int amount) {
  size_ += amount;
  // if (!IsLeafPage()) {
  //   if(size_<=1){
  //     BUSTUB_ASSERT(false, "Internal page size is less than 1");
  //   }
  // }
  }

/*
 * Helper methods to get/set max size (capacity) of the page
 */
auto BPlusTreePage::GetMaxSize() const -> int { return max_size_; }
void BPlusTreePage::SetMaxSize(int size) { max_size_ = size; }

/*
 * Helper method to get min page size
 * Generally, min page size == max page size / 2
 * But whether you will take ceil() or floor() depends on your implementation
 * 这里根据实际来决定是向上取整还是向下取整
 * 我们这里先决定是向上取整
 */
auto BPlusTreePage::GetMinSize() const -> int { return ceil(max_size_/ 2.0); }

}  // namespace bustub
