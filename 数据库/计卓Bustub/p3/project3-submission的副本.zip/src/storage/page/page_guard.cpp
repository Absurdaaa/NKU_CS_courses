//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// page_guard.cpp
//
// Identification: src/storage/page/page_guard.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "storage/page/page_guard.h"
#include <memory>

namespace bustub {

/**
 * @brief The only constructor for an RAII `ReadPageGuard` that creates a valid guard.
 *
 * Note that only the buffer pool manager is allowed to call this constructor.
 *
 * TODO(P1): Add implementation.
 *
 * @param page_id The page ID of the page we want to read.
 * @param frame A shared pointer to the frame that holds the page we want to protect.
 * @param replacer A shared pointer to the buffer pool manager's replacer.
 * @param bpm_latch A shared pointer to the buffer pool manager's latch.
 * @param disk_scheduler A shared pointer to the buffer pool manager's disk scheduler.
 */
ReadPageGuard::ReadPageGuard(page_id_t page_id, std::shared_ptr<FrameHeader> frame,
                             std::shared_ptr<LRUKReplacer> replacer, std::shared_ptr<std::mutex> bpm_latch,
                             std::shared_ptr<DiskScheduler> disk_scheduler)
    : page_id_(page_id),
      frame_(std::move(frame)),
      replacer_(std::move(replacer)),
      bpm_latch_(std::move(bpm_latch)),
      disk_scheduler_(std::move(disk_scheduler)) {
  //上锁
  frame_->rwlatch_.lock_shared();
  //bpm_latch_->lock();//这里需要上锁吗？？？
  //增加pincount
  frame_->pin_count_.fetch_add(1);

  this->is_valid_ = true;

  // 这里把frame设置成不可驱逐
  replacer_->SetEvictable(frame_->frame_id_, false);
  //UNIMPLEMENTED("TODO(P1): Add implementation.");
}

/**
 * @brief The move constructor for `ReadPageGuard`.
 *
 * ### Implementation
 *
 * If you are unfamiliar with move semantics, please familiarize yourself with learning materials online. There are many
 * great resources (including articles, Microsoft tutorials, YouTube videos) that explain this in depth.
 *
 * Make sure you invalidate the other guard, otherwise you might run into double free problems! For both objects, you
 * need to update _at least_ 5 fields each.
 *
 * TODO(P1): Add implementation.
 *
 * @param that The other page guard.
 */
ReadPageGuard::ReadPageGuard(ReadPageGuard &&that) noexcept
    : page_id_(that.page_id_),
      frame_(std::move(that.frame_)),
      replacer_(std::move(that.replacer_)),
      bpm_latch_(std::move(that.bpm_latch_)),
      disk_scheduler_(std::move(that.disk_scheduler_)),
      is_valid_(that.is_valid_) {
  // 使原对象失效
  that.is_valid_ = false;
  that.page_id_ = INVALID_PAGE_ID;
  that.frame_ = nullptr;
  that.replacer_ = nullptr;
  that.bpm_latch_ = nullptr;
  that.disk_scheduler_ = nullptr;
}

/**
 * @brief The move assignment operator for `ReadPageGuard`.
 *
 * ### Implementation
 *
 * If you are unfamiliar with move semantics, please familiarize yourself with learning materials online. There are many
 * great resources (including articles, Microsoft tutorials, YouTube videos) that explain this in depth.
 *
 * Make sure you invalidate the other guard, otherwise you might run into double free problems! For both objects, you
 * need to update _at least_ 5 fields each, and for the current object, make sure you release any resources it might be
 * holding on to.
 *
 * TODO(P1): Add implementation.
 *
 * @param that The other page guard.
 * @return ReadPageGuard& The newly valid `ReadPageGuard`.
 */
auto ReadPageGuard::operator=(ReadPageGuard &&that) noexcept -> ReadPageGuard & {
  if (this == &that) {  // 当我移动到自己的引用的时候会删掉自己
    return *this;
  }
  // if (!that.is_valid_) {
  //     return that;
  //   }
    if (this->is_valid_) {this->Drop();}//如果this持有资源就释放


    // 这里为什么不能move
    this->page_id_ = that.page_id_;
    this->frame_ = std::move(that.frame_);
    this->replacer_ = std::move(that.replacer_);
    this->bpm_latch_ = std::move(that.bpm_latch_);
    this->disk_scheduler_ = std::move(that.disk_scheduler_);
    this->is_valid_ = that.is_valid_;

    that.is_valid_ = false;
    that.page_id_ = INVALID_PAGE_ID;
    that.frame_ = nullptr;
    that.replacer_ = nullptr;
    that.bpm_latch_ = nullptr;
    that.disk_scheduler_ = nullptr;

    return *this;
}

/**
 * @brief Gets the page ID of the page this guard is protecting.
 */
auto ReadPageGuard::GetPageId() const -> page_id_t {
  BUSTUB_ENSURE(is_valid_, "tried to use an invalid read guard");
  return page_id_;
}

/**
 * @brief Gets a `const` pointer to the page of data this guard is protecting.
 */
auto ReadPageGuard::GetData() const -> const char * {
  BUSTUB_ENSURE(is_valid_, "tried to use an invalid read guard");
  return frame_->GetData();
}

/**
 * @brief Returns whether the page is dirty (modified but not flushed to the disk).
 */
auto ReadPageGuard::IsDirty() const -> bool {
  BUSTUB_ENSURE(is_valid_, "tried to use an invalid read guard");
  return frame_->is_dirty_;
}

/**
 * @brief Flushes this page's data safely to disk.
 *
 * TODO(P1): Add implementation.
 */
void ReadPageGuard::Flush() {
  // 如果没有被修改,就不需要送回磁盘修改了
  if (!IsDirty()) {
    return;
  }

  auto promise = disk_scheduler_->CreatePromise();
  auto future = promise.get_future();
  disk_scheduler_->Schedule({true, frame_->GetDataMut(), frame_->page_id_, std::move(promise)});
  future.get();

  //UNIMPLEMENTED("TODO(P1): Add implementation.");
  }

/**
 * @brief Manually drops a valid `ReadPageGuard`'s data. If this guard is invalid, this function does nothing.
 *
 * ### Implementation
 *
 * Make sure you don't double free! Also, think **very** **VERY** carefully about what resources you own and the order小心二次释放
 * in which you release those resources. If you get the ordering wrong, you will very likely fail one of the later
 * Gradescope tests. You may also want to take the buffer pool manager's latch in a very specific scenario...
 *
 * TODO(P1): Add implementation.
 */
void ReadPageGuard::Drop() {
  //判断是否合法
  if( !is_valid_ ){ return; }
  
  Flush();
  //pin减pin
  frame_->pin_count_.fetch_sub(1);
  // 解锁
  frame_->rwlatch_.unlock_shared();
  
  // 关键修复：确保pin_count为0时正确设置可驱逐
  size_t pin_count = frame_->pin_count_.load();
  if (pin_count == 0) {
    // 需要加锁确保替换器操作的原子性
    std::lock_guard<std::mutex> guard(*bpm_latch_);
    replacer_->SetEvictable(frame_->frame_id_, true);
  }

  page_id_ = INVALID_PAGE_ID;
  frame_ = nullptr;
  bpm_latch_ = nullptr;
  replacer_ = nullptr;
  disk_scheduler_ = nullptr;
  is_valid_ = false;  //明确设置为无效状态？？？

  //UNIMPLEMENTED("TODO(P1): Add implementation.");
}

/** @brief The destructor for `ReadPageGuard`. This destructor simply calls `Drop()`. */
ReadPageGuard::~ReadPageGuard() { Drop(); }

/**********************************************************************************************************************/
/**********************************************************************************************************************/
/**********************************************************************************************************************/

/**
 * @brief The only constructor for an RAII `WritePageGuard` that creates a valid guard.
 *
 * Note that only the buffer pool manager is allowed to call this constructor.
 *
 * TODO(P1): Add implementation.
 *
 * @param page_id The page ID of the page we want to write to.
 * @param frame A shared pointer to the frame that holds the page we want to protect.
 * @param replacer A shared pointer to the buffer pool manager's replacer.
 * @param bpm_latch A shared pointer to the buffer pool manager's latch.
 * @param disk_scheduler A shared pointer to the buffer pool manager's disk scheduler.
 */
WritePageGuard::WritePageGuard(page_id_t page_id, std::shared_ptr<FrameHeader> frame,
                               std::shared_ptr<LRUKReplacer> replacer, std::shared_ptr<std::mutex> bpm_latch,
                               std::shared_ptr<DiskScheduler> disk_scheduler)
    : page_id_(page_id),
      frame_(std::move(frame)),
      replacer_(std::move(replacer)),
      bpm_latch_(std::move(bpm_latch)),
      disk_scheduler_(std::move(disk_scheduler)) {
  // 上锁
  frame_->rwlatch_.lock();// 这里需要上锁吗？？？
  // 增加pincount
  frame_->pin_count_.fetch_add(1);

  this->is_valid_ = true;

  // 这里把frame设置成不可驱逐
  replacer_->SetEvictable(frame_->frame_id_, false);
  //UNIMPLEMENTED("TODO(P1): Add implementation.");
}

/**
 * @brief The move constructor for `WritePageGuard`.
 *
 * ### Implementation
 *
 * If you are unfamiliar with move semantics, please familiarize yourself with learning materials online. There are many
 * great resources (including articles, Microsoft tutorials, YouTube videos) that explain this in depth.
 *
 * Make sure you invalidate the other guard, otherwise you might run into double free problems! For both objects, you
 * need to update _at least_ 5 fields each.
 *
 * TODO(P1): Add implementation.
 *
 * @param that The other page guard.
 */
// WritePageGuard::WritePageGuard(WritePageGuard &&that) noexcept {
//   if (!that.is_valid_) {
//     return;
//   }
//   if(!this->is_valid_)return;
//   this->Drop();

//   this->page_id_ = that.page_id_;
//   this->frame_ = std::move(that.frame_);
//   this->replacer_ = std::move(that.replacer_);
//   this->bpm_latch_ = std::move(that.bpm_latch_);
//   this->disk_scheduler_ = std::move(that.disk_scheduler_);
//   this->is_valid_ = that.is_valid_;

//   // that.Drop();
//   that.is_valid_ = false;
//   that.page_id_ = INVALID_PAGE_ID;

//   // drop时候解锁了，重新上锁
//   // frame_->rwlatch_.lock();
//   //bpm_latch_->lock();  // 这里需要上锁吗？？？
//   // 增加回pincount
//   // frame_->pin_count_.fetch_add(1);
// }
// 移动构造
WritePageGuard::WritePageGuard(WritePageGuard &&that) noexcept
    : page_id_(that.page_id_),
      frame_(std::move(that.frame_)),
      replacer_(std::move(that.replacer_)),
      bpm_latch_(std::move(that.bpm_latch_)),
      disk_scheduler_(std::move(that.disk_scheduler_)),
      is_valid_(that.is_valid_) {
  // 使原对象失效
  that.is_valid_ = false;
  that.page_id_ = INVALID_PAGE_ID;
  that.frame_ = nullptr;
  that.replacer_ = nullptr;
  that.bpm_latch_ = nullptr;
  that.disk_scheduler_ = nullptr;
}

/**
 * @brief The move assignment operator for `WritePageGuard`.
 *
 * ### Implementation
 *
 * If you are unfamiliar with move semantics, please familiarize yourself with learning materials online. There are many
 * great resources (including articles, Microsoft tutorials, YouTube videos) that explain this in depth.
 *
 * Make sure you invalidate the other guard, otherwise you might run into double free problems! For both objects, you
 * need to update _at least_ 5 fields each, and for the current object, make sure you release any resources it might be
 * holding on to.
 *
 * TODO(P1): Add implementation.
 *
 * @param that The other page guard.
 * @return WritePageGuard& The newly valid `WritePageGuard`.
 */
auto WritePageGuard::operator=(WritePageGuard &&that) noexcept -> WritePageGuard & {
  if (this == &that)return *this;
  // if (!that.is_valid_) {
  //   return that;
  // }
  if (this->is_valid_){//如果this持有资源，就释放
    this->Drop();
  }

  this->page_id_ = that.page_id_;
  this->frame_ = std::move(that.frame_);
  this->replacer_ = std::move(that.replacer_);
  this->bpm_latch_ = std::move(that.bpm_latch_);
  this->disk_scheduler_ = std::move(that.disk_scheduler_);
  this->is_valid_ = that.is_valid_;

  that.is_valid_ = false;
  that.page_id_ = INVALID_PAGE_ID;
  that.frame_ = nullptr;
  that.replacer_ = nullptr;
  that.bpm_latch_ = nullptr;
  that.disk_scheduler_ = nullptr;
  
  return *this;
}

/**
 * @brief Gets the page ID of the page this guard is protecting.
 */
auto WritePageGuard::GetPageId() const -> page_id_t {
  // BUSTUB_ENSURE(is_valid_, "tried to use an invalid write guard");
  return page_id_;
}

/**
 * @brief Gets a `const` pointer to the page of data this guard is protecting.
 */
//这里获取的是无法修改的
auto WritePageGuard::GetData() const -> const char * {
  BUSTUB_ENSURE(is_valid_, "tried to use an invalid write guard");
  return frame_->GetData();
}

/**
 * @brief Gets a mutable pointer to the page of data this guard is protecting.
 */
//这里无论有没有被修改，都应该设置为脏了，因为无法得知
auto WritePageGuard::GetDataMut() -> char * {
  BUSTUB_ENSURE(is_valid_, "tried to use an invalid write guard");
  frame_->SetDirty(true);
  return frame_->GetDataMut();
}

/**
 * @brief Returns whether the page is dirty (modified but not flushed to the disk).
 */
auto WritePageGuard::IsDirty() const -> bool {
  BUSTUB_ENSURE(is_valid_, "tried to use an invalid write guard");
  return frame_->is_dirty_;
}

/**
 * @brief Flushes this page's data safely to disk.
 *
 * TODO(P1): Add implementation.
 */
void WritePageGuard::Flush() {
  // 如果没有被修改,就不需要送回磁盘修改了
  if(!IsDirty()){return;}

  auto promise = disk_scheduler_->CreatePromise();
  auto future = promise.get_future();
  disk_scheduler_->Schedule({true, frame_->GetDataMut(), frame_->page_id_, std::move(promise)});
  future.get();
  //UNIMPLEMENTED("TODO(P1): Add implementation."); 
}

/**
 * @brief Manually drops a valid `WritePageGuard`'s data. If this guard is invalid, this function does nothing.
 *
 * ### Implementation
 *
 * Make sure you don't double free! Also, think **very** **VERY** carefully about what resources you own and the order
 * in which you release those resources. If you get the ordering wrong, you will very likely fail one of the later
 * Gradescope tests. You may also want to take the buffer pool manager's latch in a very specific scenario...
 *
 * TODO(P1): Add implementation.
 */
void WritePageGuard::Drop() {
  // 判断是否合法
  if (!is_valid_) {
    return;
  }
  //bpm_latch_->lock();
  Flush();
  // pin减pin
  frame_->pin_count_.fetch_sub(1);
  // 解锁
  frame_->rwlatch_.unlock();
  
  // 关键修复：确保pin_count为0时正确设置可驱逐
  size_t pin_count = frame_->pin_count_.load();
  if (pin_count == 0){
    // 需要加锁确保替换器操作的原子性
    std::lock_guard<std::mutex> guard(*bpm_latch_);
    replacer_->SetEvictable(frame_->frame_id_, true);
  } 

  page_id_ = INVALID_PAGE_ID;
  frame_ = nullptr;
  bpm_latch_ = nullptr;
  replacer_ = nullptr;
  disk_scheduler_ = nullptr;
  is_valid_ = false;  // 明确设置为无效状态？？？

  //bpm_latch_->unlock();
  // UNIMPLEMENTED("TODO(P1): Add implementation.");
}

/** @brief The destructor for `WritePageGuard`. This destructor simply calls `Drop()`. */
WritePageGuard::~WritePageGuard() { Drop(); }

}  // namespace bustub
