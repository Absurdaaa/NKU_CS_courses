//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// b_plus_tree_leaf_page.cpp
//
// Identification: src/storage/page/b_plus_tree_leaf_page.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <sstream>

#include "common/exception.h"
#include "common/rid.h"
#include "storage/page/b_plus_tree_leaf_page.h"

namespace bustub {

/*****************************************************************************
 * HELPER METHODS AND UTILITIES
 *****************************************************************************/

/**
 * @brief Init method after creating a new leaf page
 *
 * After creating a new leaf page from buffer pool, must call initialize method to set default values,
 * including set page type, set current size to zero, set page id/parent id, set
 * next page id and set max size.
 *
 * @param max_size Max size of the leaf node
 */
INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::Init(int max_size) {
  // 基础设置
  SetPageType(IndexPageType::LEAF_PAGE);
  SetSize(0);
  SetMaxSize(max_size);
  SetNextPageId(INVALID_PAGE_ID);  // 初始化下一个页面ID为无效值
  for(int i = 0; i < max_size; i++) {
    rid_array_[i] = RID();  // 初始化RID数组
  }
  for(int i = 0; i < max_size; i++) {
    key_array_[i] = KeyType();  // 初始化键数组
  }
}

/**
 * Helper methods to set/get next page id
 */
INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_LEAF_PAGE_TYPE::GetNextPageId() const -> page_id_t{return next_page_id_;}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::SetNextPageId(page_id_t next_page_id){
    next_page_id_ = next_page_id; }

/*
 * Helper method to find and return the key associated with input "index" (a.k.a
 * array offset)
 */
INDEX_TEMPLATE_ARGUMENTS auto B_PLUS_TREE_LEAF_PAGE_TYPE::KeyAt(int index) const -> KeyType {
  if (index < 0 || index >= GetSize()) {
    BUSTUB_ASSERT(false, "Index out of range");
  }
  return key_array_[index];
}

INDEX_TEMPLATE_ARGUMENTS auto B_PLUS_TREE_LEAF_PAGE_TYPE::ValueAt(int index) const -> ValueType {
  if(index < 0 || index >= GetSize()) {
    BUSTUB_ASSERT(false, "Index out of range");
  }
  return rid_array_[index];
}

INDEX_TEMPLATE_ARGUMENTS 
auto B_PLUS_TREE_LEAF_PAGE_TYPE::Lookup(const KeyType &key, std::vector<ValueType> *result, const KeyComparator &comparator) const -> bool
{
  // // 更精确的二分查找实现
  // int left = 0;
  // int right = GetSize() - 1;
  
  // while (left <= right) {
  //   int mid = left + (right - left) / 2;
  //   int cmp = comparator(key, KeyAt(mid));
    
  //   if (cmp == 0) {
  //     // 找到匹配的键
  //     result->push_back(rid_array_[mid]);
  //     return true;
  //   } else if (cmp < 0) {
  //     right = mid - 1;
  //   } else {
  //     left = mid + 1;
  //   }
  // }
  for(int i=0;i<GetSize();i++){
    if(comparator(key,key_array_[i])==0){
      result->push_back(rid_array_[i]);
      return true;
    }
  }
  
  return false;
}

INDEX_TEMPLATE_ARGUMENTS
auto B_PLUS_TREE_LEAF_PAGE_TYPE::InsertValue(const KeyType &key, const ValueType &value, int index) -> bool {
  for (int i = GetSize(); i > index; i--) {
    key_array_[i] = key_array_[i - 1];
    rid_array_[i] = rid_array_[i - 1];
  }
  key_array_[index] = key;
  rid_array_[index] = value;
  ChangeSizeBy(1);
  // if (GetSize() < GetMinSize()) {
  //   BUSTUB_ASSERT(false, "节点比最小值小");
  // }
  return true;
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::SplitAndInsert(
  const KeyType &key, const ValueType &value, B_PLUS_TREE_LEAF_PAGE_TYPE *new_leaf,page_id_t new_page_id, const KeyComparator &comparator) 
 {
    // 使用临时数组存储所有数据（包括新插入的键值对）
    KeyType temp_keys[GetMaxSize() + 1];
    ValueType temp_values[GetMaxSize() + 1];
    
    if(GetSize() != GetMaxSize()) {
      BUSTUB_ASSERT(false, "???");
    }
    // 查找新键应该插入的位置
    int index = 0;
    for (; index < GetSize(); ++index) {
      if (comparator(key, KeyAt(index)) == -1) {
        break;
      }
    }
    
    // 复制现有数据到临时数组，同时插入新键值对
    int i;
    for (i = 0; i < index; ++i) {
      temp_keys[i] = key_array_[i];
      temp_values[i] = rid_array_[i];
    }
    
    // 在正确位置插入新键值对
    temp_keys[i] = key;
    temp_values[i] = value;
    
    // 继续复制剩余数据
    for (; i < GetSize(); ++i) {
      temp_keys[i + 1] = key_array_[i];
      temp_values[i + 1] = rid_array_[i];
    }
    
    // 计算总条目数
    int total_entries = GetSize() + 1;
    
    // 分割点计算，左叶子节点保留GetMinSize()个元素
    int split = GetMinSize();
    
    // 左边部分保留在当前节点
    SetSize(split);
    for (i = 0; i < split; ++i) {
      key_array_[i] = temp_keys[i];
      rid_array_[i] = temp_values[i];
    }
    
    // 右边部分移到新节点
    int new_size = total_entries - split;
    new_leaf->SetSize(new_size);
    for (i = 0; i < new_size; ++i) {
      new_leaf->key_array_[i] = temp_keys[split + i];
      new_leaf->rid_array_[i] = temp_values[split + i];
    }
    
    // 设置叶子节点的链接关系
    page_id_t original_next = GetNextPageId();
    new_leaf->SetNextPageId(original_next);  // 新叶子指向原叶子的下一个
    SetNextPageId(new_page_id);               // 原叶子指向新叶子
}

INDEX_TEMPLATE_ARGUMENTS
void B_PLUS_TREE_LEAF_PAGE_TYPE::Remove(int index)
{
  for (int i = index; i < GetSize()-1; i++) {
    key_array_[i] = key_array_[i + 1];
    rid_array_[i] = rid_array_[i + 1];
  }
  ChangeSizeBy(-1);
  // if(GetSize()<GetMinSize()){
  //   abort();
  //   BUSTUB_ASSERT(false,"节点比最小值小");
  // }
  return;
}

template class BPlusTreeLeafPage<GenericKey<4>, RID, GenericComparator<4>>;
template class BPlusTreeLeafPage<GenericKey<8>, RID, GenericComparator<8>>;
template class BPlusTreeLeafPage<GenericKey<16>, RID, GenericComparator<16>>;
template class BPlusTreeLeafPage<GenericKey<32>, RID, GenericComparator<32>>;
template class BPlusTreeLeafPage<GenericKey<64>, RID, GenericComparator<64>>;
}  // namespace bustub
