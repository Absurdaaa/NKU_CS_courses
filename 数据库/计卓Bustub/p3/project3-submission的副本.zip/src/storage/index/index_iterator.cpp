//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// index_iterator.cpp
//
// Identification: src/storage/index/index_iterator.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

/**
 * index_iterator.cpp
 */
#include <cassert>

#include "storage/index/index_iterator.h"

namespace bustub {

/**
 * @note you can change the destructor/constructor method here
 * set your own input parameters
 */
INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::IndexIterator(BufferPoolManager *bpm, page_id_t page_id, int index)
    : bpm_(bpm), page_id_(page_id), index_(index){

    // 获取当前页面
    if(page_id_ == INVALID_PAGE_ID) {
      is_end_ = true;
      page_guard_ = ReadPageGuard{};  // 创建一个默认构造的空 ReadPageGuard
      next_page_id_ = INVALID_PAGE_ID;
      prev_page_id_ = INVALID_PAGE_ID;                
      return;
    }
    page_guard_ = bpm->ReadPage(page_id_);
    auto page = page_guard_.As<LeafPage>();
    next_page_id_ = page->GetNextPageId();
    is_end_ = IsEnd();
    prev_page_id_ = INVALID_PAGE_ID;
    
    }

INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::~IndexIterator() = default;  // NOLINT

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::IsEnd() -> bool {
  if(page_id_ == INVALID_PAGE_ID) {
    return true;
  }
  auto page = page_guard_.As<LeafPage>();
  // 如果是最后一个索引
  if (index_ >= page->GetSize() && next_page_id_ == 0) {
    return true;
  } else {
    return false;
  }
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator*() -> std::pair<const KeyType &, const ValueType &> {
  // 确保迭代器有效
  // BUSTUB_ASSERT(!is_end_,'迭代器无效');
  if(page_id_ == INVALID_PAGE_ID || is_end_) {
    abort();
  }
  
  // 获取叶节点
  auto page = page_guard_.As<LeafPage>();

  // 返回当前位置的键值对
  return {page->KeyAt(index_), page->ValueAt(index_)};
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator++() -> INDEXITERATOR_TYPE & {
  if(is_end_) {
    abort();
    return *this;
  }
  
  // 获取当前叶节点
  auto page = page_guard_.As<LeafPage>();

  // 移动到下一个索引
  index_++;
  
  //如果下一个页面ID是无效的，说明已经遍历完了
  if (index_ >= page->GetSize()) {
    // 如果当前页面没有下一个页面，说明已经到达末尾
    if (next_page_id_ == 0 ||next_page_id_ == -1) {
      is_end_ = true;
      // 释放当前页面
      page_guard_.Drop();
      page_id_ = INVALID_PAGE_ID;
      index_ = 0;
      return *this;
    }
    
    // 保存下一页的ID，先释放当前页的锁再获取下一页的锁
    // 这样可以避免死锁问题
    page_id_t next_id = next_page_id_;
    
    // 安全地释放当前页面
    page_guard_.Drop();
    
    // 获取下一个页面并重新获取锁
    // 这里需要处理失败的情况，例如页面已被删除
    page_guard_ = bpm_->ReadPage(next_id);
    
    // 如果获取页面失败，设为结束状态
    if (page_guard_.GetData() == nullptr) {
      is_end_ = true;
      page_id_ = INVALID_PAGE_ID;
      index_ = 0;
      return *this;
    }
    
    // 更新迭代器状态
    page_id_ = next_id;
    index_ = 0;
    page = page_guard_.As<LeafPage>();
    next_page_id_ = page->GetNextPageId();
    is_end_ = IsEnd();
    
  }
  
  return *this;
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator==(const IndexIterator &itr) const -> bool {
  if(page_id_ == itr.page_id_ && index_ == itr.index_) {
    return true;
  }
  return false;
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator!=(const IndexIterator &itr) const -> bool {
  return !(*this == itr);
}

// 实例化模板
template class IndexIterator<GenericKey<4>, RID, GenericComparator<4>>;
template class IndexIterator<GenericKey<8>, RID, GenericComparator<8>>;
template class IndexIterator<GenericKey<16>, RID, GenericComparator<16>>;
template class IndexIterator<GenericKey<32>, RID, GenericComparator<32>>;
template class IndexIterator<GenericKey<64>, RID, GenericComparator<64>>;

}  // namespace bustub
