# p0
cd build
make -j$(nproc) skiplist_test
./test/skiplist_test


# p1
make lru_k_replacer_test -j `nproc`
./test/lru_k_replacer_test

make disk_scheduler_test -j `nproc`
./test/disk_scheduler_test

make page_guard_test -j `nproc`
./test/page_guard_test

make buffer_pool_manager_test -j `nproc`
./test/buffer_pool_manager_test



