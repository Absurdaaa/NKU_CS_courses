
cd build
# $ cmake -DCMAKE_BUILD_TYPE=Debug ..
cmake -DCMAKE_BUILD_TYPE=Debug -DBUSTUB_SANITIZER= ..

make -j$(nproc) sqllogictest

./bin/bustub-sqllogictest ../test/sql/p3.01-seqscan.slt --verbose

./bin/bustub-sqllogictest ../test/sql/p3.02-insert.slt --verbose

./bin/bustub-sqllogictest ../test/sql/p3.03-update.slt --verbose

./bin/bustub-sqllogictest ../test/sql/p3.04-delete.slt --verbose

./bin/bustub-sqllogictest ../test/sql/p3.05-index-scan-btree.slt --verbose

./bin/bustub-sqllogictest ../test/sql/p3.06-empty-table.slt --verbose

./bin/bustub-sqllogictest ../test/sql/p3.07-simple-agg.slt --verbose

./bin/bustub-sqllogictest ../test/sql/p3.08-group-agg-1.slt --verbose

./bin/bustub-sqllogictest ../test/sql/p3.09-group-agg-2.slt --verbose

./bin/bustub-sqllogictest ../test/sql/p3.10-simple-join.slt --verbose

./bin/bustub-sqllogictest ../test/sql/p3.11-multi-way-join.slt --verbose

./bin/bustub-sqllogictest ../test/sql/p3.12-repeat-execute.slt --verbose

./bin/bustub-sqllogictest ../test/sql/p3.13-nested-index-join.slt --verbose

./bin/bustub-sqllogictest ../test/sql/p3.14-hash-join.slt --verbose

./bin/bustub-sqllogictest ../test/sql/p3.15-multi-way-hash-join.slt --verbose

./bin/bustub-sqllogictest ../test/sql/p3.16-sort-limit.slt --verbose

