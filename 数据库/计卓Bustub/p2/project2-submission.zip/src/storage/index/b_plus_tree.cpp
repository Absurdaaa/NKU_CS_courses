//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// b_plus_tree.cpp
//
// Identification: src/storage/index/b_plus_tree.cpp
//
// Copyright (c) 2015-2025, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "storage/index/b_plus_tree.h"
#include "storage/index/b_plus_tree_debug.h"

namespace bustub {

INDEX_TEMPLATE_ARGUMENTS
BPLUSTREE_TYPE::BPlusTree(std::string name, page_id_t header_page_id, BufferPoolManager *buffer_pool_manager,
                          const KeyComparator &comparator, int leaf_max_size, int internal_max_size)
    : index_name_(std::move(name)),
      bpm_(buffer_pool_manager),
      comparator_(std::move(comparator)),
      leaf_max_size_(leaf_max_size),
      internal_max_size_(internal_max_size),
      header_page_id_(header_page_id) {
  WritePageGuard guard = bpm_->WritePage(header_page_id_);
  auto root_page = guard.AsMut<BPlusTreeHeaderPage>();
  root_page->root_page_id_ = INVALID_PAGE_ID;
}

/**
 * @brief Helper function to decide whether current b+tree is empty
 * @return Returns true if this B+ tree has no keys and values.
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::IsEmpty() const -> bool { 
  ReadPageGuard guard = bpm_->ReadPage(header_page_id_);

  //把这页的数据转换成BPlusTreeHeaderPage
  auto root_page = guard.As<BPlusTreeHeaderPage>();
  if(root_page == nullptr) {//这页里面存的数据是空的
    return true;
  }
  //如果这页的根节点是无效的，就是此时一个节点都没有，所以没有根节点
  if(root_page->root_page_id_ == INVALID_PAGE_ID) {
    return true;
  }
  return false;
}

/*****************************************************************************
 * SEARCH
 *****************************************************************************/
/**
 * @brief Return the only value that associated with input key
 *
 * This method is used for point query
 *
 * @param key input key
 * @param[out] result vector that stores the only value that associated with input key, if the value exists
 * @return : true means key exists
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::GetValue(const KeyType &key, std::vector<ValueType> *result) -> bool {
  // UNIMPLEMENTED("TODO(P2): Add implementation.");
  //  Declaration of context instance. Using the Context is not necessary but advised.
  
  // 如果树是空的，直接返回错误
  if(IsEmpty()) {
    return false;
  }

  // 获得根节点的id
  ReadPageGuard guard = bpm_->ReadPage(header_page_id_);
  auto root_page = guard.As<BPlusTreeHeaderPage>();
  page_id_t root_page_id_ = root_page->root_page_id_;
  
  
  //Context ctx(root_page_id_);
  //这里上下文没用吧
  // 读取根节点
  ReadPageGuard page_guard = bpm_->ReadPage(root_page_id_);
  //存疑，真的是装换成这个吗
  auto page = page_guard.As<BPlusTreePage>();
  //ctx.read_set_.push_back(std::move(page_guard));

  // 如果根节点不是叶子节点，进行查找
  while(!page->IsLeafPage()) {
    auto internal_page = page_guard.As<InternalPage>();
    // 查找
    int index = internal_page->Lookup(key, comparator_);
    // 找到对应的子节点
    page_id_t child_page_id = internal_page->ValueAt(index);
    // 读取子节点
    page_guard.Drop();  // 释放读锁
    page_guard = bpm_->ReadPage(child_page_id);
    //ctx.read_set_.push_back(std::move(child_page_guard));
    page = page_guard.As<BPlusTreePage>();
  }
  
  // 如果是叶子节点，直接读取
  auto leaf = page_guard.As<LeafPage>();
  return leaf->Lookup(key, result, comparator_);
}

/*****************************************************************************
 * InternalInsert
 *****************************************************************************/
/**
 * @brief 内部节点的插入，递归函数
 *  考虑父亲节点满了和没满两种情况
 * 
 * @param key input key
 * @param page_id 输入的pageid
 * @param ctx 上下文,readset最后一个是当前及诶的父亲，write最后一个是当前的节点
 * @param parent_page 父节点
 */
INDEX_TEMPLATE_ARGUMENTS
bool BPLUSTREE_TYPE::InternalInsert(KeyType &key, page_id_t page_id, Context *ctx, InternalPage *parent_page) {
  // 保存当前页面ID，这是正在修改的页面
  page_id_t current_page_id = ctx->write_set_.back().GetPageId();
  bool is_root = ctx->IsRootPage(current_page_id);
  
  // 如果内部节点未满，直接插入
  if (parent_page->GetSize() < parent_page->GetMaxSize()) {
    parent_page->Insert(key, page_id, comparator_);
    return true;
  }
  
  // 内部节点已满，需要分裂
  page_id_t new_page_id = bpm_->NewPage();
  if (new_page_id == INVALID_PAGE_ID) {
    return false;  // 分配新页面失败
  }
  WritePageGuard new_page_guard = bpm_->WritePage(new_page_id);
  auto new_page = new_page_guard.AsMut<InternalPage>();
  new_page->Init(internal_max_size_);
  
  // 分裂并插入，获取需要上移的key
  KeyType up_key = parent_page->Split(key, page_id, new_page, comparator_);
  
  //ctx->write_set_.pop_back();
  //new_page_guard.Drop();  // 释放新页面的写锁

      // 如果已经是根节点，创建新的根节点
      if (is_root) {
    page_id_t new_root_id = bpm_->NewPage();
    if (new_root_id == INVALID_PAGE_ID) {
      return false;  // 分配新页面失败
    }
    
    WritePageGuard new_root_guard = bpm_->WritePage(new_root_id);
    auto new_root = new_root_guard.AsMut<InternalPage>();
    new_root->Init(internal_max_size_);
    
    // 初始化新根节点
    new_root->InternalInit(up_key, current_page_id, new_page_id);
    
    // 更新根节点ID
    auto header_page = ctx->header_page_.value().AsMut<BPlusTreeHeaderPage>();
    header_page->root_page_id_ = new_root_id;
    
    
   new_root_guard.Drop();  // 释放新根节点的写锁
    //这里有用吗
    ReadPageGuard new_root_read_guard = bpm_->ReadPage(new_root_id);
    
    ctx->read_set_.push_back(std::move(new_root_read_guard));
    return true;
  }

  // 递归处理父节点
  if (!ctx->read_set_.empty()) {
    // 安全地处理父节点的读锁
    page_id_t parent_page_id = INVALID_PAGE_ID;
    
    // 确保安全地获取父节点ID
    ReadPageGuard &parent_read_guard = ctx->read_set_.back();
    parent_page_id = parent_read_guard.GetPageId();
    parent_read_guard.Drop();
    ctx->read_set_.pop_back();
  
    
    if (parent_page_id != INVALID_PAGE_ID) {
      // 获取父节点的写锁
      WritePageGuard parent_write_guard = bpm_->WritePage(parent_page_id);
      auto grandparent = parent_write_guard.AsMut<InternalPage>();
      ctx->write_set_.push_back(std::move(parent_write_guard));
      // 递归处理
      InternalInsert(up_key, new_page_id, ctx, grandparent);
      
      
      
      //父亲放回readset
      //检查最后一个是不是爷爷
      if(ctx->write_set_.back().GetPageId() != parent_page_id) {
        //ctx->write_set_.pop_back();  // 释放父节点的写锁
        BUSTUB_ASSERT(false, "最后一个不是爷爷，不对孩子");
      }
      ctx->write_set_.pop_back();  // 释放父节点的写锁
      ReadPageGuard parent_read_guard = bpm_->ReadPage(parent_page_id);
      
      // auto grandparent_page = parent_read_guard.As<InternalPage>();
      
      ctx->read_set_.push_back(std::move(parent_read_guard));

      // 此时这个节点肯定是内部节点，我们检查grandparent的儿子是不是内部节点
      //  如果是叶子节点，说明分裂失败
      ctx->write_set_.back().Drop();  // 释放父节点的写锁
      ctx->write_set_.pop_back();  // 释放父节点的写锁

      //std::cout << "grandparent_id is" << parent_page_id << ",here are his sons" << std::endl;
      // for (int i = 0; i < grandparent_page->GetSize(); i++) {
      //   auto child_page_id = grandparent_page->ValueAt(i);
      //   ReadPageGuard child_read_guard = bpm_->ReadPage(child_page_id);
      //   auto child_page = child_read_guard.As<BPlusTreePage>();
      //   //std::cout<<child_page_id <<", ";
      //   if (child_page->IsLeafPage()) {
      //     // 释放读锁
      //     child_read_guard.Drop();
      //     abort();
      //     return false;  // 分裂失败
      //   }
      // }
      //std::cout << std::endl;
      //把父亲放回writeset
      WritePageGuard curr = bpm_->WritePage(current_page_id);
      ctx->write_set_.push_back(std::move(curr));

      return true;
    }
  }
  abort();
  return false;  // 不应该到达这里
}

/*****************************************************************************
 * INSERTION
 *****************************************************************************/
/**
 * @brief Insert constant key & value pair into b+ tree
 *
 * if current tree is empty, start new tree, update root page id and insert
 * entry, otherwise insert into leaf page.
 * 如果现在这颗树是空的，就创建一个新树
 *
 * @param key the key to insert
 * @param value the value associated with key
 * @return: since we only support unique key, if user try to insert duplicate
 * keys return false, otherwise return true.
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Insert(const KeyType &key, const ValueType &value) -> bool {
  //UNIMPLEMENTED("TODO(P2): Add implementation.");
  // Declaration of context instance. Using the Context is not necessary but advised.
  Context ctx;
  ctx.header_page_ = bpm_->WritePage(header_page_id_);
  auto header_page = ctx.header_page_.value().AsMut<BPlusTreeHeaderPage>();
  ctx.root_page_id_ = header_page->root_page_id_;
  // --- 1. 处理空树 ---
  if (ctx.root_page_id_ == INVALID_PAGE_ID) {
    // 获取头页写锁
    
    

    // 创建新的叶子节点作为根
    page_id_t root_page_id = bpm_->NewPage();
    if (root_page_id == INVALID_PAGE_ID) {
      return false; // 无法分配新页面
    }
    // 初始化新的叶子节点
    WritePageGuard root_page_guard = bpm_->WritePage(root_page_id);
    auto root_leaf = root_page_guard.AsMut<LeafPage>();
    root_leaf->Init(leaf_max_size_);

    // 插入第一个键值对
    root_leaf->InsertValue(key, value, 0); // 在空叶子节点中插入到位置0

    // 更新头页
    header_page->root_page_id_ = root_page_id;

    // 根节点和头页的锁会在 ctx 析构时自动释放
    return true;
  }

  // --- 2. 查找叶子节点 (使用 Latch Crabbing) ---
  // 获取头页读锁以读取根 ID 
  // ctx.header_page_ = bpm_->WritePage(header_page_id_);
  // auto header_page = ctx.header_page_.value().As<BPlusTreeHeaderPage>();
  // ctx.root_page_id_ = header_page->root_page_id_;
  page_id_t current_page_id = header_page->root_page_id_;

  // 从根节点开始下降
  ReadPageGuard current_rguard = bpm_->ReadPage(current_page_id);


  while (true) {
    auto current_page = current_rguard.As<BPlusTreePage>();

    // --- 3. 到达叶子节点 ---
    if (current_page->IsLeafPage()) {
      // 释放当前叶节点的读锁，准备获取写锁
      page_id_t leaf_page_id = current_rguard.GetPageId();
      current_rguard.Drop();

      // 获取叶子节点的写锁
      WritePageGuard leaf_wguard = bpm_->WritePage(leaf_page_id);
      auto leaf_page = leaf_wguard.AsMut<LeafPage>();

      // 检查键是否重复
      int insert_pos = leaf_page->checkKey(key, comparator_);
      if (insert_pos < leaf_page->GetSize() && comparator_(leaf_page->KeyAt(insert_pos), key) == 0) {
        // 键重复，释放所有锁并返回 false
        // ctx 中的 read_set_ 锁已在下降过程中释放
        // leaf_wguard 会在函数结束时自动释放
        return false;
      }

      // --- 3.1 叶子节点未满 ---
      if (leaf_page->GetSize() < leaf_page->GetMaxSize()) {
        leaf_page->InsertValue(key, value, insert_pos);
        //如果本身是根节点，不需要更新

        // 如果插入的是第一个键，且不是根节点，需要更新父节点
        // if (insert_pos == 0 && !ctx.IsRootPage(leaf_page_id) && !ctx.read_set_.empty()) {
        //    // 获取父节点写锁 ,read_set_ 最后一个是父节点的读锁
        //    ReadPageGuard parent_rguard = std::move(ctx.read_set_.back());
        //    page_id_t parent_page_id = parent_rguard.GetPageId();
        //    parent_rguard.Drop();
        //    ctx.read_set_.pop_back();

        //    WritePageGuard parent_wguard = bpm_->WritePage(parent_page_id);
        //    auto parent_page = parent_wguard.AsMut<InternalPage>();
        //    ctx.write_set_.push_back(std::move(parent_wguard));
        //    // 调用 Updatekey，传递父节点指针和新的键
        //    // Updatekey(parent_page, key, leaf_page_id, &ctx);
        //    // parent_wguard 会自动释放
        // }
        // leaf_wguard 会自动释放
        return true;
      }

      // --- 3.2 叶子节点已满，需要分裂 ---
      page_id_t new_leaf_page_id = bpm_->NewPage();
      if (new_leaf_page_id == INVALID_PAGE_ID) {
        return false; // 无法分配新页面
      }
      WritePageGuard new_leaf_guard = bpm_->WritePage(new_leaf_page_id);
      auto new_leaf_page = new_leaf_guard.AsMut<LeafPage>();
      new_leaf_page->Init(leaf_max_size_);

      // 执行分裂和插入
      leaf_page->SplitAndInsert(key, value, new_leaf_page, new_leaf_page_id, comparator_);

      // 获取需要插入到父节点的键 (新叶节点的第一个键)
      KeyType middle_key = new_leaf_page->KeyAt(0);

      // 将新旧叶子节点的写锁放入 ctx (如果需要 InternalInsert 访问)
      // 注意：BasicPageGuard 不能直接移动到 ctx，需要转换为 WritePageGuard
      // 或者在 InternalInsert 中重新获取锁。这里假设 InternalInsert 会处理。
      // 为了简化，我们先释放它们，InternalInsert 需要时再获取。
      leaf_wguard.Drop();
      new_leaf_guard.Drop();


      // --- 3.3 更新父节点 ---
      if (ctx.IsRootPage(leaf_page_id)) {
        // --- 创建新的根节点 ---
        page_id_t new_root_id = bpm_->NewPage();
        if (new_root_id == INVALID_PAGE_ID) {
          return false; // 无法分配新页面
        }
        WritePageGuard new_root_guard = bpm_->WritePage(new_root_id);
        auto new_root_page = new_root_guard.AsMut<InternalPage>();
        new_root_page->Init(internal_max_size_);
        new_root_page->InternalInit(middle_key, leaf_page_id, new_leaf_page_id);

        // 获取头页写锁以更新根 ID
        auto header_page_mut = ctx.header_page_.value().AsMut<BPlusTreeHeaderPage>();
        header_page_mut->root_page_id_ = new_root_id;
        ctx.root_page_id_ = new_root_id; // 更新 ctx 中的根 ID

        // new_root_guard 和 header_page_ 锁会自动释放
        return true;

      } else {
        // --- 递归更新父节点 ---
        if (ctx.read_set_.empty()) {
          // 这不应该发生，因为如果不是根，read_set 至少包含父节点
          BUSTUB_ASSERT(false, "Parent lock not found in read_set_ for non-root split");
          return false;
        }
        // 获取父节点写锁
        ReadPageGuard parent_rguard = std::move(ctx.read_set_.back());
        page_id_t parent_page_id = parent_rguard.GetPageId();
        parent_rguard.Drop();
        ctx.read_set_.pop_back();

        WritePageGuard parent_wguard = bpm_->WritePage(parent_page_id);
        auto parent_page = parent_wguard.AsMut<InternalPage>();

        // 将父节点写锁加入 ctx，以便 InternalInsert 递归时使用
        ctx.write_set_.push_back(std::move(parent_wguard));
        
        /*
        此时writrset最后一个是将要修改的父亲节点
        readset最后一个是这个父亲的父亲
        */

        // 调用 InternalInsert 处理父节点插入和可能的分裂
        // 注意：InternalInsert 需要自己处理锁的获取和释放
        bool insert_internal_ok = InternalInsert(middle_key, new_leaf_page_id, &ctx, parent_page);
        
        if(!insert_internal_ok) {
          // 分裂失败，释放所有锁并返回 false
          // ctx 中的 read_set_ 锁已在下降过程中释放
          // parent_wguard 会自动释放
          abort();
        }

        // ctx 中的锁会自动释放
        return insert_internal_ok;
      }
    } // end if (IsLeafPage)

    // --- 4. 当前是内部节点，继续下降 ---
    auto internal_page = current_rguard.As<InternalPage>();
    int child_index = internal_page->Lookup(key, comparator_);
    page_id_t child_page_id = internal_page->ValueAt(child_index);

    // 获取子节点读锁 (在释放当前节点锁之前)
    ReadPageGuard child_rguard = bpm_->ReadPage(child_page_id);
    auto child_page = child_rguard.As<BPlusTreePage>();

    // 检查子节点是否会分裂
    bool child_will_split = (child_page->GetSize() == child_page->GetMaxSize());
    // 检查是否沿着最左侧指针下降 (child_index == 0 意味着 key < KeyAt(1))
    // bool might_need_update_ancestor = (child_index == 0);
    bool might_need_update_ancestor = 0;

    // 安全释放条件：子节点不会分裂 且 不是沿着最左侧指针下降
    bool can_release_ancestors = !child_will_split && !might_need_update_ancestor;

    // Latch Crabbing: 只有在绝对安全时才释放祖先锁
    if (can_release_ancestors) {
      while (ctx.read_set_.size()>1) {
        ctx.read_set_.pop_front(); // 自动 Drop
      }
    }

    // 根据是否能释放祖先锁，决定如何处理当前节点的锁
    if (!can_release_ancestors) {
        // 如果子节点可能分裂 或 可能需要更新祖先，保留当前(父)节点的读锁
        ctx.read_set_.push_back(std::move(current_rguard));
    } else {
        // 如果子节点确定安全，释放当前(父)节点的读锁
        current_rguard.Drop();
    }

    // 移动到子节点
    current_rguard = std::move(child_rguard);
    current_page_id = child_page_id;

  } // end while(true)
}

/*****************************************************************************
 * Updatakey
 *****************************************************************************/
/**
 * @brief 孩子节点没发生合并，但是可能修改第一个键值，更新key,
 * 这个updateksy函数主要是内部节点的递归
 *
 * @param parent_page 需要更新的父亲节点
 * @param new_key 孩子节点的新第一个值
 * @param child_page_id 发生改变的孩子节点
 * @param ctx 上下文，此时read_set_最后面是这个父亲的父亲,write最后一个是这个父亲 
 */

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Updatekey(InternalPage *parent_page, const KeyType &new_key, page_id_t child_page_id, Context *ctx) {
  int index = parent_page->ValueIndex(child_page_id);
  
  //1. 如果本父亲节点是根节点了，修改key之后不会对上面产生影响
  if(ctx->read_set_.empty()){
    //如果index是0，对根节点没有影响，直接返回
    if(index == 0)return;
    //如果index不是0，直接修改key
    parent_page->SetKeyAt(index, new_key);
    return;
  }
  
  //2. 如果修改的是第一个孩子,就会对这个父亲的父亲产生影响
  if(index == 0){
    // 先获取本父亲的节点id，本父亲在writeset的最后一个
    WritePageGuard &parent_wguard = ctx->write_set_.back();
    page_id_t parent_page_id = parent_wguard.GetPageId();
    // //父亲不需要修改，释放父亲的锁
    // parent_wguard.Drop();
    // ctx->write_set_.pop_back();

    // 获取爷爷的page，并转换成写锁
    ReadPageGuard grandparent_rguard = std::move(ctx->read_set_.back());
    page_id_t grandparent_page_id = grandparent_rguard.GetPageId();
    grandparent_rguard.Drop();
    ctx->read_set_.pop_back();
    
    WritePageGuard grandparent_wguard = bpm_->WritePage(grandparent_page_id);
    auto grandparent_page = grandparent_wguard.AsMut<InternalPage>();
    ctx->write_set_.push_back(std::move(grandparent_wguard));

    Updatekey(grandparent_page, new_key, parent_page_id, ctx);
    
    //释放爷爷的写锁
    grandparent_wguard = std::move(ctx->write_set_.back());
    grandparent_wguard.Drop();
    ctx->write_set_.pop_back();
    //将爷爷放回读锁
    grandparent_rguard = bpm_->ReadPage(grandparent_page_id);
    ctx->read_set_.push_back(std::move(grandparent_rguard));
  }
  //3. 修改的是后面的孩子，则只修改本父亲key，不对爷爷产生影响
  else{
    parent_page->SetKeyAt(index, new_key);
  }
  return;
}
/*
*****************************************************************************
* Getbrother
*****************************************************************************/
/**
 * @brief 获取左边的兄弟或者右边的兄弟，注意，这里read_set_的尾部是当前节点的爸爸
 *
 * @param leftpage
 * @param rigthpage
 * @param ctx 上下文，此时read_set_最后一个是这个的父亲
 *
 * @return : 兄弟节点的id
 */

INDEX_TEMPLATE_ARGUMENTS
page_id_t BPLUSTREE_TYPE::Getleftbro(ReadPageGuard *right_rguard, Context *ctx) {
  // right是当前节点
  // 1. 如果当前节点是根节点，返回错误
  if (ctx->IsRootPage(right_rguard->GetPageId())) {
    abort();
    BUSTUB_ASSERT(false, "为什么会查找根节点的兄弟呢？");
  }

  // const BPlusTreePage* rightpage = right_rguard->As<BPlusTreePage>();

  // 2. 对于叶子节点和内部节点，都需要通过父节点查找左兄弟
  // 储存路上的节点
  Context tmp_ctx;
  
  // 获取当前节点的父亲
  ReadPageGuard parent_rguard = std::move(ctx->read_set_.back());
  ctx->read_set_.pop_back();

  const InternalPage* parent_page = parent_rguard.As<InternalPage>();
  int index = parent_page->ValueIndex(right_rguard->GetPageId());

  tmp_ctx.read_set_.push_back(std::move(parent_rguard));

  // 3.1 如果index不是第一个，直接返回左边的兄弟
  if (index > 0) {
    return parent_page->ValueAt(index - 1);
  }
  // 3.2 如果是第一个，我们先上后下寻找左边兄弟
  else {
    // 记录我们向上走了几层
    int cnt = 1;
    page_id_t child_id = right_rguard->GetPageId();
    
    // 3.2.1 我们先找到第一个不是其父亲第一个孩子的祖先
    while (index == 0) {
      // 如果没有爷爷了，就返回0，表示没有左兄弟
      if (ctx->read_set_.empty()) {
        return 0;
      }
      
      // 父亲变成孩子，获取父亲的id
      child_id = tmp_ctx.read_set_.back().GetPageId();
      // 继续获取爷爷
      parent_rguard = std::move(ctx->read_set_.back());
      ctx->read_set_.pop_back();
      parent_page = parent_rguard.As<InternalPage>();
      tmp_ctx.read_set_.push_back(std::move(parent_rguard));

      index = parent_page->ValueIndex(child_id);
      cnt++;
    }
    
    // 当while结束时，parent_page是有左边兄弟的
    // 先走到第一个左边兄弟
    cnt--;
    parent_page = tmp_ctx.read_set_.back().As<InternalPage>();
    // parent_page = tmp_ctx.read_set_.back().As<BPlusTreePage>();
    // if (parent_page->IsLeafPage()){
    //   parent_page = tmp_ctx.read_set_.back().As<LeafPage>();
    // }
    // else{
    //   parent_page = tmp_ctx.read_set_.back().As<InternalPage>();
    // }
    child_id = parent_page->ValueAt(index - 1);
    // 现在这个childid是第一个左边兄弟的id
    
    // 我们还原ctx
    while (!tmp_ctx.read_set_.empty()) {
      auto &guard = tmp_ctx.read_set_.back();
      ctx->read_set_.push_back(std::move(guard));
      guard.Drop();
      tmp_ctx.read_set_.pop_back();
    }
    
    // 然后一直往右下遍历直到达到与当前节点相同的层
    while (cnt-- > 0) {
      ReadPageGuard child_rguard = bpm_->ReadPage(child_id);
      auto child_page = child_rguard.As<BPlusTreePage>();
      
      // 选择最右边的子节点
      if (child_page->IsLeafPage()) {
        // 如果是叶子节点，直接返回
        child_rguard.Drop();
        break;
      } else {
        // 如果是内部节点，选择最右边的子节点
        auto internal_page = child_rguard.As<InternalPage>();
        child_id = internal_page->ValueAt(internal_page->GetSize() - 1);
        child_rguard.Drop();
      }
    }
    
    return child_id;
  }
}

INDEX_TEMPLATE_ARGUMENTS
page_id_t BPLUSTREE_TYPE::Getrightbro(ReadPageGuard *left_rguard, Context *ctx) {
  //left是当前节点
  //1. 如果当前节点是根节点，返回错误
  if(ctx->IsRootPage(left_rguard->GetPageId())){
    abort();
    BUSTUB_ASSERT(false,"为什么会查找根节点的兄弟呢？");
  }

  const BPlusTreePage* leftpage = left_rguard->As<BPlusTreePage>();
  //2. 如果当前节点是叶子节点
  if (leftpage->IsLeafPage()) {
    //希望用nextpageid获得右边的节点
    const LeafPage* left_leaf_page = left_rguard->As<LeafPage>();
    //如果没有next了，返回的应该是0
    return left_leaf_page->GetNextPageId();
  }
  //3. 当前是内部节点，我们走上再走下来找傍边节点
  else{
    //储存路上的节点
    Context tmp_ctx;
    
    //获取当前节点的父亲
    ReadPageGuard parent_rguard = std::move(ctx->read_set_.back());
    //page_id_t parent_page_id = parent_rguard.GetPageId();
    ctx->read_set_.pop_back();

    const InternalPage* parent_page = parent_rguard.As<InternalPage>();
    int index = parent_page->ValueIndex(left_rguard->GetPageId());

    tmp_ctx.read_set_.push_back(std::move(parent_rguard));

    //3.1 如果index不是最后一个，直接返回右边的兄弟
    if(index < parent_page->GetSize()-1){
      return parent_page->ValueAt(index+1);
    }
    //3.2 如果是最后一个，我们先上后下寻找右边兄弟
    else{
      //记录我们网上走了几层？
      int cnt=1;
      page_id_t child_id = left_rguard->GetPageId();
      // 此时，child_rguard是当前节点的读锁，parent_rguard是父亲的读锁
      //  3.2.1 我们先找到第一个有右边节点的祖先
      while (index == parent_page->GetSize() - 1) {
        //如果没有爷爷了，就返回0
        if(ctx->read_set_.empty()) {
          return 0;
        }
        
        //父亲变成孩子，获取父亲的id
        child_id = tmp_ctx.read_set_.back().GetPageId();
        //继续获取爷爷
        parent_rguard = std::move(ctx->read_set_.back());
        ctx->read_set_.pop_back();
        parent_page = parent_rguard.As<InternalPage>();
        tmp_ctx.read_set_.push_back(std::move(parent_rguard));

        index = parent_page->ValueIndex(child_id);
        cnt++;
      }
      // 当whilie结束的时候，parent_page是有右边兄弟的,然后我们一直往左下走，
      // 先走到第一个右边兄弟
      cnt--;
      parent_page = tmp_ctx.read_set_.back().As<InternalPage>();
      child_id = parent_page->ValueAt(index + 1);
      //现在这个childid是第一个右边兄弟的id
      //我们还原ctx
      while(tmp_ctx.read_set_.size() > 1) {
        auto &guard = tmp_ctx.read_set_.back();
        ctx->read_set_.push_back(std::move(guard));
        guard.Drop();  // 明确调用Drop而不是依赖移动
        tmp_ctx.read_set_.pop_back();
      }
      
      while(cnt-- > 0){
        ReadPageGuard child_rguard = bpm_->ReadPage(child_id);
        auto child_rpage = child_rguard.As<BPlusTreePage>();
        if(child_rpage->IsLeafPage()){
          break;
        }
        auto child_page = child_rguard.As<InternalPage>();
        child_id = child_page->ValueAt(0);
        child_rguard.Drop();
      }
      return child_id;
    }

  }
  
}

/*
*****************************************************************************
* MergeOrRedistributeLeafNode
*****************************************************************************/

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::MergeOrRedistributeLeafNode(WritePageGuard* leaf_wguard, LeafPage *leaf, page_id_t leaf_page_id, Context *ctx) -> bool {
  // 1. 先检查是否是根节点
  if (ctx->IsRootPage(leaf_page_id)) {
    // 如果是根节点且为空，则删除根节点
    if (leaf->GetSize() == 0) {
      auto header_page = ctx->header_page_.value().AsMut<BPlusTreeHeaderPage>();
      header_page->root_page_id_ = INVALID_PAGE_ID;
      // 释放当前页面守卫
      leaf_wguard->Drop();
      // 删除根节点页面
      bpm_->DeletePage(leaf_page_id);
    }
    return true;
  }

  // 如果节点大小符合最小要求，无需处理
  if (leaf->GetSize() >= leaf->GetMinSize()) {
    return true;
  }
  
  // 2. 获取父节点
  ReadPageGuard &parent_read_guard = ctx->read_set_.back();
  page_id_t parent_page_id = parent_read_guard.GetPageId();
  parent_read_guard.Drop();
  ctx->read_set_.pop_back();
  
  WritePageGuard parent_write_guard = bpm_->WritePage(parent_page_id);
  InternalPage* parent_page = parent_write_guard.AsMut<InternalPage>();
  ctx->write_set_.push_back(std::move(parent_write_guard));
  
  // 3. 找到当前节点在父节点中的索引
  int node_index = parent_page->ValueIndex(leaf_page_id);
  
  // 4. 检查左兄弟，如果存在相同父亲的左兄弟
  if (node_index > 0) {
    page_id_t left_sibling_id = parent_page->ValueAt(node_index - 1);
    WritePageGuard left_sibling_guard = bpm_->WritePage(left_sibling_id);
    LeafPage* left_sibling = left_sibling_guard.AsMut<LeafPage>();
    
    // 4.1 尝试从左兄弟借节点
    if (left_sibling->GetSize() > left_sibling->GetMinSize()) {
      // 获取左兄弟最后一个键值对
      int last_idx = left_sibling->GetSize() - 1;
      KeyType key = left_sibling->KeyAt(last_idx);
      ValueType value = left_sibling->ValueAt(last_idx);
      
      // 在当前节点开头插入借来的键值对
      leaf->InsertValue(key, value, 0);
      
      // 从左兄弟删除已借出的键值对
      left_sibling->Remove(last_idx);
      
      // 更新父节点中的分隔键
      // Updatekey(parent_page, leaf->KeyAt(0), leaf_page_id, ctx);
      //借的是左兄弟的话，只需要更新父亲的key，前面的不需要更新
      parent_page->SetKeyAt(node_index, leaf->KeyAt(0));
      
      //释放兄弟
      left_sibling_guard.Drop();
      return true;
    }
    
    // 4.2 左兄弟不能借，直接合并
    // 将当前节点的所有键值对移至左兄弟
    for (int i = 0; i < leaf->GetSize(); i++) {
      left_sibling->InsertValue(leaf->KeyAt(i), leaf->ValueAt(i), left_sibling->GetSize());
    }
    
    // 更新链表指针
    left_sibling->SetNextPageId(leaf->GetNextPageId());
    
    // 从父节点中删除当前节点的索引和指针
    parent_page->Remove(node_index);
    
    /*
    既然都有左兄弟了，更新key的时候只需要删掉父亲的nodeindex的key，并且不需要更新祖先的key？？？
    */
    
    // 释放当前节点页面
    leaf_wguard->Drop();
    bpm_->DeletePage(leaf_page_id);
    
    left_sibling_guard.Drop();
    
    // 递归处理父节点是否需要合并
    auto &parent_guard = ctx->write_set_.back();
    return MergeOrRedistributeInternalNode(&parent_guard, parent_page, parent_page_id, ctx);
  }
  
  // 5. 如果没有左兄弟，检查右兄弟
  if (node_index < parent_page->GetSize() - 1) {
    page_id_t right_sibling_id = parent_page->ValueAt(node_index + 1);
    WritePageGuard right_sibling_guard = bpm_->WritePage(right_sibling_id);
    LeafPage* right_sibling = right_sibling_guard.AsMut<LeafPage>();
    
    // 5.1 尝试从右兄弟借节点
    if (right_sibling->GetSize() > right_sibling->GetMinSize()) {
      // 获取右兄弟第一个键值对
      KeyType key = right_sibling->KeyAt(0);
      ValueType value = right_sibling->ValueAt(0);
      
      // 在当前节点末尾插入借来的键值对
      leaf->InsertValue(key, value, leaf->GetSize());
      
      // 从右兄弟删除已借出的键值对
      right_sibling->Remove(0);
      
      // 更新父节点中的分隔键
      parent_page->SetKeyAt(node_index + 1, right_sibling->KeyAt(0));
      
      right_sibling_guard.Drop();
      return true;
    }
    
    // 5.2 右兄弟不能借，进行合并
    // 将右兄弟的所有键值对移至当前节点
    for (int i = 0; i < right_sibling->GetSize(); i++) {
      leaf->InsertValue(right_sibling->KeyAt(i), right_sibling->ValueAt(i), leaf->GetSize());
    }
    
    // 更新链表指针
    leaf->SetNextPageId(right_sibling->GetNextPageId());
    
    // 从父节点中删除右兄弟的索引和指针
    parent_page->Remove(node_index + 1);
    
    // 释放右兄弟节点页面
    right_sibling_guard.Drop();
    bpm_->DeletePage(right_sibling_id);
    
    // 递归处理父节点是否需要合并
    auto &parent_guard = ctx->write_set_.back();
    return MergeOrRedistributeInternalNode(&parent_guard, parent_page, parent_page_id, ctx);
  }
  
  // 不应该到达这里
  BUSTUB_ASSERT(false, "叶子节点无法满足最小大小要求且没有兄弟节点");
  return false;
}

/******************************************************************************
* MergeOrRedistributeInternalNode
*****************************************************************************/
// 实现内部节点的合并或重分配函数
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::MergeOrRedistributeInternalNode(WritePageGuard* internal_wguard, InternalPage *internal_page, page_id_t internal_page_id, Context *ctx) -> bool {
  // 1. 检查是否是根节点
  if (ctx->IsRootPage(internal_page_id)) {
    // 如果根节点只剩一个子节点，将子节点提升为新的根节点
    if (internal_page->GetSize() == 1) {
      page_id_t child_page_id = internal_page->ValueAt(0);
      
      // 更新头页中的根节点ID
      auto header_page = ctx->header_page_.value().AsMut<BPlusTreeHeaderPage>();
      header_page->root_page_id_ = child_page_id;
      ctx->root_page_id_ = child_page_id;
      
      // 释放当前根节点
      internal_wguard->Drop();
      bpm_->DeletePage(internal_page_id);
    }
    return true;
  }
  
  // 如果节点大小符合最小要求，无需处理
  if (internal_page->GetSize() >= internal_page->GetMinSize()) {
    return true;
  }
  
  // 2. 获取父节点
  if (ctx->read_set_.empty()) {
    abort();
    // 处理错误情况
    return false;
  }
  
  ReadPageGuard &parent_read_guard = ctx->read_set_.back();
  page_id_t parent_page_id = parent_read_guard.GetPageId();
  parent_read_guard.Drop();
  ctx->read_set_.pop_back();
  
  WritePageGuard parent_write_guard = bpm_->WritePage(parent_page_id);
  auto parent_page = parent_write_guard.AsMut<InternalPage>();
  ctx->write_set_.push_back(std::move(parent_write_guard));
  
  // 3. 找到当前节点在父节点中的索引
  int node_index = parent_page->ValueIndex(internal_page_id);
  
  // 确保父节点指针正确更新
  BUSTUB_ASSERT(parent_page->ValueAt(parent_page->ValueIndex(internal_page_id)) == internal_page_id,
                "Parent pointer not correctly updated after merge!");

  // 4. 检查左兄弟
  if (node_index > 0) {
    page_id_t left_sibling_id = parent_page->ValueAt(node_index - 1);
    WritePageGuard left_sibling_guard = bpm_->WritePage(left_sibling_id);
    InternalPage* left_sibling = left_sibling_guard.AsMut<InternalPage>();
    
    // 4.1 尝试从左兄弟借节点
    if (left_sibling->GetSize() > left_sibling->GetMinSize()) {
      // 获取父节点中的分隔键
      KeyType parent_key = parent_page->KeyAt(node_index);
      
      // 获取左兄弟最后一个键和子节点指针
      int last_idx = left_sibling->GetSize() - 1;
      KeyType sibling_key = left_sibling->KeyAt(last_idx);
      page_id_t sibling_value = left_sibling->ValueAt(last_idx);
      
      // 在当前节点开头插入从父节点借来的键和从左兄弟借来的子节点
      internal_page->InsertValue(parent_key, sibling_value, 0);
      internal_page->SetKeyAt(1, parent_key);

      // 更新当前节点的第一个键,从父亲那拿回原先的键
      // KeyType first_key = parent_page->KeyAt(1);
      // internal_page->SetKeyAt(1, sibling_key);

      // 更新父节点中的分隔键
      parent_page->SetKeyAt(node_index, sibling_key);

      // 从左兄弟删除借出的键和子节点
      left_sibling->ChangeSizeBy(-1);
      
      left_sibling_guard.Drop();
      return true;
    }
    
    // 4.2 左兄弟不能借，直接合并
    // 获取父节点中的分隔键
    KeyType parent_key = parent_page->KeyAt(node_index);
    
    // 将父节点的分隔键下移到左兄弟
    left_sibling->InsertValue(parent_key, internal_page->ValueAt(0), left_sibling->GetSize());
    
    // 将当前节点的所有子节点指针移到左兄弟
    for (int i = 1; i < internal_page->GetSize(); i++) {
      left_sibling->InsertValue(internal_page->KeyAt(i), internal_page->ValueAt(i), left_sibling->GetSize());
    }
    
    // int merged_size = left_sibling->GetSize() + internal_page->GetSize();
    // if (merged_size != left_sibling->GetSize()){
    //   abort();
    //   BUSTUB_ASSERT(false, "合并后的大小不一致");
    // }

    // 从父节点中删除当前节点的索引和指针
    parent_page->Remove(node_index);
    
    // 释放当前节点页面
    internal_wguard->Drop();
    bpm_->DeletePage(internal_page_id);
    
    left_sibling_guard.Drop();
    
    // 递归处理父节点是否需要合并
    auto &parent_guard = ctx->write_set_.back();
    return MergeOrRedistributeInternalNode(&parent_guard, parent_page, parent_page_id, ctx);
  }
  
  // 5. 如果没有左兄弟，检查右兄弟
  if (node_index < parent_page->GetSize() - 1) {
    page_id_t right_sibling_id = parent_page->ValueAt(node_index + 1);
    WritePageGuard right_sibling_guard = bpm_->WritePage(right_sibling_id);
    InternalPage* right_sibling = right_sibling_guard.AsMut<InternalPage>();
    
    // 5.1 尝试从右兄弟借节点
    if (right_sibling->GetSize() > right_sibling->GetMinSize()) {
      // 获取父节点中的分隔键
      KeyType parent_key = parent_page->KeyAt(node_index + 1);
      
      // 获取右兄弟第一个键和子节点指针
      KeyType sibling_key = right_sibling->KeyAt(1);
      page_id_t sibling_value = right_sibling->ValueAt(0);
      
      // 在当前节点末尾插入从父节点借来的键和从右兄弟借来的子节点
      internal_page->InsertValue(parent_key, sibling_value, internal_page->GetSize());

      // 更新父节点中的分隔键
      parent_page->SetKeyAt(node_index + 1, sibling_key);
      
      // 从右兄弟删除借出的键和子节点
      right_sibling->Remove(0);
      
      right_sibling_guard.Drop();
      return true;
    }
    
    // 5.2 右兄弟不能借，进行合并
    // 获取父节点中的分隔键
    KeyType parent_key = parent_page->KeyAt(node_index + 1);
    
    // 将父节点的分隔键下移到当前节点
    internal_page->InsertValue(parent_key,right_sibling->ValueAt(0), internal_page->GetSize());
    
    // 将右兄弟的所有子节点指针移到当前节点
    for (int i = 1; i < right_sibling->GetSize(); i++) {
      internal_page->InsertValue(right_sibling->KeyAt(i), right_sibling->ValueAt(i), internal_page->GetSize());
    }
    
    // int merged_size = internal_page->GetSize() + right_sibling->GetSize();
    // if(merged_size != internal_page->GetSize()){
    //   abort();
    //   BUSTUB_ASSERT(false, "合并后的大小不一致");
    // }
    // //internal_page->SetSize(merged_size);
    
    // 从父节点中删除右兄弟的索引和指针
    parent_page->Remove(node_index + 1);
    
    // 释放右兄弟节点页面
    right_sibling_guard.Drop();
    bpm_->DeletePage(right_sibling_id);
    
    // 递归处理父节点是否需要合并
    auto &parent_guard = ctx->write_set_.back();
    return MergeOrRedistributeInternalNode(&parent_guard, parent_page, parent_page_id, ctx);
  }
  
  // 不应该到达这里
  BUSTUB_ASSERT(false, "内部节点无法满足最小大小要求且没有兄弟节点");
  return false;
}

/*****************************************************************************
 * REMOVE
 *****************************************************************************/

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Remove(const KeyType &key) {
  // Declaration of context instance.
  Context ctx;
  // 获取根节点ID给ctx,并且转移header的写锁给ctx
  WritePageGuard guard = bpm_->WritePage(header_page_id_);
  auto header_page = guard.AsMut<BPlusTreeHeaderPage>();
  page_id_t root_page_id = header_page->root_page_id_;
  ctx.root_page_id_ = root_page_id;
  ctx.header_page_ = std::move(guard);

  if (root_page_id == INVALID_PAGE_ID) {
    return;  // 树是空的，直接返回
  }

  page_id_t current_page_id = root_page_id;

  ReadPageGuard page_guard = bpm_->ReadPage(current_page_id);
  // 查找叶子节点
  while(true) {
    page_guard = bpm_->ReadPage(current_page_id);
    auto current_page = page_guard.As<BPlusTreePage>();
    
    // 如果当前不是叶子节点
    if (!current_page->IsLeafPage()) {
      // 内部节点，继续查找
      auto internal = page_guard.As<InternalPage>();
      int index = internal->Lookup(key, comparator_);
      current_page_id = internal->ValueAt(index);
      ctx.read_set_.push_back(std::move(page_guard));  // 保存路径
    }
    // 如果当前页面是叶子节点，进行删除
    else {
      // 叶子节点转为写权限
      page_guard.Drop();  // 释放读锁
      WritePageGuard write_guard = bpm_->WritePage(current_page_id);
      auto leaf = write_guard.AsMut<LeafPage>();
      
      // 查找键的位置
      int index = leaf->checkKey(key, comparator_);
      
      // 如果键存在，执行删除
      if (index < leaf->GetSize() && comparator_(leaf->KeyAt(index), key) == 0) {
        // 执行删除操作
        leaf->Remove(index);

        if (current_page_id == ctx.root_page_id_) {
          // 如果删除的是根节点，检查是否需要更新根节点
          if (leaf->GetSize() == 0) {
            // 如果根节点为空，更新头页中的根节点ID
            auto header_page = ctx.header_page_.value().AsMut<BPlusTreeHeaderPage>();
            header_page->root_page_id_ = INVALID_PAGE_ID;
            ctx.root_page_id_ = INVALID_PAGE_ID;
            write_guard.Drop();
            bpm_->DeletePage(current_page_id);
            return;
          }
        }

          // //如果删除的是第一个键，且节点仍有元素，需要更新父节点中的分隔键
          // if (index == 0 && leaf->GetSize() > 0 && !ctx.read_set_.empty()) {
          //   // 获取父节点
          //   ReadPageGuard parent_read_guard = std::move(ctx.read_set_.back());
          //   page_id_t parent_page_id = parent_read_guard.GetPageId();
          //   parent_read_guard.Drop();
          //   ctx.read_set_.pop_back();

          //   WritePageGuard parent_write_guard = bpm_->WritePage(parent_page_id);
          //   auto parent_page = parent_write_guard.AsMut<InternalPage>();
          //   ctx.write_set_.push_back(std::move(parent_write_guard));

          //   // 更新父节点中的分隔键为当前叶子节点的新的第一个键
          //   KeyType new_key = leaf->KeyAt(0);
          //   Updatekey(parent_page, new_key, current_page_id, &ctx);

          //   //将父亲节点放回ctx readset中
          //   //先释放父亲的写锁
          //   parent_write_guard = std::move(ctx.write_set_.back());
          //   ctx.write_set_.pop_back();
          //   parent_write_guard.Drop();
          //   // 重新获取父节点的读锁放回readset里面
          //   parent_read_guard = bpm_->ReadPage(parent_page_id);
          //   ctx.read_set_.push_back(std::move(parent_read_guard));
          // }

          // 处理删除后可能的合并/重分配
          ctx.write_set_.push_back(std::move(write_guard));
        auto &leaf_guard = ctx.write_set_.back();
        MergeOrRedistributeLeafNode(&leaf_guard, leaf, current_page_id, &ctx);
      }
      
      return;  // 完成删除操作
    }
  }
}

/*****************************************************************************
 * INDEX ITERATOR
 *****************************************************************************/
/**
 * @brief Input parameter is void, find the leftmost leaf page first, then construct
 * index iterator
 *
 * You may want to implement this while implementing Task #3.
 * 这个想找到数据的最左边的叶子节点，然后构造一个迭代器
 * @return : index iterator
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Begin() -> INDEXITERATOR_TYPE {
  ReadPageGuard guard = bpm_->ReadPage(header_page_id_);
  // 处理空树情况
  if (IsEmpty()) {
    return End();
  }

  // 获取根节点ID
  
  auto header_page = guard.As<BPlusTreeHeaderPage>();
  page_id_t root_page_id = header_page->root_page_id_;

  // 从根节点开始，一直查找最左侧的子节点，直到找到叶子节点
  page_id_t current_page_id = root_page_id;
  ReadPageGuard page_guard = bpm_->ReadPage(current_page_id);
  while (true) {
    page_guard = bpm_->ReadPage(current_page_id);
    auto page = page_guard.As<BPlusTreePage>();
    
    // 如果是叶子节点，创建迭代器
    if (page->IsLeafPage()) {
      // 创建并返回迭代器，指向最左侧叶子节点的第一个元素
      return INDEXITERATOR_TYPE(bpm_, current_page_id, 0);
    }
    
    // 如果是内部节点，继续查找最左侧子节点
    auto internal = page_guard.As<InternalPage>();
    // 内部节点的最左侧子节点总是在索引0处
    current_page_id = internal->ValueAt(0);
    //page_guard.Drop();
  }
}

/**
 * @brief Input parameter is void, construct an index iterator representing the end
 * of the key/value pair in the leaf node
 * @return : index iterator
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::End() -> INDEXITERATOR_TYPE {
  // 返回表示迭代器结束的实例
  return INDEXITERATOR_TYPE(bpm_, INVALID_PAGE_ID, 0);
}

/**
 * @brief Input parameter is low key, find the leaf page that contains the input key
 * first, then construct index iterator
 * @return : index iterator
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Begin(const KeyType &key) -> INDEXITERATOR_TYPE {
  ReadPageGuard guard = bpm_->ReadPage(header_page_id_);

  // 处理空树情况
  if (IsEmpty()) {
    return End();
  }

  // 获取根节点ID
  //ReadPageGuard guard = bpm_->ReadPage(header_page_id_);
  auto header_page = guard.As<BPlusTreeHeaderPage>();
  page_id_t root_page_id = header_page->root_page_id_;

  // 从根节点开始，查找包含指定键的叶子节点
  page_id_t current_page_id = root_page_id;
  while (true) {
    ReadPageGuard page_guard = bpm_->ReadPage(current_page_id);
    auto page = page_guard.As<BPlusTreePage>();
    
    if (page->IsLeafPage()) {
      auto leaf = page_guard.As<LeafPage>();
      // 在叶子节点中查找大于等于指定键的第一个位置
      int index = leaf->checkKey(key, comparator_);
      //这里如果不存在，则index是插入位置
      // 创建迭代器，指向找到的位置
      return INDEXITERATOR_TYPE(bpm_, current_page_id, index);
    }
    
    // 继续在内部节点中查找
    auto internal = page_guard.As<InternalPage>();
    int index = internal->Lookup(key, comparator_);
    current_page_id = internal->ValueAt(index);
    page_guard.Drop();
  }
}

/**
 * @return Page id of the root of this tree
 *
 * You may want to implement this while implementing Task #3.
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::GetRootPageId() -> page_id_t {
  ReadPageGuard guard = bpm_->ReadPage(header_page_id_);
  auto header_page = guard.As<BPlusTreeHeaderPage>();
  return header_page->root_page_id_;
}

/*****************************************************************************
 * PRINT
 *****************************************************************************/
/**
 * @brief Print the B+ tree structure
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Print() {
  ReadPageGuard header_page_guard = bpm_->ReadPage(header_page_id_);

  auto root_page_id = header_page_guard.As<BPlusTreeHeaderPage>()->root_page_id_;
  if (root_page_id == INVALID_PAGE_ID) {
    std::cout << "Empty tree" << std::endl;
    return;
  }
  
  // 直接使用b_plus_tree_debug.h中已实现的PrintTree
  ReadPageGuard guard = bpm_->ReadPage(root_page_id);
  auto page = guard.template As<BPlusTreePage>();
  
  // 使用已有的PrintTree函数
  PrintTree(root_page_id, page);
  
  // 也可以使用更简洁的方式
  std::cout << "\nCompact tree representation:\n" << DrawBPlusTree() << std::endl;
}

template class BPlusTree<GenericKey<4>, RID, GenericComparator<4>>;

template class BPlusTree<GenericKey<8>, RID, GenericComparator<8>>;

template class BPlusTree<GenericKey<16>, RID, GenericComparator<16>>;

template class BPlusTree<GenericKey<32>, RID, GenericComparator<32>>;

template class BPlusTree<GenericKey<64>, RID, GenericComparator<64>>;

}  // namespace bustub
