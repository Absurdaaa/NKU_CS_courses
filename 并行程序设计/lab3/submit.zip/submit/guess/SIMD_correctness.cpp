#include "PCFG.h"
#include <chrono>
#include <fstream>
#include "SIMD_md5.h"
// #include "md5.h"
#include <iomanip>
using namespace std;
using namespace chrono;

string test1 = "bvaisdbjasdkafkasdfnavkjnakdjfejfanjsdnfkajdfkajdfjkwanfdjaknsvjkanbjbjadfajwefajksdfakdnsvjadfasjdvabvaisdbjasdkafkasdfnavkjnakdjfejfanjsdnfkajdfkajdfjkwanfdjaknsvjkanbjbjadfajwefajksdfakdnsvjadfasjdvabvaisdbjasdkafkasdfnavkjnakdjfejfanjsdnfkajdfkajdfjkwanfdjaknsvjkanbjbjadfajwefajksdfakdnsvjadfasjdvabvaisdbjasdkafkasdfnavkjnakdjfejfanjsdnfkajdfkajdfjkwanfdjaknsvjkanbjbjadfajwefajksdfakdnsvjadfasjdva";  
// c09a99098b5d0cfefe205dd99822487f    
string test2=
"adhfkjbdhshcbhdhciuashdcuisdhaciuhdsiuchksjabcweuiciuwhuidshacnjkznjkxnbckjbsdahbcajhdsbcjhsdbchjbasjadhfkjbdhshcbhdhciuashdcuisdhaciuhdsiuchksjabcweuiciuwhuidshacnjkznjkxnbckjbsdahbcajhdsbcjhsdbchjbasjadhfkjbdhshcbhdhciuashdcuisdhaciuhdsiuchksjabcweuiciuwhuidshacnjkznjkxnbckjbsdahbcajhdsbcjhsdbchjbasjadhfkjbdhshcbhdhciuashdcuisdhaciuhdsiuchksjabcweuiciuwhuidshacnjkznjkxnbckjbsdahbcajhdsbcjhsdbchjbasj";
string test3 = "ashdbchjsdbjchbsajhdbcjshdbcwheudihiuewhfuihausgfyugsdjfhjkhfskdjhfuewhfuiwhiwuehfeuiwhfuiwhfeuihewuiashdbchjsdbjchbsajhdbcjshdbcwheudihiuewhfuihausgfyugsdjfhjkhfskdjhfuewhfuiwhiwuehfeuiwhfuiwhfeuihewuiashdbchjsdbjchbsajhdbcjshdbcwheudihiuewhfuihausgfyugsdjfhjkhfskdjhfuewhfuiwhiwuehfeuiwhfuiwhfeuihewuiashdbchjsdbjchbsajhdbcjshdbcwheudihiuewhfuihausgfyugsdjfhjkhfskdjhfuewhfuiwhiwuehfeuiwhfuiwhfeuihewui";
string test4 = "djbchjsbdhvbhcbbsdjkncjkdhcdsiuhiuehcksjdhujhuehfiuwehcadkjhciuwehyhsgtyuiuytretytdyhghbxhsdbcksapqpddjbchjsbdhvbhcbbsdjkncjkdhcdsiuhiuehcksjdhujhuehfiuwehcadkjhciuwehyhsgtyuiuytretytdyhghbxhsdbcksapqpddjbchjsbdhvbhcbbsdjkncjkdhcdsiuhiuehcksjdhujhuehfiuwehcadkjhciuwehyhsgtyuiuytretytdyhghbxhsdbcksapqpddjbchjsbdhvbhcbbsdjkncjkdhcdsiuhiuehcksjdhujhuehfiuwehcadkjhciuwehyhsgtyuiuytretytdyhghbxhsdbcksapqpd";

// bba46eb8b53cf65d50ca54b2f8afd9db
// c09a99098b5d0cfefe205dd99822487f
// ed5a1b1ee6b109599835c7254bca15d8
// 4d2d293624aa2ab7e0ffbc585e6de0f0

// 编译指令如下：
// g++ correctness.cpp train.cpp guessing.cpp md5.cpp -o test.exe

// 通过这个函数，你可以验证你实现的SIMD哈希函数的正确性
// int main()
// {
//     bit32 state[4];
//     MD5Hash(test1, state);
//     for (int i1 = 0; i1 < 4; i1 += 1)
//     {
//         cout << std::setw(8) << std::setfill('0') << hex << state[i1];
//     }
//     cout<<endl;
//     MD5Hash(test2, state);
//     for (int i1 = 0; i1 < 4; i1 += 1)
//     {
//       cout << std::setw(8) << std::setfill('0') << hex << state[i1];
//     }
//     cout<<endl;
//     MD5Hash(test3, state);
//     for (int i1 = 0; i1 < 4; i1 += 1)
//     {
//       cout << std::setw(8) << std::setfill('0') << hex << state[i1];
//     }
//     cout << endl;
//     MD5Hash(test4, state);
//     for (int i1 = 0; i1 < 4; i1 += 1)
//     {
//       cout << std::setw(8) << std::setfill('0') << hex << state[i1];
//     }
//     cout << endl;
// }


// 通过这个函数，你可以验证你实现的SIMD哈希函数的正确性
// g++ correctness.cpp train.cpp guessing.cpp SIMD_md5.cpp -o main
int main()
{
  bit32 state[4][4];
  string input[4];
  // for (int i = 0; i < 4; i++)
  // {
  //   input[i] = "bvaisdbjasdkafkasdfnavkjnakdjfejfanjsdnfkajdfkajdfjkwanfdjaknsvjkanbjbjadfajwefajksdfakdnsvjadfasjdvabvaisdbjasdkafkasdfnavkjnakdjfejfanjsdnfkajdfkajdfjkwanfdjaknsvjkanbjbjadfajwefajksdfakdnsvjadfasjdvabvaisdbjasdkafkasdfnavkjnakdjfejfanjsdnfkajdfkajdfjkwanfdjaknsvjkanbjbjadfajwefajksdfakdnsvjadfasjdvabvaisdbjasdkafkasdfnavkjnakdjfejfanjsdnfkajdfkajdfjkwanfdjaknsvjkanbjbjadfajwefajksdfakdnsvjadfasjdva";
  // }
  input[0]=test1;
  input[1]=test2;
  input[2]=test3;
  input[3]=test4;
  SIMD_MD5Hash(input, state);
  for (int i = 0; i < 4; i++)
  {
    for (int i1 = 0; i1 < 4; i1 += 1)
    {
      cout << std::setw(8) << std::setfill('0') << hex << state[i][i1];
    }
    cout << endl;
  }

  cout << endl;
  
  // for(int k=0;k<10000;k++){
  //   input[0] = test1;
  //   input[1] = test2;
  //   input[2] = test3;
  //   input[3] = test4;
  //   SIMD_MD5Hash(input, state);
  // }
}

//     // bvaisdbjasdkafkasdfnavkjnakdjfejfanjsdnfkajdfkajdfjkwanfdjaknsvjkanbjbjadfajwefajksdfakdnsvjadfasjdva
//     // adhfkjbdhshcbhdhciuashdcuisdhaciuhdsiuchksjabcweuiciuwhuidshacnjkznjkxnbckjbsdahbcajhdsbcjhsdbchjbasj
//     // ashdbchjsdbjchbsajhdbcjshdbcwheudihiuewhfuihausgfyugsdjfhjkhfskdjhfuewhfuiwhiwuehfeuiwhfuiwhfeuihewui
//     // djbchjsbdhvbhcbbsdjkncjkdhcdsiuhiuehcksjdhujhuehfiuwehcadkjhciuwehyhsgtyuiuytretytdyhghbxhsdbcksapqpd