#include <pthread.h>
#include <vector>
#include <string>
#include <iostream>
#include "../PCFG.h"
using namespace std;

// 定义线程参数结构体
struct ThreadArgs
{
  int start;
  int end;
  string base_guess;
  segment *a;
  vector<string> *guesses;
  int init_size;
};

// 线程函数
void *generate_guesses(void *args)
{
  ThreadArgs *threadArgs = (ThreadArgs *)args;
  for (int i = threadArgs->start; i < threadArgs->end; i++)
  {
    string temp = threadArgs->base_guess + threadArgs->a->ordered_values[i];
    (*threadArgs->guesses)[threadArgs->init_size + i] = temp;
  }
  pthread_exit(nullptr);
}